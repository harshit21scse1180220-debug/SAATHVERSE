export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      branch_featured_students: {
        Row: {
          achievement: string | null
          branch: string
          college_id: string | null
          created_at: string
          created_by: string
          description: string | null
          display_order: number
          id: string
          is_active: boolean
          media_url: string | null
          profile_id: string
          updated_at: string
        }
        Insert: {
          achievement?: string | null
          branch: string
          college_id?: string | null
          created_at?: string
          created_by: string
          description?: string | null
          display_order?: number
          id?: string
          is_active?: boolean
          media_url?: string | null
          profile_id: string
          updated_at?: string
        }
        Update: {
          achievement?: string | null
          branch?: string
          college_id?: string | null
          created_at?: string
          created_by?: string
          description?: string | null
          display_order?: number
          id?: string
          is_active?: boolean
          media_url?: string | null
          profile_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "branch_featured_students_college_id_fkey"
            columns: ["college_id"]
            isOneToOne: false
            referencedRelation: "colleges"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "branch_featured_students_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      carousel_slides: {
        Row: {
          branch: string | null
          category: string
          college_id: string | null
          created_at: string
          created_by: string
          description: string | null
          display_order: number
          hyperlink: string | null
          hyperlink_text: string | null
          id: string
          is_active: boolean
          media_url: string | null
          title: string
          updated_at: string
        }
        Insert: {
          branch?: string | null
          category?: string
          college_id?: string | null
          created_at?: string
          created_by: string
          description?: string | null
          display_order?: number
          hyperlink?: string | null
          hyperlink_text?: string | null
          id?: string
          is_active?: boolean
          media_url?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          branch?: string | null
          category?: string
          college_id?: string | null
          created_at?: string
          created_by?: string
          description?: string | null
          display_order?: number
          hyperlink?: string | null
          hyperlink_text?: string | null
          id?: string
          is_active?: boolean
          media_url?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "carousel_slides_college_id_fkey"
            columns: ["college_id"]
            isOneToOne: false
            referencedRelation: "colleges"
            referencedColumns: ["id"]
          },
        ]
      }
      collaboration_requests: {
        Row: {
          created_at: string
          id: string
          message: string | null
          receiver_id: string
          sender_id: string
          status: string
        }
        Insert: {
          created_at?: string
          id?: string
          message?: string | null
          receiver_id: string
          sender_id: string
          status?: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string | null
          receiver_id?: string
          sender_id?: string
          status?: string
        }
        Relationships: []
      }
      colleges: {
        Row: {
          created_at: string
          domain: string
          id: string
          logo_url: string | null
          name: string
          primary_color: string | null
        }
        Insert: {
          created_at?: string
          domain: string
          id?: string
          logo_url?: string | null
          name: string
          primary_color?: string | null
        }
        Update: {
          created_at?: string
          domain?: string
          id?: string
          logo_url?: string | null
          name?: string
          primary_color?: string | null
        }
        Relationships: []
      }
      conferences: {
        Row: {
          category: string
          college_id: string | null
          created_at: string
          created_by: string
          deadline_date: string
          description: string | null
          id: string
          link_url: string | null
          mode: string
          organizer: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          category?: string
          college_id?: string | null
          created_at?: string
          created_by: string
          deadline_date: string
          description?: string | null
          id?: string
          link_url?: string | null
          mode?: string
          organizer: string
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          category?: string
          college_id?: string | null
          created_at?: string
          created_by?: string
          deadline_date?: string
          description?: string | null
          id?: string
          link_url?: string | null
          mode?: string
          organizer?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "conferences_college_id_fkey"
            columns: ["college_id"]
            isOneToOne: false
            referencedRelation: "colleges"
            referencedColumns: ["id"]
          },
        ]
      }
      content_cards: {
        Row: {
          about_text: string | null
          banner_image_url: string | null
          co_leader_id: string | null
          created_at: string
          display_order: number
          id: string
          image_url: string | null
          is_active: boolean
          leader_id: string | null
          link_url: string | null
          profile_id: string | null
          row_id: string
          subtitle: string | null
          title: string
          updated_at: string
        }
        Insert: {
          about_text?: string | null
          banner_image_url?: string | null
          co_leader_id?: string | null
          created_at?: string
          display_order?: number
          id?: string
          image_url?: string | null
          is_active?: boolean
          leader_id?: string | null
          link_url?: string | null
          profile_id?: string | null
          row_id: string
          subtitle?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          about_text?: string | null
          banner_image_url?: string | null
          co_leader_id?: string | null
          created_at?: string
          display_order?: number
          id?: string
          image_url?: string | null
          is_active?: boolean
          leader_id?: string | null
          link_url?: string | null
          profile_id?: string | null
          row_id?: string
          subtitle?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "content_cards_co_leader_id_fkey"
            columns: ["co_leader_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "content_cards_leader_id_fkey"
            columns: ["leader_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "content_cards_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "content_cards_row_id_fkey"
            columns: ["row_id"]
            isOneToOne: false
            referencedRelation: "content_rows"
            referencedColumns: ["id"]
          },
        ]
      }
      content_rows: {
        Row: {
          created_at: string
          display_order: number
          id: string
          is_active: boolean
          section_id: string
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_order?: number
          id?: string
          is_active?: boolean
          section_id: string
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_order?: number
          id?: string
          is_active?: boolean
          section_id?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "content_rows_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "content_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      content_sections: {
        Row: {
          college_id: string | null
          cover_image_url: string | null
          created_at: string
          created_by: string
          description: string | null
          display_order: number
          id: string
          is_active: boolean
          section_type: string
          title: string
          updated_at: string
        }
        Insert: {
          college_id?: string | null
          cover_image_url?: string | null
          created_at?: string
          created_by: string
          description?: string | null
          display_order?: number
          id?: string
          is_active?: boolean
          section_type?: string
          title: string
          updated_at?: string
        }
        Update: {
          college_id?: string | null
          cover_image_url?: string | null
          created_at?: string
          created_by?: string
          description?: string | null
          display_order?: number
          id?: string
          is_active?: boolean
          section_type?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "content_sections_college_id_fkey"
            columns: ["college_id"]
            isOneToOne: false
            referencedRelation: "colleges"
            referencedColumns: ["id"]
          },
        ]
      }
      event_logs: {
        Row: {
          created_at: string
          event_type: string
          id: string
          metadata: Json | null
          user_id: string
        }
        Insert: {
          created_at?: string
          event_type: string
          id?: string
          metadata?: Json | null
          user_id: string
        }
        Update: {
          created_at?: string
          event_type?: string
          id?: string
          metadata?: Json | null
          user_id?: string
        }
        Relationships: []
      }
      form_options: {
        Row: {
          category: string
          created_at: string
          display_order: number
          id: string
          is_active: boolean
          label: string
          parent_id: string | null
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          display_order?: number
          id?: string
          is_active?: boolean
          label: string
          parent_id?: string | null
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          display_order?: number
          id?: string
          is_active?: boolean
          label?: string
          parent_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "form_options_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "form_options"
            referencedColumns: ["id"]
          },
        ]
      }
      hackathon_teams: {
        Row: {
          created_at: string
          creator_id: string
          description: string | null
          hackathon_id: string
          id: string
          name: string
          roles_needed: string | null
          team_size: number | null
        }
        Insert: {
          created_at?: string
          creator_id: string
          description?: string | null
          hackathon_id: string
          id?: string
          name: string
          roles_needed?: string | null
          team_size?: number | null
        }
        Update: {
          created_at?: string
          creator_id?: string
          description?: string | null
          hackathon_id?: string
          id?: string
          name?: string
          roles_needed?: string | null
          team_size?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "hackathon_teams_hackathon_id_fkey"
            columns: ["hackathon_id"]
            isOneToOne: false
            referencedRelation: "hackathons"
            referencedColumns: ["id"]
          },
        ]
      }
      hackathons: {
        Row: {
          college_id: string | null
          created_at: string
          created_by: string
          description: string | null
          id: string
          link_url: string | null
          mode: string
          name: string
          organizer: string
          registration_deadline: string
          status: string
          updated_at: string
        }
        Insert: {
          college_id?: string | null
          created_at?: string
          created_by: string
          description?: string | null
          id?: string
          link_url?: string | null
          mode: string
          name: string
          organizer: string
          registration_deadline: string
          status?: string
          updated_at?: string
        }
        Update: {
          college_id?: string | null
          created_at?: string
          created_by?: string
          description?: string | null
          id?: string
          link_url?: string | null
          mode?: string
          name?: string
          organizer?: string
          registration_deadline?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "hackathons_college_id_fkey"
            columns: ["college_id"]
            isOneToOne: false
            referencedRelation: "colleges"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          content: string
          created_at: string
          id: string
          read_at: string | null
          receiver_id: string
          sender_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          read_at?: string | null
          receiver_id: string
          sender_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          read_at?: string | null
          receiver_id?: string
          sender_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          bio: string | null
          branch: string
          college_id: string | null
          college_name: string
          company_name: string | null
          created_at: string
          full_name: string
          gender: string
          id: string
          interested_in_hackathons: boolean | null
          is_alumni: boolean
          photo_url: string | null
          show_photo: boolean | null
          skills: string[] | null
          sub_branch: string | null
          tech_or_non_tech: string | null
          updated_at: string
          user_id: string
          year_of_passout: number | null
          year_of_study: number
        }
        Insert: {
          bio?: string | null
          branch: string
          college_id?: string | null
          college_name?: string
          company_name?: string | null
          created_at?: string
          full_name: string
          gender: string
          id?: string
          interested_in_hackathons?: boolean | null
          is_alumni?: boolean
          photo_url?: string | null
          show_photo?: boolean | null
          skills?: string[] | null
          sub_branch?: string | null
          tech_or_non_tech?: string | null
          updated_at?: string
          user_id: string
          year_of_passout?: number | null
          year_of_study: number
        }
        Update: {
          bio?: string | null
          branch?: string
          college_id?: string | null
          college_name?: string
          company_name?: string | null
          created_at?: string
          full_name?: string
          gender?: string
          id?: string
          interested_in_hackathons?: boolean | null
          is_alumni?: boolean
          photo_url?: string | null
          show_photo?: boolean | null
          skills?: string[] | null
          sub_branch?: string | null
          tech_or_non_tech?: string | null
          updated_at?: string
          user_id?: string
          year_of_passout?: number | null
          year_of_study?: number
        }
        Relationships: [
          {
            foreignKeyName: "profiles_college_id_fkey"
            columns: ["college_id"]
            isOneToOne: false
            referencedRelation: "colleges"
            referencedColumns: ["id"]
          },
        ]
      }
      published_papers: {
        Row: {
          abstract: string | null
          author_name: string
          category: string
          college_id: string | null
          created_at: string
          created_by: string
          id: string
          link_url: string | null
          published_date: string
          title: string
          updated_at: string
        }
        Insert: {
          abstract?: string | null
          author_name: string
          category?: string
          college_id?: string | null
          created_at?: string
          created_by: string
          id?: string
          link_url?: string | null
          published_date?: string
          title: string
          updated_at?: string
        }
        Update: {
          abstract?: string | null
          author_name?: string
          category?: string
          college_id?: string | null
          created_at?: string
          created_by?: string
          id?: string
          link_url?: string | null
          published_date?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "published_papers_college_id_fkey"
            columns: ["college_id"]
            isOneToOne: false
            referencedRelation: "colleges"
            referencedColumns: ["id"]
          },
        ]
      }
      site_settings: {
        Row: {
          created_at: string
          id: string
          key: string
          updated_at: string
          value: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          key: string
          updated_at?: string
          value?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          key?: string
          updated_at?: string
          value?: string | null
        }
        Relationships: []
      }
      startup_ideas: {
        Row: {
          ai_clarity_score: number | null
          ai_difficulty: string | null
          ai_evaluated_at: string | null
          ai_feasibility_score: number | null
          ai_innovation: string | null
          ai_market_score: number | null
          ai_overall_score: number | null
          ai_risks: string | null
          ai_strengths: string | null
          ai_suggestions: string | null
          ai_summary: string | null
          category: string | null
          college_id: string | null
          created_at: string
          creator_id: string
          description: string | null
          id: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          ai_clarity_score?: number | null
          ai_difficulty?: string | null
          ai_evaluated_at?: string | null
          ai_feasibility_score?: number | null
          ai_innovation?: string | null
          ai_market_score?: number | null
          ai_overall_score?: number | null
          ai_risks?: string | null
          ai_strengths?: string | null
          ai_suggestions?: string | null
          ai_summary?: string | null
          category?: string | null
          college_id?: string | null
          created_at?: string
          creator_id: string
          description?: string | null
          id?: string
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          ai_clarity_score?: number | null
          ai_difficulty?: string | null
          ai_evaluated_at?: string | null
          ai_feasibility_score?: number | null
          ai_innovation?: string | null
          ai_market_score?: number | null
          ai_overall_score?: number | null
          ai_risks?: string | null
          ai_strengths?: string | null
          ai_suggestions?: string | null
          ai_summary?: string | null
          category?: string | null
          college_id?: string | null
          created_at?: string
          creator_id?: string
          description?: string | null
          id?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "startup_ideas_college_id_fkey"
            columns: ["college_id"]
            isOneToOne: false
            referencedRelation: "colleges"
            referencedColumns: ["id"]
          },
        ]
      }
      startup_join_requests: {
        Row: {
          created_at: string
          id: string
          message: string | null
          startup_id: string
          status: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          message?: string | null
          startup_id: string
          status?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string | null
          startup_id?: string
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "startup_join_requests_startup_id_fkey"
            columns: ["startup_id"]
            isOneToOne: false
            referencedRelation: "startup_ideas"
            referencedColumns: ["id"]
          },
        ]
      }
      startup_messages: {
        Row: {
          content: string
          created_at: string
          id: string
          sender_id: string
          startup_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          sender_id: string
          startup_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          sender_id?: string
          startup_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "startup_messages_startup_id_fkey"
            columns: ["startup_id"]
            isOneToOne: false
            referencedRelation: "startup_ideas"
            referencedColumns: ["id"]
          },
        ]
      }
      student_affiliations: {
        Row: {
          created_at: string
          id: string
          profile_id: string
          role: string
          section_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          profile_id: string
          role?: string
          section_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          profile_id?: string
          role?: string
          section_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_affiliations_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_affiliations_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "content_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      team_invites: {
        Row: {
          created_at: string
          id: string
          invited_by: string
          invited_user_id: string
          status: string
          team_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          invited_by: string
          invited_user_id: string
          status?: string
          team_id: string
        }
        Update: {
          created_at?: string
          id?: string
          invited_by?: string
          invited_user_id?: string
          status?: string
          team_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "team_invites_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "hackathon_teams"
            referencedColumns: ["id"]
          },
        ]
      }
      team_join_requests: {
        Row: {
          created_at: string
          id: string
          status: string
          team_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          status?: string
          team_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          status?: string
          team_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "team_join_requests_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "hackathon_teams"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_db_size: { Args: never; Returns: number }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_super_admin: { Args: { _user_id: string }; Returns: boolean }
      is_valid_university_email: { Args: never; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "student" | "super_admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "student", "super_admin"],
    },
  },
} as const
