import React, { createContext, useContext, useEffect, useState, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { User, Session } from "@supabase/supabase-js";
import type { Tables } from "@/integrations/supabase/types";

type Profile = Tables<"profiles">;

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  isAdmin: boolean;
  isSuperAdmin: boolean;
  loading: boolean;
  collegeId: string | null;
  activeCollegeId: string | null;
  setActiveCollegeId: (id: string | null) => void;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  session: null,
  profile: null,
  isAdmin: false,
  isSuperAdmin: false,
  loading: true,
  collegeId: null,
  activeCollegeId: null,
  setActiveCollegeId: () => {},
  signOut: async () => {},
  refreshProfile: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeCollegeId, setActiveCollegeIdState] = useState<string | null>(null);
  const initialSessionResolved = useRef(false);

  const setActiveCollegeId = (id: string | null) => {
    setActiveCollegeIdState(id);
    if (id) {
      sessionStorage.setItem("activeCollegeId", id);
    } else {
      sessionStorage.removeItem("activeCollegeId");
    }
  };

  const fetchProfile = async (userId: string) => {
    const { data } = await supabase
      .from("profiles")
      .select("*")
      .eq("user_id", userId)
      .maybeSingle();
    setProfile(data);
    return data;
  };

  const checkAdmin = async (userId: string) => {
    const { data: adminData } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    const { data: superData } = await (supabase.rpc as any)("is_super_admin", {
      _user_id: userId,
    });
    const isSA = !!superData;
    setIsAdmin(!!adminData || isSA);
    setIsSuperAdmin(isSA);
    return { isAdmin: !!adminData || isSA, isSuperAdmin: isSA };
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user.id);
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
    setProfile(null);
    setIsAdmin(false);
    setIsSuperAdmin(false);
    setActiveCollegeIdState(null);
    sessionStorage.removeItem("activeCollegeId");
  };

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, newSession) => {
        if (!initialSessionResolved.current) return;

        setSession(newSession);
        setUser(newSession?.user ?? null);

        if (newSession?.user) {
          setTimeout(async () => {
            const prof = await fetchProfile(newSession.user.id);
            const roles = await checkAdmin(newSession.user.id);
            // Set activeCollegeId: restore from session or use profile college
            const stored = sessionStorage.getItem("activeCollegeId");
            if (roles.isSuperAdmin && stored) {
              setActiveCollegeIdState(stored);
            } else if (prof?.college_id) {
              setActiveCollegeIdState(prof.college_id);
            }
            setLoading(false);
          }, 0);
        } else {
          setProfile(null);
          setIsAdmin(false);
          setIsSuperAdmin(false);
          setActiveCollegeIdState(null);
          setLoading(false);
        }
      }
    );

    supabase.auth.getSession().then(async ({ data: { session: initialSession } }) => {
      initialSessionResolved.current = true;
      setSession(initialSession);
      setUser(initialSession?.user ?? null);
      if (initialSession?.user) {
        try {
          const prof = await fetchProfile(initialSession.user.id);
          const roles = await checkAdmin(initialSession.user.id);
          const stored = sessionStorage.getItem("activeCollegeId");
          if (roles.isSuperAdmin && stored) {
            setActiveCollegeIdState(stored);
          } else if (prof?.college_id) {
            setActiveCollegeIdState(prof.college_id);
          }
        } catch (e) {
          console.error("Failed to load profile/roles:", e);
          // Clear stale session on failure
          await supabase.auth.signOut();
          setUser(null);
          setSession(null);
        }
      }
      setLoading(false);
    }).catch(() => {
      // If getSession itself fails (e.g. stale refresh token), clear everything
      initialSessionResolved.current = true;
      setUser(null);
      setSession(null);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  // For super admins, collegeId follows activeCollegeId (the switched college)
  // For regular users, collegeId is always their profile's college
  const collegeId = isSuperAdmin ? (activeCollegeId ?? profile?.college_id ?? null) : (profile?.college_id ?? null);

  return (
    <AuthContext.Provider value={{
      user, session, profile, isAdmin, isSuperAdmin, loading,
      collegeId, activeCollegeId, setActiveCollegeId,
      signOut, refreshProfile
    }}>
      {children}
    </AuthContext.Provider>
  );
};
