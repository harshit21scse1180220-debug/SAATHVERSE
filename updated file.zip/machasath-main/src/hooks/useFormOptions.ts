import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type FormOptionItem = {
  id: string;
  label: string;
  parent_id: string | null;
};

/** Fetch flat list of active labels for a category (non-branch or legacy usage) */
export function useFormOptions(category: string) {
  const [options, setOptions] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase
        .from("form_options")
        .select("label")
        .eq("category", category)
        .eq("is_active", true)
        .is("parent_id", null)
        .order("display_order", { ascending: true });
      setOptions((data || []).map((d: any) => d.label));
      setLoading(false);
    };
    fetch();
  }, [category]);

  return { options, loading };
}

/** Fetch main branches (parent_id is null) */
export function useMainBranches() {
  const [branches, setBranches] = useState<FormOptionItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase
        .from("form_options")
        .select("id, label, parent_id")
        .eq("category", "branch")
        .eq("is_active", true)
        .is("parent_id", null)
        .order("display_order", { ascending: true });
      setBranches((data as FormOptionItem[]) || []);
      setLoading(false);
    };
    fetch();
  }, []);

  return { branches, loading };
}

/** Fetch sub-branches for a given parent branch ID */
export function useSubBranches(parentId: string | null) {
  const [subBranches, setSubBranches] = useState<FormOptionItem[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!parentId) {
      setSubBranches([]);
      return;
    }
    setLoading(true);
    const fetch = async () => {
      const { data } = await supabase
        .from("form_options")
        .select("id, label, parent_id")
        .eq("category", "branch")
        .eq("is_active", true)
        .eq("parent_id", parentId)
        .order("display_order", { ascending: true });
      setSubBranches((data as FormOptionItem[]) || []);
      setLoading(false);
    };
    fetch();
  }, [parentId]);

  return { subBranches, loading };
}
