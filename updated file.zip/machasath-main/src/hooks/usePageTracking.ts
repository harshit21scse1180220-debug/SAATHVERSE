import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { logEvent } from "@/lib/eventLog";

const PAGE_LABELS: Record<string, string> = {
  "/search": "Discover",
  "/alumni": "Alumni",
  "/requests": "Requests",
  "/chat": "Chat",
  "/hackathons": "Hackathons",
  "/my-profile": "My Profile",
  "/admin/dashboard": "Admin Dashboard",
};

export function usePageTracking() {
  const location = useLocation();
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;

    const path = location.pathname;
    const label = PAGE_LABELS[path] || path;

    logEvent(user.id, "page_view", { page: path, label });
  }, [location.pathname, user]);
}
