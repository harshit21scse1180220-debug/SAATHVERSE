import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export interface ContentSectionItem {
  id: string;
  title: string;
  section_type: string;
}

/**
 * Auto-registry hook: dynamically loads all active content sections
 * from the database. Use this instead of hardcoded arrays like
 * SECTION_TARGETS, or to check if a "branch" is actually a content section.
 */
export function useContentSections() {
  const [sections, setSections] = useState<ContentSectionItem[]>([]);
  const [labels, setLabels] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const { collegeId } = useAuth();

  useEffect(() => {
    const fetch = async () => {
      let query = supabase
        .from("content_sections")
        .select("id, title, section_type")
        .eq("is_active", true)
        .order("display_order", { ascending: true });
      if (collegeId) query = query.or(`college_id.eq.${collegeId},college_id.is.null`);
      const { data } = await query;

      const items = (data || []) as ContentSectionItem[];
      setSections(items);
      setLabels(items.map((s) => s.title));
      setLoading(false);
    };
    fetch();
  }, [collegeId]);

  /** Check if a given label is a content section (not a branch) */
  const isContentSection = (label: string) => labels.includes(label);

  /** Get section targets formatted for carousel dropdowns */
  const sectionTargets = sections.map((s) => ({
    value: `section:${s.title.toLowerCase().replace(/\s+/g, "-")}`,
    label: s.title,
  }));

  return { sections, labels, loading, isContentSection, sectionTargets };
}
