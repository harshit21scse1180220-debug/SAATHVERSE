import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export function useSiteSetting(key: string, defaultValue: string = "") {
  const [value, setValue] = useState(defaultValue);

  useEffect(() => {
    supabase
      .from("site_settings")
      .select("value")
      .eq("key", key)
      .maybeSingle()
      .then(({ data }) => {
        if (data?.value) setValue(data.value);
      });
  }, [key]);

  return value;
}

export function useFeaturedTitle() {
  return useSiteSetting("featured_title", "Top Students");
}

export function useLogoUrl() {
  return useSiteSetting("logo_url", "");
}

/** Returns the admin-configured max upload size in KB. Default 200. */
export function useMaxUploadSizeKB(): number {
  const val = useSiteSetting("max_upload_size_kb", "1024");
  const parsed = parseInt(val, 10);
  return isNaN(parsed) ? 1024 : parsed;
}
