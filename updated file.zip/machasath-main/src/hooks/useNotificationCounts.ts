import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export function useNotificationCounts() {
  const { user } = useAuth();
  const [pendingRequests, setPendingRequests] = useState(0);
  const [unreadMessages, setUnreadMessages] = useState(0);

  useEffect(() => {
    if (!user) return;

    const fetchCounts = async () => {
      // Count pending incoming collaboration requests
      const { count: reqCount } = await supabase
        .from("collaboration_requests")
        .select("*", { count: "exact", head: true })
        .eq("receiver_id", user.id)
        .eq("status", "pending");
      setPendingRequests(reqCount || 0);

      // Count unread messages (messages received that have NOT been read)
      const { count: msgCount } = await supabase
        .from("messages")
        .select("*", { count: "exact", head: true })
        .eq("receiver_id", user.id)
        .is("read_at", null);
      setUnreadMessages(msgCount || 0);
    };

    fetchCounts();

    // Subscribe to realtime changes
    const channel = supabase
      .channel("notification-counts")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "collaboration_requests", filter: `receiver_id=eq.${user.id}` },
        () => fetchCounts()
      )
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "messages", filter: `receiver_id=eq.${user.id}` },
        () => fetchCounts()
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "messages", filter: `receiver_id=eq.${user.id}` },
        () => fetchCounts()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  return { pendingRequests, unreadMessages };
}
