import { useState, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { logEvent } from "@/lib/eventLog";

interface MutationOptions<T> {
  /** Human-readable description for toasts and logging */
  successMessage?: string;
  errorMessage?: string;
  /** Log this admin action to event_logs */
  auditAction?: string;
  /** Called after a successful mutation */
  onSuccess?: (data: T) => void;
  /** Called on failure */
  onError?: (error: Error) => void;
  /** If true, log mutation failures to event_logs */
  trackFailures?: boolean;
}

interface MutationResult<T> {
  mutate: () => Promise<T | null>;
  loading: boolean;
  error: Error | null;
}

/**
 * Centralized hook for all Supabase mutations.
 * Ensures proper error handling, user feedback, and audit logging.
 *
 * Usage:
 * ```ts
 * const { mutate, loading } = useSupabaseMutation(
 *   async () => {
 *     const { data, error } = await supabase.from("profiles").update({ bio }).eq("id", id);
 *     if (error) throw error;
 *     return data;
 *   },
 *   { successMessage: "Profile updated", auditAction: "profile_update" }
 * );
 * ```
 */
export function useSupabaseMutation<T = unknown>(
  mutationFn: () => Promise<T>,
  options: MutationOptions<T> = {}
): MutationResult<T> {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const mutate = useCallback(async (): Promise<T | null> => {
    setLoading(true);
    setError(null);
    try {
      const result = await mutationFn();

      // Success toast
      if (options.successMessage) {
        toast({ title: options.successMessage });
      }

      // Audit log
      if (options.auditAction) {
        try {
          const { data: { user } } = await supabase.auth.getUser();
          if (user) {
            await logEvent(user.id, "feature_click", {
              action: options.auditAction,
              type: "admin_action",
              timestamp: new Date().toISOString(),
            });
          }
        } catch {
          // Don't fail the mutation if audit logging fails
        }
      }

      options.onSuccess?.(result);
      return result;
    } catch (err: any) {
      const error = err instanceof Error ? err : new Error(err?.message || "Unknown error");
      setError(error);

      // Error toast
      toast({
        title: options.errorMessage || "Operation failed",
        description: error.message,
        variant: "destructive",
      });

      // Track failure in event_logs
      if (options.trackFailures !== false) {
        try {
          const { data: { user } } = await supabase.auth.getUser();
          if (user) {
            await logEvent(user.id, "feature_click", {
              action: "mutation_failed",
              error: error.message,
              operation: options.auditAction || "unknown",
              timestamp: new Date().toISOString(),
            });
          }
        } catch {
          // Silent
        }
      }

      options.onError?.(error);
      return null;
    } finally {
      setLoading(false);
    }
  }, [mutationFn, options, toast]);

  return { mutate, loading, error };
}

/**
 * One-shot helper for simple mutations that don't need hook lifecycle.
 * Returns { data, error } and shows toasts automatically.
 */
export async function safeMutate<T>(
  fn: () => Promise<{ data: T; error: any }>,
  options: { toast: ReturnType<typeof useToast>["toast"]; successMessage?: string; errorMessage?: string }
): Promise<{ data: T | null; error: any }> {
  try {
    const result = await fn();
    if (result.error) {
      options.toast({
        title: options.errorMessage || "Operation failed",
        description: result.error.message,
        variant: "destructive",
      });
      return { data: null, error: result.error };
    }
    if (options.successMessage) {
      options.toast({ title: options.successMessage });
    }
    return { data: result.data, error: null };
  } catch (err: any) {
    options.toast({
      title: options.errorMessage || "Operation failed",
      description: err.message,
      variant: "destructive",
    });
    return { data: null, error: err };
  }
}
