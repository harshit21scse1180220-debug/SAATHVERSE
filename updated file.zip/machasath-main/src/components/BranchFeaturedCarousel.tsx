import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { ChevronLeft, ChevronRight, ExternalLink, Trophy } from "lucide-react";
import { cn } from "@/lib/utils";
import { useFeaturedTitle } from "@/hooks/useSiteSettings";

type FeaturedStudent = {
  id: string;
  achievement: string | null;
  description: string | null;
  media_url: string | null;
  profile: {
    id: string;
    user_id: string;
    full_name: string;
    photo_url: string | null;
    show_photo: boolean | null;
    skills: string[] | null;
    year_of_study: number;
  };
};

export default function BranchFeaturedCarousel({ branch }: { branch: string }) {
  const navigate = useNavigate();
  const { collegeId } = useAuth();
  const [students, setStudents] = useState<FeaturedStudent[]>([]);
  const [current, setCurrent] = useState(0);
  const featuredTitle = useFeaturedTitle();

  useEffect(() => {
    let query = supabase
      .from("branch_featured_students")
      .select("id, achievement, description, media_url, profile:profiles!inner(id, user_id, full_name, photo_url, show_photo, skills, year_of_study)")
      .eq("branch", branch)
      .eq("is_active", true)
      .order("display_order", { ascending: true });
    if (collegeId) query = query.or(`college_id.eq.${collegeId},college_id.is.null`);
    query.then(({ data }) => {
        if (data && data.length > 0) {
          setStudents(data as unknown as FeaturedStudent[]);
        }
      });
  }, [branch, collegeId]);

  const next = useCallback(() => {
    setCurrent((c) => (c + 1) % students.length);
  }, [students.length]);

  const prev = useCallback(() => {
    setCurrent((c) => (c - 1 + students.length) % students.length);
  }, [students.length]);

  // Auto-slide
  useEffect(() => {
    if (students.length <= 1) return;
    const id = setInterval(next, 4000);
    return () => clearInterval(id);
  }, [next, students.length]);

  if (students.length === 0) return null;

  const student = students[current];
  const profile = student.profile;

  return (
    <div className="mb-6 overflow-hidden rounded-xl border border-border/60 bg-card shadow-sm">
      {/* Header */}
      <div className="flex items-center gap-2 px-4 pt-3 pb-1">
        <Trophy size={14} className="text-primary" />
        <span className="text-[10px] font-bold uppercase tracking-wider text-primary">
          {featuredTitle}
        </span>
      </div>

      <div className="relative h-[200px] sm:h-[220px] md:h-[160px]">
        {/* Mobile: full background image */}
        {(student.media_url || (profile.photo_url && profile.show_photo)) && (
          <div
            className="absolute inset-0 bg-cover bg-center sm:hidden"
            style={{ backgroundImage: `url(${student.media_url || profile.photo_url!})` }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/30" />
          </div>
        )}

        <div className="relative flex h-full">
          {/* Left Arrow */}
          {students.length > 1 && (
            <button
              onClick={prev}
              className="absolute left-2 top-1/2 -translate-y-1/2 z-10 w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm text-white hover:bg-white/30 sm:bg-background/80 sm:border sm:border-border/60 sm:text-muted-foreground sm:hover:text-foreground sm:hover:bg-muted flex items-center justify-center transition-colors shadow-sm"
            >
              <ChevronLeft size={16} />
            </button>
          )}

          {/* Desktop side media */}
          {(student.media_url || (profile.photo_url && profile.show_photo)) && (
            <div className="hidden sm:block w-48 shrink-0">
              <img
                src={student.media_url || profile.photo_url!}
                alt={profile.full_name}
                className="h-full w-full object-cover"
              />
            </div>
          )}

          {/* Content — clickable */}
          <button
            className="flex flex-1 flex-col justify-center gap-2 p-5 text-left hover:bg-muted/30 transition-colors w-full relative z-10"
            onClick={() => navigate(`/profile/${profile.user_id}`)}
          >
          {/* Avatar + Name row */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-muted shrink-0 overflow-hidden border-2 border-white/30 sm:border-primary/20 sm:hidden">
              {(student.media_url || (profile.photo_url && profile.show_photo)) ? (
                <img src={student.media_url || profile.photo_url!} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-sm font-bold text-white/80 sm:text-muted-foreground">
                  {profile.full_name[0]}
                </div>
              )}
            </div>
            <div>
              <h3 className="text-base font-bold text-white sm:text-foreground leading-tight line-clamp-1">
                {profile.full_name}
              </h3>
              <p className="text-xs text-white/70 sm:text-muted-foreground">
                {profile.year_of_study === 0 ? "N/A" : `Year ${profile.year_of_study}`}
                {profile.skills && profile.skills.length > 0 && ` · ${profile.skills.slice(0, 2).join(", ")}`}
              </p>
            </div>
          </div>

          {student.achievement && (
            <p className="text-sm font-semibold text-white sm:text-primary line-clamp-1">
              🏆 {student.achievement}
            </p>
          )}

          {student.description && (
            <p className="text-sm text-white/80 sm:text-muted-foreground line-clamp-2">
              {student.description}
            </p>
          )}

          <span className="inline-flex items-center gap-1 text-xs font-semibold text-white sm:text-primary hover:underline mt-1 w-fit">
            View Profile <ExternalLink size={12} />
          </span>
        </button>

          {/* Right Arrow */}
          {students.length > 1 && (
            <button
              onClick={next}
              className="absolute right-2 top-1/2 -translate-y-1/2 z-10 w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm text-white hover:bg-white/30 sm:bg-background/80 sm:border sm:border-border/60 sm:text-muted-foreground sm:hover:text-foreground sm:hover:bg-muted flex items-center justify-center transition-colors shadow-sm"
            >
              <ChevronRight size={16} />
            </button>
          )}
        </div>
      </div>

      {/* Dots */}
      {students.length > 1 && (
        <div className="flex justify-center gap-1.5 pb-3">
          {students.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrent(i)}
              className={cn(
                "h-1.5 rounded-full transition-all",
                i === current
                  ? "w-5 bg-primary"
                  : "w-1.5 bg-muted-foreground/30 hover:bg-muted-foreground/50"
              )}
            />
          ))}
        </div>
      )}
    </div>
  );
}
