import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  RefreshCw, Database, HardDrive, Users, Activity,
  AlertTriangle, XCircle, CheckCircle2, Loader2, Server,
  Wifi, Shield, Zap, UserPlus
} from "lucide-react";
import { motion } from "framer-motion";
import {
  ChartContainer, ChartTooltip, ChartTooltipContent,
} from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer } from "recharts";

interface ServerStatusData {
  timestamp: string;
  database: { sizeBytes: number; availableBytes: number; percentUsed: number };
  storage: {
    sizeBytes: number; availableBytes: number; percentUsed: number;
    buckets: { name: string; public: boolean }[];
  };
  users: { totalRegistered: number; totalProfiles: number; activeLastWeek: number };
  userCapacity: {
    currentUsers: number; maxSupportedUsers: number;
    remainingSlots: number; maxUploadSizeKB: number;
  };
  serviceHealth: Record<string, { status: string; latencyMs: number }>;
  recentSignups: { week: string; count: number }[];
  alerts: { level: string; message: string }[];
}

function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
}

const healthColor = (status: string) => {
  if (status === "healthy") return "text-emerald-500";
  if (status === "degraded") return "text-amber-500";
  return "text-red-500";
};

const healthBg = (status: string) => {
  if (status === "healthy") return "bg-emerald-500/10 border-emerald-500/20";
  if (status === "degraded") return "bg-amber-500/10 border-amber-500/20";
  return "bg-red-500/10 border-red-500/20";
};

const healthIcon = (status: string) => {
  if (status === "healthy") return <CheckCircle2 size={16} className="text-emerald-500" />;
  if (status === "degraded") return <AlertTriangle size={16} className="text-amber-500" />;
  return <XCircle size={16} className="text-red-500" />;
};

const serviceIcon = (name: string) => {
  const map: Record<string, React.ReactNode> = {
    database: <Database size={16} />,
    authentication: <Shield size={16} />,
    storage: <HardDrive size={16} />,
    realtime: <Wifi size={16} />,
    edge_functions: <Zap size={16} />,
  };
  return map[name] || <Server size={16} />;
};

const serviceName = (key: string) =>
  key.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

export default function AdminServerStatus() {
  const [data, setData] = useState<ServerStatusData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);

  const fetchStatus = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Not authenticated");
      const res = await supabase.functions.invoke("server-status", {
        headers: { Authorization: `Bearer ${session.access_token}` },
      });
      if (res.error) throw res.error;
      setData(res.data as ServerStatusData);
      setLastRefresh(new Date());
    } catch (e: any) {
      setError(e.message || "Failed to fetch server status");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 3 * 60 * 1000); // 3 min auto-refresh
    return () => clearInterval(interval);
  }, [fetchStatus]);

  if (loading && !data) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-3">
        <Loader2 className="animate-spin text-primary" size={32} />
        <p className="text-sm text-muted-foreground">Loading server status...</p>
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-3">
        <XCircle className="text-destructive" size={32} />
        <p className="text-sm text-destructive">{error}</p>
        <Button variant="outline" size="sm" onClick={fetchStatus}>
          <RefreshCw size={14} className="mr-1.5" /> Retry
        </Button>
      </div>
    );
  }

  if (!data) return null;

  const chartConfig = {
    count: { label: "New Users", color: "hsl(var(--primary))" },
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg gradient-navy flex items-center justify-center">
            <Server size={18} className="text-primary-foreground" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-foreground">Server Status</h2>
            <p className="text-xs text-muted-foreground">
              {lastRefresh ? `Last updated: ${lastRefresh.toLocaleTimeString()}` : "Loading..."}
              {loading && <Loader2 size={10} className="inline ml-1 animate-spin" />}
            </p>
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={fetchStatus} disabled={loading} className="gap-1.5">
          <RefreshCw size={14} className={loading ? "animate-spin" : ""} /> Refresh
        </Button>
      </div>

      {/* Alerts */}
      {data.alerts.length > 0 && (
        <div className="space-y-2">
          {data.alerts.map((alert, i) => (
            <div
              key={i}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-sm font-medium ${
                alert.level === "critical"
                  ? "bg-red-500/10 border-red-500/20 text-red-600"
                  : "bg-amber-500/10 border-amber-500/20 text-amber-600"
              }`}
            >
              {alert.level === "critical" ? <XCircle size={14} /> : <AlertTriangle size={14} />}
              {alert.message}
            </div>
          ))}
        </div>
      )}

      {/* Usage Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Database */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Database size={14} /> Database
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-end justify-between">
              <span className="text-2xl font-bold text-foreground">
                {formatBytes(data.database.sizeBytes)}
              </span>
              <span className="text-xs text-muted-foreground">
                / {formatBytes(data.database.availableBytes)}
              </span>
            </div>
            <Progress value={data.database.percentUsed} className="h-2" />
            <p className="text-xs text-muted-foreground">{data.database.percentUsed}% used</p>
          </CardContent>
        </Card>

        {/* Storage */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <HardDrive size={14} /> File Storage
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-end justify-between">
              <span className="text-2xl font-bold text-foreground">
                {formatBytes(data.storage.sizeBytes)}
              </span>
              <span className="text-xs text-muted-foreground">
                / {formatBytes(data.storage.availableBytes)}
              </span>
            </div>
            <Progress value={data.storage.percentUsed} className="h-2" />
            <p className="text-xs text-muted-foreground">
              {data.storage.percentUsed}% used · {data.storage.buckets.length} bucket(s)
            </p>
          </CardContent>
        </Card>

        {/* Users */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Users size={14} /> Users
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            <span className="text-2xl font-bold text-foreground">{data.users.totalRegistered}</span>
            <p className="text-xs text-muted-foreground">Registered accounts</p>
            <div className="flex items-center gap-3 mt-1">
              <Badge variant="secondary" className="text-xs">{data.users.totalProfiles} profiles</Badge>
              <Badge variant="outline" className="text-xs">
                <Activity size={10} className="mr-1" />{data.users.activeLastWeek} active (7d)
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* User Capacity */}
        <Card className="border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <UserPlus size={14} /> User Capacity
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-end justify-between">
              <span className="text-2xl font-bold text-foreground">
                {data.userCapacity.currentUsers}
              </span>
              <span className="text-xs text-muted-foreground">
                / {data.userCapacity.maxSupportedUsers} max
              </span>
            </div>
            <Progress
              value={
                data.userCapacity.maxSupportedUsers > 0
                  ? (data.userCapacity.currentUsers / data.userCapacity.maxSupportedUsers) * 100
                  : 0
              }
              className="h-2"
            />
            <p className="text-xs font-medium text-primary">
              {data.userCapacity.remainingSlots} slots remaining
            </p>
            <p className="text-[10px] text-muted-foreground">
              Based on {data.userCapacity.maxUploadSizeKB}KB per profile photo
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Service Health + Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Service Health */}
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Activity size={14} /> Service Health
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {Object.entries(data.serviceHealth).map(([key, health]) => (
              <div
                key={key}
                className={`flex items-center justify-between px-3 py-2.5 rounded-lg border ${healthBg(health.status)}`}
              >
                <div className="flex items-center gap-2.5">
                  <span className={healthColor(health.status)}>{serviceIcon(key)}</span>
                  <span className="text-sm font-medium text-foreground">{serviceName(key)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">{health.latencyMs}ms</span>
                  {healthIcon(health.status)}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* New Users Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <UserPlus size={14} /> New Users Per Week
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data.recentSignups.length > 0 ? (
              <ChartContainer config={chartConfig} className="h-[200px] w-full">
                <BarChart data={data.recentSignups}>
                  <XAxis
                    dataKey="week"
                    tickFormatter={(v) => {
                      const d = new Date(v);
                      return `${d.getMonth() + 1}/${d.getDate()}`;
                    }}
                    fontSize={11}
                  />
                  <YAxis fontSize={11} allowDecimals={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ChartContainer>
            ) : (
              <div className="flex items-center justify-center h-[200px] text-sm text-muted-foreground">
                No signup data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Storage Buckets Detail */}
      {data.storage.buckets.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <HardDrive size={14} /> Storage Buckets
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {data.storage.buckets.map((bucket) => (
                <div
                  key={bucket.name}
                  className="flex items-center gap-2 px-3 py-2 bg-muted/50 rounded-lg border border-border/40"
                >
                  <HardDrive size={14} className="text-muted-foreground" />
                  <span className="text-sm font-medium text-foreground">{bucket.name}</span>
                  <Badge variant={bucket.public ? "secondary" : "outline"} className="ml-auto text-[10px]">
                    {bucket.public ? "Public" : "Private"}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </motion.div>
  );
}
