import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Brain, X, RefreshCw, TrendingUp, Eye, Target, Lightbulb, AlertTriangle, Sparkles, FileText } from "lucide-react";
import { motion } from "framer-motion";

interface AIReportModalProps {
  idea: {
    title: string;
    ai_overall_score: number | null;
    ai_clarity_score: number | null;
    ai_market_score: number | null;
    ai_feasibility_score: number | null;
    ai_innovation: string | null;
    ai_difficulty: string | null;
    ai_strengths: string | null;
    ai_risks: string | null;
    ai_suggestions: string | null;
    ai_summary: string | null;
    ai_evaluated_at: string | null;
  };
  onClose: () => void;
  onReEvaluate: () => void;
  reEvaluating: boolean;
  canReEvaluate: boolean;
  hoursUntilReEval: number | null;
}

function ScoreCircle({ score, label, icon: Icon }: { score: number | null; label: string; icon: any }) {
  if (score === null) return null;
  const getColor = (s: number) => {
    if (s >= 8) return "text-emerald-500 border-emerald-500/40";
    if (s >= 6) return "text-blue-500 border-blue-500/40";
    if (s >= 4) return "text-orange-500 border-orange-500/40";
    return "text-red-500 border-red-500/40";
  };
  return (
    <div className="flex flex-col items-center gap-1.5">
      <div className={`w-16 h-16 rounded-full border-2 flex items-center justify-center ${getColor(score)}`}>
        <span className="text-lg font-bold">{score.toFixed(1)}</span>
      </div>
      <div className="flex items-center gap-1 text-xs text-muted-foreground">
        <Icon size={10} />
        <span>{label}</span>
      </div>
    </div>
  );
}

function parseJsonArray(val: string | null): string[] {
  if (!val) return [];
  try { return JSON.parse(val); } catch { return []; }
}

export default function AIReportModal({ idea, onClose, onReEvaluate, reEvaluating, canReEvaluate, hoursUntilReEval }: AIReportModalProps) {
  const strengths = parseJsonArray(idea.ai_strengths);
  const risks = parseJsonArray(idea.ai_risks);
  const suggestions = parseJsonArray(idea.ai_suggestions);

  const getScoreColor = (s: number) => {
    if (s >= 8) return "text-emerald-500";
    if (s >= 6) return "text-blue-500";
    if (s >= 4) return "text-orange-500";
    return "text-red-500";
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4" onClick={onClose}>
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-lg max-h-[85vh] overflow-y-auto p-6 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain size={20} className="text-primary" />
            <h3 className="font-bold text-lg text-foreground">AI Startup Evaluation</h3>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
        </div>

        <p className="text-sm text-muted-foreground">{idea.title}</p>

        {/* Overall Score */}
        {idea.ai_overall_score !== null && (
          <div className="flex flex-col items-center py-4">
            <div className={`w-24 h-24 rounded-full border-4 flex items-center justify-center ${
              idea.ai_overall_score >= 8 ? "border-emerald-500/50" :
              idea.ai_overall_score >= 6 ? "border-blue-500/50" :
              idea.ai_overall_score >= 4 ? "border-orange-500/50" : "border-red-500/50"
            }`}>
              <span className={`text-3xl font-extrabold ${getScoreColor(idea.ai_overall_score)}`}>
                {idea.ai_overall_score.toFixed(1)}
              </span>
            </div>
            <p className="text-sm text-muted-foreground mt-2">Overall Score / 10</p>
          </div>
        )}

        {/* Score Breakdown */}
        <div className="grid grid-cols-3 gap-4 justify-items-center">
          <ScoreCircle score={idea.ai_clarity_score} label="Clarity" icon={Eye} />
          <ScoreCircle score={idea.ai_market_score} label="Market" icon={TrendingUp} />
          <ScoreCircle score={idea.ai_feasibility_score} label="Feasibility" icon={Target} />
        </div>

        {/* Innovation & Difficulty */}
        <div className="flex justify-center gap-3">
          {idea.ai_innovation && (
            <Badge variant="secondary" className="text-xs gap-1">
              <Lightbulb size={10} /> Innovation: {idea.ai_innovation}
            </Badge>
          )}
          {idea.ai_difficulty && (
            <Badge variant="outline" className="text-xs gap-1">
              Difficulty: {idea.ai_difficulty}
            </Badge>
          )}
        </div>

        {/* Strengths */}
        {strengths.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
              <Sparkles size={14} /> Strengths
            </h4>
            <ul className="space-y-1">
              {strengths.map((s, i) => (
                <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                  <span className="text-emerald-500 mt-0.5">•</span> {s}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Risks */}
        {risks.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold flex items-center gap-1.5 text-orange-600 dark:text-orange-400">
              <AlertTriangle size={14} /> Risks
            </h4>
            <ul className="space-y-1">
              {risks.map((r, i) => (
                <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                  <span className="text-orange-500 mt-0.5">•</span> {r}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Suggestions */}
        {suggestions.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold flex items-center gap-1.5 text-blue-600 dark:text-blue-400">
              <Lightbulb size={14} /> Suggestions
            </h4>
            <ul className="space-y-1">
              {suggestions.map((s, i) => (
                <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                  <span className="text-blue-500 mt-0.5">•</span> {s}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Summary */}
        {idea.ai_summary && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold flex items-center gap-1.5 text-foreground">
              <FileText size={14} /> Summary
            </h4>
            <p className="text-sm text-muted-foreground leading-relaxed">{idea.ai_summary}</p>
          </div>
        )}

        {/* Evaluated at + Re-evaluate */}
        <div className="flex items-center justify-between pt-2 border-t border-border">
          {idea.ai_evaluated_at && (
            <p className="text-[10px] text-muted-foreground">
              Evaluated: {new Date(idea.ai_evaluated_at).toLocaleDateString()}
            </p>
          )}
          <Button
            size="sm"
            variant="outline"
            onClick={onReEvaluate}
            disabled={reEvaluating || !canReEvaluate}
            className="text-xs gap-1"
          >
            <RefreshCw size={12} className={reEvaluating ? "animate-spin" : ""} />
            {reEvaluating ? "Evaluating..." : canReEvaluate ? "Re-evaluate" : `Wait ${hoursUntilReEval}h`}
          </Button>
        </div>
      </motion.div>
    </div>
  );
}
