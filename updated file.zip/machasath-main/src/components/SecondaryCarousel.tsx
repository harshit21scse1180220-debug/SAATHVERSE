import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import AnnouncementCarousel from "./AnnouncementCarousel";

interface SecondaryCarouselConfig {
  enabled: boolean;
  position: "top" | "middle" | "bottom";
}

const DEFAULT_CONFIG: SecondaryCarouselConfig = {
  enabled: false,
  position: "middle",
};

export function useSecondaryCarouselConfig() {
  const [config, setConfig] = useState<SecondaryCarouselConfig>(DEFAULT_CONFIG);

  useEffect(() => {
    supabase
      .from("site_settings")
      .select("value")
      .eq("key", "secondary_carousel")
      .maybeSingle()
      .then(({ data }) => {
        if (data?.value) {
          try {
            setConfig({ ...DEFAULT_CONFIG, ...JSON.parse(data.value) });
          } catch {}
        }
      });
  }, []);

  return config;
}

export default function SecondaryCarousel({ position }: { position: "top" | "middle" | "bottom" }) {
  const config = useSecondaryCarouselConfig();

  if (!config.enabled || config.position !== position) return null;

  return <AnnouncementCarousel target="secondary" />;
}
