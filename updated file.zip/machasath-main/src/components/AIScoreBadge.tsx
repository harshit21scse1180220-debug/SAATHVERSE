import { Badge } from "@/components/ui/badge";
import { Brain } from "lucide-react";

interface AIScoreBadgeProps {
  score: number | null;
  evaluating?: boolean;
}

export default function AIScoreBadge({ score, evaluating }: AIScoreBadgeProps) {
  if (evaluating) {
    return (
      <Badge variant="outline" className="text-xs gap-1 animate-pulse">
        <Brain size={12} /> AI Evaluating...
      </Badge>
    );
  }

  if (score === null || score === undefined) return null;

  const getColor = (s: number) => {
    if (s >= 8) return "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30";
    if (s >= 6) return "bg-blue-500/15 text-blue-700 dark:text-blue-400 border-blue-500/30";
    if (s >= 4) return "bg-orange-500/15 text-orange-700 dark:text-orange-400 border-orange-500/30";
    return "bg-red-500/15 text-red-700 dark:text-red-400 border-red-500/30";
  };

  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-bold ${getColor(score)}`}>
      <Brain size={12} />
      AI Score: {score.toFixed(1)} / 10
    </span>
  );
}
