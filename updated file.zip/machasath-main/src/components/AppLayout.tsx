import { Link, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Search, Users, MessageCircle, Trophy, UserCircle, Shield, LogOut, Menu, X, GraduationCap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect, useRef } from "react";
import { usePageTracking } from "@/hooks/usePageTracking";
import { useNotificationCounts } from "@/hooks/useNotificationCounts";
import { useLogoUrl } from "@/hooks/useSiteSettings";
import { cn } from "@/lib/utils";
import siteLogo from "@/assets/logo.jpeg";

const desktopNav = [
  { to: "/search", label: "Discover", icon: Search },
  { to: "/alumni", label: "Alumni", icon: GraduationCap },
  { to: "/requests", label: "Requests", icon: Users, badgeKey: "pendingRequests" as const },
  { to: "/chat", label: "Chat", icon: MessageCircle, badgeKey: "unreadMessages" as const },
  { to: "/hackathons", label: "Hackathons", icon: Trophy },
  { to: "/my-profile", label: "Profile", icon: UserCircle },
];

// Mobile nav: Profile first
const mobileNav = [
  { to: "/my-profile", label: "Profile", icon: UserCircle },
  { to: "/search", label: "Discover", icon: Search },
  { to: "/alumni", label: "Alumni", icon: GraduationCap },
  { to: "/requests", label: "Requests", icon: Users, badgeKey: "pendingRequests" as const },
  { to: "/chat", label: "Chat", icon: MessageCircle, badgeKey: "unreadMessages" as const },
  { to: "/hackathons", label: "Hackathons", icon: Trophy },
];

const adminNav = [{ to: "/admin/dashboard", label: "Admin", icon: Shield }];

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const { signOut, isAdmin } = useAuth();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const drawerRef = useRef<HTMLDivElement>(null);
  usePageTracking();
  const { pendingRequests, unreadMessages } = useNotificationCounts();
  const counts = { pendingRequests, unreadMessages };
  const logoUrl = useLogoUrl();
  const desktopItems = [...desktopNav, ...(isAdmin ? adminNav : [])];
  const mobileItems = [...mobileNav, ...(isAdmin ? adminNav : [])];

  // Close drawer on outside click
  useEffect(() => {
    if (!mobileOpen) return;
    const handler = (e: MouseEvent) => {
      if (drawerRef.current && !drawerRef.current.contains(e.target as Node)) {
        setMobileOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [mobileOpen]);

  const renderBadge = (count: number) =>
    count > 0 ? (
      <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold flex items-center justify-center px-1 shadow-sm">
        {count > 99 ? "99+" : count}
      </span>
    ) : null;

  return (
    <div className="min-h-screen bg-background">
      {/* Top nav bar */}
      <header className="sticky top-0 z-50 bg-card/90 backdrop-blur-lg border-b border-border/60 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          {/* Mobile: center logo, hamburger on right */}
          <div className="md:hidden flex-1" />
          <Link to="/search" className="flex items-center gap-2.5 md:flex-none">
            <img src={logoUrl || siteLogo} alt="SaathVerse Logo" className="w-9 h-9 rounded-xl object-cover shadow-md" />
            <span className="text-xl font-extrabold text-foreground tracking-tight">SaathVerse</span>
          </Link>
          <div className="md:hidden flex-1 flex justify-end">
            <button
              className="p-2 rounded-lg hover:bg-muted transition-colors"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              <Menu size={20} />
            </button>
          </div>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-0.5">
            {desktopItems.map((item) => {
              const active = location.pathname === item.to;
              const badgeCount = "badgeKey" in item && item.badgeKey ? counts[item.badgeKey as keyof typeof counts] : 0;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`relative flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    active
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/60"
                  }`}
                >
                  <span className="relative">
                    <item.icon size={16} />
                    {renderBadge(badgeCount)}
                  </span>
                  {item.label}
                </Link>
              );
            })}
            <div className="w-px h-6 bg-border mx-2" />
            <Button
              variant="ghost"
              size="sm"
              onClick={signOut}
              className="text-muted-foreground hover:text-destructive"
            >
              <LogOut size={16} />
            </Button>
          </nav>
        </div>
      </header>

      {/* Mobile slide-in drawer overlay */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" style={{ touchAction: "none" }}>
          <div
            ref={drawerRef}
            className="absolute top-0 left-0 h-full w-72 bg-card shadow-2xl border-r border-border/60 flex flex-col animate-in slide-in-from-left duration-300"
          >
            {/* Drawer header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-border/60">
              <Link to="/search" onClick={() => setMobileOpen(false)} className="flex items-center gap-2.5">
                <img src={logoUrl || siteLogo} alt="SaathVerse Logo" className="w-8 h-8 rounded-xl object-cover shadow-md" />
                <span className="text-lg font-extrabold text-foreground tracking-tight">SaathVerse</span>
              </Link>
              <button
                onClick={() => setMobileOpen(false)}
                className="p-1.5 rounded-lg hover:bg-muted transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            {/* Nav items */}
            <nav className="flex-1 overflow-y-auto p-3 space-y-0.5">
              {mobileItems.map((item) => {
                const active = location.pathname === item.to;
                const badgeCount =
                  "badgeKey" in item && item.badgeKey ? counts[item.badgeKey as keyof typeof counts] : 0;
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    onClick={() => setMobileOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                      active
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted/60"
                    }`}
                  >
                    <span className="relative">
                      <item.icon size={18} />
                      {renderBadge(badgeCount)}
                    </span>
                    {item.label}
                    {badgeCount > 0 && (
                      <span className="ml-auto text-xs font-bold bg-destructive text-destructive-foreground rounded-full px-2 py-0.5">
                        {badgeCount}
                      </span>
                    )}
                  </Link>
                );
              })}
            </nav>

            {/* Sign out */}
            <div className="p-3 border-t border-border/60">
              <button
                onClick={() => {
                  signOut();
                  setMobileOpen(false);
                }}
                className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-destructive hover:bg-muted/60 w-full transition-all"
              >
                <LogOut size={18} />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main content */}
      <main className="max-w-7xl mx-auto px-4 py-8">{children}</main>
    </div>
  );
}
