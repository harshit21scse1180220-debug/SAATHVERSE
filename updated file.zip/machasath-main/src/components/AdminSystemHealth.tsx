import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  CheckCircle2, AlertTriangle, XCircle, RefreshCw, Wrench,
  Activity, Clock, Shield, Loader2, ChevronDown, ChevronUp
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

/* ── Types ── */
type Severity = "ok" | "warning" | "critical";

interface HealthCheck {
  id: string;
  title: string;
  module: string;
  severity: Severity;
  explanation: string;
  suggestedFix: string;
  autoFixable: boolean;
  autoFixFn?: () => Promise<void>;
}

interface ErrorLogEntry {
  timestamp: string;
  errorType: string;
  module: string;
  message: string;
}

const severityIcon = (s: Severity) => {
  if (s === "ok") return <CheckCircle2 size={16} className="text-emerald-500" />;
  if (s === "warning") return <AlertTriangle size={16} className="text-amber-500" />;
  return <XCircle size={16} className="text-red-500" />;
};

const severityBadge = (s: Severity) => {
  const map: Record<Severity, { label: string; cls: string }> = {
    ok: { label: "OK", cls: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20" },
    warning: { label: "Warning", cls: "bg-amber-500/10 text-amber-600 border-amber-500/20" },
    critical: { label: "Critical", cls: "bg-red-500/10 text-red-600 border-red-500/20" },
  };
  const m = map[s];
  return <Badge variant="outline" className={m.cls}>{m.label}</Badge>;
};

/* ── Individual Check Runners ── */

async function checkProfilesNoPhoto(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const { count, error } = await supabase
      .from("profiles").select("*", { count: "exact", head: true }).is("photo_url", null);
    if (error) throw error;
    const n = count ?? 0;
    return {
      id: "profiles_no_photo", title: "Profiles Missing Photo", module: "Profiles",
      severity: n > 5 ? "warning" : "ok",
      explanation: n > 0 ? `${n} profile(s) have no photo uploaded.` : "All profiles have photos.",
      suggestedFix: "Contact students to upload their profile photos.", autoFixable: false,
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "query_error", module: "Profiles", message: e.message });
    return { id: "profiles_no_photo", title: "Profiles Photo Check", module: "Profiles", severity: "critical", explanation: "Failed to query profiles.", suggestedFix: "Check database connectivity.", autoFixable: false };
  }
}

async function checkProfilesEmptyName(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const { count, error } = await supabase
      .from("profiles").select("*", { count: "exact", head: true }).or("full_name.eq.,full_name.is.null");
    if (error) throw error;
    const n = count ?? 0;
    return {
      id: "profiles_empty_name", title: "Profiles with Empty Name", module: "Profiles",
      severity: n > 0 ? "critical" : "ok",
      explanation: n > 0 ? `${n} profile(s) have an empty or null name.` : "All profiles have names.",
      suggestedFix: "Edit profiles to add missing names.", autoFixable: false,
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "query_error", module: "Profiles", message: e.message });
    return { id: "profiles_empty_name", title: "Profiles Name Check", module: "Profiles", severity: "critical", explanation: "Failed to query.", suggestedFix: "Check DB.", autoFixable: false };
  }
}

async function checkDuplicateProfiles(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const { data, error } = await supabase.from("profiles").select("user_id");
    if (error) throw error;
    const counts: Record<string, number> = {};
    (data || []).forEach(p => { counts[p.user_id] = (counts[p.user_id] || 0) + 1; });
    const dupes = Object.entries(counts).filter(([, c]) => c > 1);
    return {
      id: "duplicate_profiles", title: "Duplicate User Profiles", module: "Profiles",
      severity: dupes.length > 0 ? "critical" : "ok",
      explanation: dupes.length > 0 ? `${dupes.length} user(s) have multiple profile rows.` : "No duplicate profiles found.",
      suggestedFix: "Remove duplicate profile rows keeping the latest one.", autoFixable: false,
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "query_error", module: "Profiles", message: e.message });
    return { id: "duplicate_profiles", title: "Duplicate Profile Check", module: "Profiles", severity: "critical", explanation: "Failed.", suggestedFix: "Check DB.", autoFixable: false };
  }
}

async function checkCarouselNoMedia(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const { data, error } = await supabase
      .from("carousel_slides").select("id, title, media_url, is_active").eq("is_active", true).is("media_url", null);
    if (error) throw error;
    const n = data?.length ?? 0;
    return {
      id: "carousel_no_media", title: "Active Slides Without Media", module: "Carousel",
      severity: n > 0 ? "warning" : "ok",
      explanation: n > 0 ? `${n} active slide(s) have no media/image.` : "All active slides have media.",
      suggestedFix: "Upload images or deactivate empty slides.",
      autoFixable: n > 0,
      autoFixFn: async () => {
        const ids = (data ?? []).map(d => d.id);
        if (ids.length === 0) return;
        const { error: ue } = await supabase.from("carousel_slides").update({ is_active: false }).in("id", ids);
        if (ue) throw ue;
      },
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "query_error", module: "Carousel", message: e.message });
    return { id: "carousel_no_media", title: "Carousel Media Check", module: "Carousel", severity: "critical", explanation: "Failed.", suggestedFix: "Check DB.", autoFixable: false };
  }
}

async function checkSectionsNoRows(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const { data: sections, error: se } = await supabase.from("content_sections").select("id, title").eq("is_active", true);
    if (se) throw se;
    const { data: rows, error: re } = await supabase.from("content_rows").select("section_id");
    if (re) throw re;
    const sectionIdsWithRows = new Set((rows ?? []).map(r => r.section_id));
    const orphans = (sections ?? []).filter(s => !sectionIdsWithRows.has(s.id));
    return {
      id: "sections_no_rows", title: "Active Sections Without Content", module: "Content",
      severity: orphans.length > 0 ? "warning" : "ok",
      explanation: orphans.length > 0 ? `${orphans.length} section(s) have no rows: ${orphans.map(o => o.title).join(", ")}` : "All active sections have content rows.",
      suggestedFix: "Add content rows or deactivate empty sections.", autoFixable: false,
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "query_error", module: "Content", message: e.message });
    return { id: "sections_no_rows", title: "Content Check", module: "Content", severity: "critical", explanation: "Failed.", suggestedFix: "Check DB.", autoFixable: false };
  }
}

async function checkSiteSettings(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const requiredKeys = ["logo_url", "featured_title", "max_upload_size_kb"];
    const { data, error } = await supabase.from("site_settings").select("key, value").in("key", requiredKeys);
    if (error) throw error;
    const existingKeys = new Set((data ?? []).map(d => d.key));
    const missing = requiredKeys.filter(k => !existingKeys.has(k));
    const emptyVal = (data ?? []).filter(d => !d.value || d.value.trim() === "");
    return {
      id: "settings_missing", title: "Site Settings Configuration", module: "Settings",
      severity: missing.length > 0 ? "critical" : emptyVal.length > 0 ? "warning" : "ok",
      explanation: missing.length > 0 ? `Missing settings: ${missing.join(", ")}` : emptyVal.length > 0 ? `Empty values for: ${emptyVal.map(e => e.key).join(", ")}` : "All critical settings are configured.",
      suggestedFix: missing.length > 0 ? "Add missing settings via Settings tab." : "Set values for empty settings.",
      autoFixable: missing.length > 0,
      autoFixFn: async () => {
        const defaults: Record<string, string> = { logo_url: "", featured_title: "Top Students", max_upload_size_kb: "1024" };
        for (const key of missing) {
          await supabase.from("site_settings").upsert({ key, value: defaults[key] ?? "" }, { onConflict: "key" });
        }
      },
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "query_error", module: "Settings", message: e.message });
    return { id: "settings_missing", title: "Settings Check", module: "Settings", severity: "critical", explanation: "Failed.", suggestedFix: "Check DB.", autoFixable: false };
  }
}

async function checkExpiredHackathons(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const { data, error } = await supabase
      .from("hackathons").select("id, name, registration_deadline, status")
      .eq("status", "open").lt("registration_deadline", new Date().toISOString());
    if (error) throw error;
    const n = data?.length ?? 0;
    return {
      id: "hackathons_expired", title: "Expired Hackathons Still Open", module: "Hackathons",
      severity: n > 0 ? "warning" : "ok",
      explanation: n > 0 ? `${n} hackathon(s) past deadline but still marked open: ${(data ?? []).map(h => h.name).join(", ")}` : "No expired hackathons are marked open.",
      suggestedFix: "Close or update expired hackathons.",
      autoFixable: n > 0,
      autoFixFn: async () => {
        const ids = (data ?? []).map(d => d.id);
        const { error: ue } = await supabase.from("hackathons").update({ status: "closed" }).in("id", ids);
        if (ue) throw ue;
      },
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "query_error", module: "Hackathons", message: e.message });
    return { id: "hackathons_expired", title: "Hackathons Check", module: "Hackathons", severity: "critical", explanation: "Failed.", suggestedFix: "Check DB.", autoFixable: false };
  }
}

async function checkFeaturedOrphans(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const { data: featured, error: fe } = await supabase
      .from("branch_featured_students").select("id, profile_id, branch").eq("is_active", true);
    if (fe) throw fe;
    if (featured && featured.length > 0) {
      const profileIds = featured.map(f => f.profile_id);
      const { data: profiles, error: pe } = await supabase.from("profiles").select("id").in("id", profileIds);
      if (pe) throw pe;
      const validIds = new Set((profiles ?? []).map(p => p.id));
      const orphaned = featured.filter(f => !validIds.has(f.profile_id));
      return {
        id: "featured_orphan", title: "Featured Students with Missing Profiles", module: "Featured",
        severity: orphaned.length > 0 ? "critical" : "ok",
        explanation: orphaned.length > 0 ? `${orphaned.length} featured student(s) reference deleted profiles.` : "All featured students reference valid profiles.",
        suggestedFix: "Remove or replace orphaned featured student entries.",
        autoFixable: orphaned.length > 0,
        autoFixFn: async () => {
          const ids = orphaned.map(o => o.id);
          const { error: de } = await supabase.from("branch_featured_students").update({ is_active: false }).in("id", ids);
          if (de) throw de;
        },
      };
    }
    return { id: "featured_orphan", title: "Featured Students Integrity", module: "Featured", severity: "ok", explanation: "No active featured students to check or all valid.", suggestedFix: "No action needed.", autoFixable: false };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "query_error", module: "Featured", message: e.message });
    return { id: "featured_orphan", title: "Featured Check", module: "Featured", severity: "critical", explanation: "Failed.", suggestedFix: "Check DB.", autoFixable: false };
  }
}

async function checkStorageAccess(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const { error } = await supabase.storage.from("profile-photos").list("", { limit: 1 });
    return {
      id: "storage_access", title: "Storage Bucket Access", module: "Storage",
      severity: error ? "critical" : "ok",
      explanation: error ? `Cannot access storage: ${error.message}` : "Storage buckets are accessible.",
      suggestedFix: error ? "Check storage configuration and RLS policies." : "No action needed.", autoFixable: false,
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "access_error", module: "Storage", message: e.message });
    return { id: "storage_access", title: "Storage Check", module: "Storage", severity: "critical", explanation: "Failed.", suggestedFix: "Check storage.", autoFixable: false };
  }
}

async function checkDbConnectivity(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const start = Date.now();
    const { error } = await supabase.from("site_settings").select("id", { count: "exact", head: true });
    const latency = Date.now() - start;
    return {
      id: "db_connectivity", title: "Database Connectivity", module: "Database",
      severity: error ? "critical" : latency > 3000 ? "warning" : "ok",
      explanation: error ? `Database error: ${error.message}` : `Database responding (${latency}ms latency).`,
      suggestedFix: error ? "Check database connectivity." : latency > 3000 ? "Investigate slow queries." : "No action needed.", autoFixable: false,
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "connection_error", module: "Database", message: e.message });
    return { id: "db_connectivity", title: "DB Check", module: "Database", severity: "critical", explanation: "Failed.", suggestedFix: "Check DB.", autoFixable: false };
  }
}

async function checkStaleRequests(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const { count, error } = await supabase
      .from("collaboration_requests").select("*", { count: "exact", head: true })
      .eq("status", "pending").lt("created_at", thirtyDaysAgo.toISOString());
    if (error) throw error;
    const n = count ?? 0;
    return {
      id: "stale_requests", title: "Stale Collaboration Requests", module: "Collaboration",
      severity: n > 10 ? "warning" : "ok",
      explanation: n > 0 ? `${n} pending request(s) older than 30 days.` : "No stale requests.",
      suggestedFix: n > 0 ? "Consider notifying users or auto-expiring old requests." : "No action needed.", autoFixable: false,
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "query_error", module: "Collaboration", message: e.message });
    return { id: "stale_requests", title: "Requests Check", module: "Collaboration", severity: "critical", explanation: "Failed.", suggestedFix: "Check DB.", autoFixable: false };
  }
}

/* ── NEW: Deep diagnostics ── */

async function checkAuthFlow(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const { data } = await supabase.auth.getSession();
    return {
      id: "auth_session", title: "Auth Session Active", module: "Auth",
      severity: data.session ? "ok" : "warning",
      explanation: data.session ? "Admin session is active and valid." : "No active auth session detected.",
      suggestedFix: data.session ? "No action needed." : "Re-login to refresh session.", autoFixable: false,
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "auth_error", module: "Auth", message: e.message });
    return { id: "auth_session", title: "Auth Check", module: "Auth", severity: "critical", explanation: "Auth check failed.", suggestedFix: "Check auth configuration.", autoFixable: false };
  }
}

async function checkOnboardingIntegrity(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    // Check for profiles with year_of_study = 0 (often means incomplete onboarding)
    const { count, error } = await supabase
      .from("profiles").select("*", { count: "exact", head: true }).eq("year_of_study", 0);
    if (error) throw error;
    const n = count ?? 0;
    return {
      id: "onboarding_incomplete", title: "Incomplete Onboarding Profiles", module: "Onboarding",
      severity: n > 3 ? "warning" : "ok",
      explanation: n > 0 ? `${n} profile(s) have year_of_study=0 (possibly incomplete onboarding).` : "All profiles appear fully onboarded.",
      suggestedFix: n > 0 ? "Review these profiles and contact users to complete onboarding." : "No action needed.", autoFixable: false,
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "query_error", module: "Onboarding", message: e.message });
    return { id: "onboarding_incomplete", title: "Onboarding Check", module: "Onboarding", severity: "critical", explanation: "Failed.", suggestedFix: "Check DB.", autoFixable: false };
  }
}

async function checkContentCardOrphans(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const { data: cards, error: ce } = await supabase
      .from("content_cards").select("id, row_id").eq("is_active", true);
    if (ce) throw ce;
    const { data: rows, error: re } = await supabase
      .from("content_rows").select("id");
    if (re) throw re;
    const validRowIds = new Set((rows ?? []).map(r => r.id));
    const orphaned = (cards ?? []).filter(c => !validRowIds.has(c.row_id));
    return {
      id: "content_card_orphans", title: "Orphaned Content Cards", module: "Content",
      severity: orphaned.length > 0 ? "warning" : "ok",
      explanation: orphaned.length > 0 ? `${orphaned.length} card(s) reference deleted content rows.` : "All content cards reference valid rows.",
      suggestedFix: "Reassign or remove orphaned content cards.", autoFixable: false,
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "query_error", module: "Content", message: e.message });
    return { id: "content_card_orphans", title: "Content Cards Check", module: "Content", severity: "critical", explanation: "Failed.", suggestedFix: "Check DB.", autoFixable: false };
  }
}

async function checkRecentMutationFailures(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const oneDayAgo = new Date();
    oneDayAgo.setDate(oneDayAgo.getDate() - 1);
    const { data, error } = await supabase
      .from("event_logs")
      .select("metadata")
      .eq("event_type", "feature_click")
      .gte("created_at", oneDayAgo.toISOString())
      .limit(500);
    if (error) throw error;
    const failures = (data ?? []).filter(e => {
      const meta = e.metadata as Record<string, unknown> | null;
      return meta?.action === "mutation_failed";
    });
    return {
      id: "recent_failures", title: "Recent Mutation Failures (24h)", module: "Mutations",
      severity: failures.length > 5 ? "critical" : failures.length > 0 ? "warning" : "ok",
      explanation: failures.length > 0 ? `${failures.length} failed database write(s) in the last 24 hours.` : "No mutation failures detected in the last 24 hours.",
      suggestedFix: failures.length > 0 ? "Check error logs and investigate failing operations." : "No action needed.", autoFixable: false,
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "query_error", module: "Mutations", message: e.message });
    return { id: "recent_failures", title: "Mutation Failures Check", module: "Mutations", severity: "warning", explanation: "Could not check.", suggestedFix: "Check DB.", autoFixable: false };
  }
}

async function checkFormOptionsIntegrity(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const { data, error } = await supabase
      .from("form_options").select("id, label, category, parent_id").eq("is_active", true);
    if (error) throw error;
    // Check for orphaned sub-branches (parent_id references non-existent parent)
    const allIds = new Set((data ?? []).map(d => d.id));
    const orphanedSubs = (data ?? []).filter(d => d.parent_id && !allIds.has(d.parent_id));
    return {
      id: "form_options_integrity", title: "Form Options Integrity", module: "Configuration",
      severity: orphanedSubs.length > 0 ? "warning" : "ok",
      explanation: orphanedSubs.length > 0 ? `${orphanedSubs.length} sub-option(s) reference missing parent options.` : "All form options are correctly linked.",
      suggestedFix: "Fix or remove orphaned sub-options in Form Options management.", autoFixable: false,
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "query_error", module: "Configuration", message: e.message });
    return { id: "form_options_integrity", title: "Form Options Check", module: "Configuration", severity: "critical", explanation: "Failed.", suggestedFix: "Check DB.", autoFixable: false };
  }
}

async function checkStorageQuota(logs: ErrorLogEntry[]): Promise<HealthCheck> {
  try {
    const buckets = ["profile-photos", "carousel-media", "content-media"];
    let totalFiles = 0;
    for (const bucket of buckets) {
      const { data } = await supabase.storage.from(bucket).list("", { limit: 1000 });
      totalFiles += data?.length ?? 0;
    }
    return {
      id: "storage_quota", title: "Storage File Count", module: "Storage",
      severity: totalFiles > 800 ? "warning" : "ok",
      explanation: `${totalFiles} files across all storage buckets.`,
      suggestedFix: totalFiles > 800 ? "Consider cleaning up unused files." : "No action needed.", autoFixable: false,
    };
  } catch (e: any) {
    logs.push({ timestamp: new Date().toISOString(), errorType: "access_error", module: "Storage", message: e.message });
    return { id: "storage_quota", title: "Storage Quota Check", module: "Storage", severity: "warning", explanation: "Could not count files.", suggestedFix: "Check storage access.", autoFixable: false };
  }
}

/* ── Main Component ── */
export default function AdminSystemHealth() {
  const { toast } = useToast();
  const [checks, setChecks] = useState<HealthCheck[]>([]);
  const [errorLogs, setErrorLogs] = useState<ErrorLogEntry[]>([]);
  const [scanning, setScanning] = useState(false);
  const [lastScan, setLastScan] = useState<Date | null>(null);
  const [fixing, setFixing] = useState<string | null>(null);
  const [expandedModules, setExpandedModules] = useState<Set<string>>(new Set());

  const toggleModule = (mod: string) => {
    setExpandedModules(prev => {
      const next = new Set(prev);
      if (next.has(mod)) next.delete(mod); else next.add(mod);
      return next;
    });
  };

  const runChecks = useCallback(async () => {
    setScanning(true);
    const logs: ErrorLogEntry[] = [];

    // Run all checks in parallel
    const results = await Promise.all([
      checkDbConnectivity(logs),
      checkAuthFlow(logs),
      checkProfilesNoPhoto(logs),
      checkProfilesEmptyName(logs),
      checkDuplicateProfiles(logs),
      checkOnboardingIntegrity(logs),
      checkCarouselNoMedia(logs),
      checkSectionsNoRows(logs),
      checkContentCardOrphans(logs),
      checkSiteSettings(logs),
      checkExpiredHackathons(logs),
      checkFeaturedOrphans(logs),
      checkStorageAccess(logs),
      checkStorageQuota(logs),
      checkStaleRequests(logs),
      checkRecentMutationFailures(logs),
      checkFormOptionsIntegrity(logs),
    ]);

    setChecks(results);
    setErrorLogs(prev => [...logs, ...prev].slice(0, 50));
    setLastScan(new Date());
    setScanning(false);
  }, []);

  const handleAutoFix = async (check: HealthCheck) => {
    if (!check.autoFixFn) return;
    setFixing(check.id);
    try {
      await check.autoFixFn();
      toast({ title: "Auto-fix applied", description: `"${check.title}" has been fixed.` });
      await runChecks();
    } catch (e: any) {
      toast({ title: "Auto-fix failed", description: e.message, variant: "destructive" });
    } finally {
      setFixing(null);
    }
  };

  useEffect(() => { runChecks(); }, [runChecks]);
  useEffect(() => {
    const interval = setInterval(runChecks, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [runChecks]);

  const summary = {
    ok: checks.filter(c => c.severity === "ok").length,
    warning: checks.filter(c => c.severity === "warning").length,
    critical: checks.filter(c => c.severity === "critical").length,
  };

  // Group checks by module
  const grouped = checks.reduce<Record<string, HealthCheck[]>>((acc, c) => {
    (acc[c.module] = acc[c.module] || []).push(c);
    return acc;
  }, {});

  const sortedModules = Object.keys(grouped).sort((a, b) => {
    const worstSeverity = (checks: HealthCheck[]) => {
      if (checks.some(c => c.severity === "critical")) return 0;
      if (checks.some(c => c.severity === "warning")) return 1;
      return 2;
    };
    return worstSeverity(grouped[a]) - worstSeverity(grouped[b]);
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
            <Activity size={18} className="text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-foreground">System Health</h2>
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              {lastScan && <><Clock size={10} /> Last scan: {lastScan.toLocaleTimeString()} · </>}
              {checks.length} checks across {Object.keys(grouped).length} modules
            </p>
          </div>
        </div>
        <Button onClick={runChecks} disabled={scanning} size="sm" className="gap-1.5">
          {scanning ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />}
          {scanning ? "Scanning…" : "Run Deep Scan"}
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="border-emerald-500/20">
          <CardContent className="p-4 flex items-center gap-3">
            <CheckCircle2 size={24} className="text-emerald-500" />
            <div>
              <p className="text-2xl font-bold text-foreground">{summary.ok}</p>
              <p className="text-xs text-muted-foreground">Healthy</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-amber-500/20">
          <CardContent className="p-4 flex items-center gap-3">
            <AlertTriangle size={24} className="text-amber-500" />
            <div>
              <p className="text-2xl font-bold text-foreground">{summary.warning}</p>
              <p className="text-xs text-muted-foreground">Warnings</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-red-500/20">
          <CardContent className="p-4 flex items-center gap-3">
            <XCircle size={24} className="text-red-500" />
            <div>
              <p className="text-2xl font-bold text-foreground">{summary.critical}</p>
              <p className="text-xs text-muted-foreground">Critical</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Checks grouped by module */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Health Checks by Module</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <AnimatePresence>
            {scanning && checks.length === 0 ? (
              <div className="flex items-center justify-center py-12 text-muted-foreground">
                <Loader2 size={24} className="animate-spin mr-2" /> Running deep diagnostics…
              </div>
            ) : (
              <div className="divide-y divide-border">
                {sortedModules.map((mod) => {
                  const moduleChecks = grouped[mod];
                  const worstSev = moduleChecks.some(c => c.severity === "critical") ? "critical"
                    : moduleChecks.some(c => c.severity === "warning") ? "warning" : "ok";
                  const isExpanded = expandedModules.has(mod) || worstSev !== "ok";

                  return (
                    <div key={mod}>
                      <button
                        onClick={() => toggleModule(mod)}
                        className="w-full px-4 py-3 flex items-center justify-between hover:bg-muted/30 transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          {severityIcon(worstSev)}
                          <span className="font-medium text-sm text-foreground">{mod}</span>
                          {severityBadge(worstSev)}
                          <Badge variant="secondary" className="text-[10px]">{moduleChecks.length} check{moduleChecks.length > 1 ? "s" : ""}</Badge>
                        </div>
                        {isExpanded ? <ChevronUp size={14} className="text-muted-foreground" /> : <ChevronDown size={14} className="text-muted-foreground" />}
                      </button>

                      {isExpanded && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="border-t border-border/50">
                          {moduleChecks.sort((a, b) => {
                            const order: Record<Severity, number> = { critical: 0, warning: 1, ok: 2 };
                            return order[a.severity] - order[b.severity];
                          }).map((check) => (
                            <div key={check.id} className="px-6 py-3 flex flex-col sm:flex-row sm:items-center gap-2 bg-muted/10">
                              <div className="flex items-start gap-2 flex-1 min-w-0">
                                <div className="mt-0.5">{severityIcon(check.severity)}</div>
                                <div className="min-w-0 flex-1">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span className="text-sm text-foreground">{check.title}</span>
                                    {severityBadge(check.severity)}
                                  </div>
                                  <p className="text-xs text-muted-foreground mt-0.5">{check.explanation}</p>
                                  {check.severity !== "ok" && (
                                    <p className="text-xs text-primary/80 mt-0.5 flex items-center gap-1">
                                      <Wrench size={10} /> {check.suggestedFix}
                                    </p>
                                  )}
                                </div>
                              </div>
                              {check.severity !== "ok" && (
                                <div className="flex items-center gap-2 shrink-0 ml-6 sm:ml-0">
                                  {check.autoFixable ? (
                                    <Button size="sm" variant="outline" className="gap-1.5 text-xs h-7" disabled={fixing === check.id} onClick={() => handleAutoFix(check)}>
                                      {fixing === check.id ? <Loader2 size={12} className="animate-spin" /> : <Wrench size={12} />}
                                      Auto Fix
                                    </Button>
                                  ) : (
                                    <Badge variant="outline" className="text-[10px] border-red-500/20 text-red-500">
                                      <Shield size={10} className="mr-1" /> Manual Fix Required
                                    </Badge>
                                  )}
                                </div>
                              )}
                            </div>
                          ))}
                        </motion.div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>

      {/* Error Logs */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Error Logs</CardTitle>
            <Badge variant="secondary" className="text-xs">{errorLogs.length} entries</Badge>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {errorLogs.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
              <CheckCircle2 size={32} className="mb-2 opacity-30" />
              <p className="text-sm">No errors detected</p>
            </div>
          ) : (
            <ScrollArea className="max-h-[300px]">
              <div className="divide-y divide-border">
                {errorLogs.map((log, i) => (
                  <div key={i} className="px-4 py-3 text-xs">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-muted-foreground font-mono">{new Date(log.timestamp).toLocaleString()}</span>
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-red-500/20 text-red-500">{log.errorType}</Badge>
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0">{log.module}</Badge>
                    </div>
                    <p className="text-muted-foreground">{log.message}</p>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
