import { useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import ProfilePhoto from "./ProfilePhoto";
import type { Tables } from "@/integrations/supabase/types";
import { BookOpen, Calendar } from "lucide-react";

type Profile = Tables<"profiles">;

interface StudentCardProps {
  profile: Profile;
}

export default function StudentCard({ profile }: StudentCardProps) {
  const navigate = useNavigate();

  return (
    <Card
      className="cursor-pointer hover:shadow-lg transition-all duration-200 hover:-translate-y-1 border-border/60 group overflow-hidden"
      onClick={() => navigate(`/profile/${profile.user_id}`)}
    >
      <CardContent className="p-0">
        <div className="h-1 gradient-saffron opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        <div className="p-5">
          <div className="flex items-start gap-4">
            <ProfilePhoto
              fullName={profile.full_name}
              gender={profile.gender}
              photoUrl={profile.photo_url}
              showPhoto={profile.show_photo}
              size="md"
            />
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-foreground truncate text-base">
                {profile.full_name}
              </h3>
              <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                <span className="flex items-center gap-1">
                  <BookOpen size={11} /> {profile.branch}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar size={11} /> {profile.year_of_study === 0 ? "N/A" : `Year ${profile.year_of_study}`}
                </span>
              </div>
              {profile.bio && (
                <p className="text-sm text-muted-foreground mt-2 line-clamp-2 leading-relaxed">
                  {profile.bio}
                </p>
              )}
              {profile.skills && profile.skills.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-2.5">
                  {profile.skills.map((skill) => (
                    <Badge
                      key={skill}
                      variant="secondary"
                      className="text-xs font-medium px-2 py-0.5"
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
