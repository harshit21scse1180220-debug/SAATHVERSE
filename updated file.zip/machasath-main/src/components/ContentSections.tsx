import { useEffect, useState, useRef, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { motion } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";

type Section = {
  id: string;
  title: string;
  section_type: string;
  cover_image_url: string | null;
  description: string | null;
};

const typeBadge: Record<string, { label: string; color: string }> = {
  professional_org: { label: "Professional Org", color: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300" },
  college_club: { label: "College Club", color: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300" },
  entrepreneurship: { label: "Entrepreneurship", color: "bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300" },
  general: { label: "General", color: "bg-muted text-muted-foreground" },
};

export default function ContentSections() {
  const [sections, setSections] = useState<Section[]>([]);
  const { collegeId } = useAuth();
  const navigate = useNavigate();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  useEffect(() => {
    let query = supabase
      .from("content_sections")
      .select("id, title, section_type, cover_image_url, description")
      .eq("is_active", true)
      .order("display_order");
    if (collegeId) query = query.or(`college_id.eq.${collegeId},college_id.is.null`);
    query.then(({ data }) => { if (data) setSections(data); });
  }, [collegeId]);

  const checkScroll = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    setCanScrollLeft(el.scrollLeft > 2);
    setCanScrollRight(el.scrollLeft < el.scrollWidth - el.clientWidth - 2);
  }, []);

  // Re-check scroll state after sections render and on resize
  useEffect(() => {
    if (sections.length === 0) return;
    // Use a small delay to ensure the DOM has rendered
    const timer = setTimeout(checkScroll, 100);
    window.addEventListener("resize", checkScroll);
    return () => {
      clearTimeout(timer);
      window.removeEventListener("resize", checkScroll);
    };
  }, [sections, checkScroll]);

  const scroll = (dir: number) => {
    scrollRef.current?.scrollBy({ left: dir * 320, behavior: "smooth" });
    // Recheck after scroll animation
    setTimeout(checkScroll, 400);
  };

  if (sections.length === 0) return null;

  const isFewSections = sections.length <= 3;

  return (
    <div className="mt-10 relative group">
      {/* Left arrow - always visible on mobile when scrollable */}
      <button
        onClick={() => scroll(-1)}
        aria-label="Scroll left"
        className={`absolute left-1 sm:left-2 top-1/2 -translate-y-1/2 z-10 w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-card/95 border border-border shadow-lg flex items-center justify-center text-foreground hover:bg-card transition-all ${
          canScrollLeft
            ? "opacity-90 sm:opacity-0 sm:group-hover:opacity-100"
            : "opacity-0 pointer-events-none"
        }`}
      >
        <ChevronLeft size={18} />
      </button>

      {/* Right arrow - always visible on mobile when scrollable */}
      <button
        onClick={() => scroll(1)}
        aria-label="Scroll right"
        className={`absolute right-1 sm:right-2 top-1/2 -translate-y-1/2 z-10 w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-card/95 border border-border shadow-lg flex items-center justify-center text-foreground hover:bg-card transition-all ${
          canScrollRight
            ? "opacity-90 sm:opacity-0 sm:group-hover:opacity-100"
            : "opacity-0 pointer-events-none"
        }`}
      >
        <ChevronRight size={18} />
      </button>

      <div
        ref={scrollRef}
        onScroll={checkScroll}
        className={`flex gap-5 overflow-x-auto scrollbar-hide pb-2 snap-x snap-mandatory ${isFewSections ? "justify-center" : ""}`}
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {sections.map((section, i) => {
          const badge = typeBadge[section.section_type] || typeBadge.general;
          return (
            <motion.div
              key={section.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08, duration: 0.35 }}
              onClick={() => navigate(section.section_type === "entrepreneurship" ? "/startups" : `/section/${section.id}`)}
              className="shrink-0 w-[280px] sm:w-[320px] cursor-pointer group/card rounded-2xl border border-border/60 bg-card overflow-hidden hover:border-primary/40 hover:shadow-lg transition-all duration-300 snap-start"
            >
              {section.cover_image_url ? (
                <div className="relative aspect-[16/9] overflow-hidden">
                  <img
                    src={section.cover_image_url}
                    alt={section.title}
                    className="w-full h-full object-cover group-hover/card:scale-105 transition-transform duration-300"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  <div className="absolute bottom-3 left-4">
                    <span className={`text-[10px] uppercase tracking-widest font-bold px-2.5 py-1 rounded-full ${badge.color}`}>
                      {badge.label}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="aspect-[16/9] bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center">
                  <span className="text-4xl font-extrabold text-muted-foreground/20">{section.title[0]}</span>
                </div>
              )}
              <div className="p-4">
                <h3 className="text-lg font-bold text-foreground tracking-tight group-hover/card:text-primary transition-colors">
                  {section.title}
                </h3>
                {section.description && (
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{section.description}</p>
                )}
                {!section.cover_image_url && (
                  <span className={`mt-2 inline-block text-[10px] uppercase tracking-widest font-bold px-2.5 py-1 rounded-full ${badge.color}`}>
                    {badge.label}
                  </span>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
