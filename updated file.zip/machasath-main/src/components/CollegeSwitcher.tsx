import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Building2, ShieldCheck } from "lucide-react";
import type { Tables } from "@/integrations/supabase/types";

type College = Tables<"colleges">;

export default function CollegeSwitcher() {
  const { isSuperAdmin, activeCollegeId, setActiveCollegeId, isAdmin } = useAuth();
  const [colleges, setColleges] = useState<College[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchColleges = async () => {
      const { data } = await supabase.from("colleges").select("*").order("name");
      setColleges(data || []);
      setLoading(false);
    };
    if (isSuperAdmin) fetchColleges();
    else setLoading(false);
  }, [isSuperAdmin]);

  if (!isAdmin) return null;

  const activeCollege = colleges.find(c => c.id === activeCollegeId);

  return (
    <div className="flex items-center gap-2">
      {isSuperAdmin ? (
        <>
          <Badge variant="outline" className="text-[10px] gap-1 shrink-0 border-primary/30 text-primary">
            <ShieldCheck size={10} /> Super Admin
          </Badge>
          {!loading && colleges.length > 0 && (
            <Select
              value={activeCollegeId || "all"}
              onValueChange={(v) => setActiveCollegeId(v === "all" ? null : v)}
            >
              <SelectTrigger className="h-8 text-xs max-w-[200px] gap-1">
                <Building2 size={12} className="shrink-0" />
                <SelectValue placeholder="All Colleges" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Colleges</SelectItem>
                {colleges.map(c => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </>
      ) : (
        <Badge variant="secondary" className="text-[10px] gap-1 shrink-0">
          <Building2 size={10} /> College Admin
          {activeCollege && <span className="ml-1">· {activeCollege.name}</span>}
        </Badge>
      )}
    </div>
  );
}
