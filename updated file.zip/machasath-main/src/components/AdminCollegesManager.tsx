import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { mapErrorMessage } from "@/lib/errorMessages";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Plus, Trash2, Edit2, X, Building2, Globe, Palette, Users, ExternalLink } from "lucide-react";
import { useNavigate } from "react-router-dom";
import type { Tables } from "@/integrations/supabase/types";

type College = Tables<"colleges">;

interface CollegeStats {
  college_id: string;
  profile_count: number;
  admin_count: number;
}

export default function AdminCollegesManager() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [colleges, setColleges] = useState<College[]>([]);
  const [stats, setStats] = useState<CollegeStats[]>([]);
  const [loading, setLoading] = useState(true);

  // Add form
  const [showAdd, setShowAdd] = useState(false);
  const [name, setName] = useState("");
  const [domain, setDomain] = useState("");
  const [logoUrl, setLogoUrl] = useState("");
  const [primaryColor, setPrimaryColor] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // Edit
  const [editing, setEditing] = useState<College | null>(null);
  const [editForm, setEditForm] = useState({ name: "", domain: "", logo_url: "", primary_color: "" });

  const fetchColleges = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("colleges")
      .select("*")
      .order("created_at", { ascending: true });
    if (data) setColleges(data);
    setLoading(false);
  };

  const fetchStats = async () => {
    // Get profile counts per college
    const { data: profiles } = await supabase
      .from("profiles")
      .select("college_id");

    if (profiles) {
      const countMap: Record<string, number> = {};
      profiles.forEach((p) => {
        if (p.college_id) {
          countMap[p.college_id] = (countMap[p.college_id] || 0) + 1;
        }
      });
      setStats(
        Object.entries(countMap).map(([college_id, profile_count]) => ({
          college_id,
          profile_count,
          admin_count: 0,
        }))
      );
    }
  };

  useEffect(() => {
    fetchColleges();
    fetchStats();
  }, []);

  const handleAdd = async () => {
    if (!name.trim() || !domain.trim()) return;
    setSubmitting(true);
    const { error } = await supabase.from("colleges").insert({
      name: name.trim(),
      domain: domain.trim().toLowerCase().replace(/^@/, ""),
      logo_url: logoUrl.trim() || null,
      primary_color: primaryColor.trim() || null,
    });
    if (error) {
      toast({ title: "Error", description: mapErrorMessage(error), variant: "destructive" });
    } else {
      toast({ title: "College added" });
      setName(""); setDomain(""); setLogoUrl(""); setPrimaryColor("");
      setShowAdd(false);
      fetchColleges();
    }
    setSubmitting(false);
  };

  const startEdit = (c: College) => {
    setEditing(c);
    setEditForm({
      name: c.name,
      domain: c.domain,
      logo_url: c.logo_url || "",
      primary_color: c.primary_color || "",
    });
  };

  const saveEdit = async () => {
    if (!editing) return;
    const { error } = await supabase
      .from("colleges")
      .update({
        name: editForm.name.trim(),
        domain: editForm.domain.trim().toLowerCase().replace(/^@/, ""),
        logo_url: editForm.logo_url.trim() || null,
        primary_color: editForm.primary_color.trim() || null,
      })
      .eq("id", editing.id);
    if (error) {
      toast({ title: "Error", description: mapErrorMessage(error), variant: "destructive" });
    } else {
      toast({ title: "College updated" });
      setEditing(null);
      fetchColleges();
    }
  };

  const deleteCollege = async (c: College) => {
    const stat = stats.find((s) => s.college_id === c.id);
    const count = stat?.profile_count || 0;
    if (count > 0) {
      toast({
        title: "Cannot delete",
        description: `This college has ${count} profile(s). Remove them first.`,
        variant: "destructive",
      });
      return;
    }
    if (!confirm(`Delete "${c.name}"? This cannot be undone.`)) return;
    const { error } = await supabase.from("colleges").delete().eq("id", c.id);
    if (error) {
      toast({ title: "Error", description: mapErrorMessage(error), variant: "destructive" });
    } else {
      toast({ title: "College deleted" });
      fetchColleges();
    }
  };

  const getProfileCount = (id: string) => stats.find((s) => s.college_id === id)?.profile_count || 0;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-foreground">Registered Colleges</h2>
        <Button size="sm" onClick={() => setShowAdd(!showAdd)} className="gap-1.5">
          <Plus size={14} /> Add College
        </Button>
      </div>

      {/* Add form */}
      {showAdd && (
        <div className="p-4 bg-card rounded-xl border border-border/60 shadow-sm mb-6 space-y-3">
          <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <Building2 size={14} /> New College
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label className="text-xs">College Name *</Label>
              <Input placeholder="e.g. Galgotias University" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Email Domain *</Label>
              <Input placeholder="e.g. galgotiasuniversity.edu.in" value={domain} onChange={(e) => setDomain(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Logo URL</Label>
              <Input placeholder="https://..." value={logoUrl} onChange={(e) => setLogoUrl(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Primary Color (HSL)</Label>
              <Input placeholder="e.g. 222.2 47.4% 11.2%" value={primaryColor} onChange={(e) => setPrimaryColor(e.target.value)} />
            </div>
          </div>
          <div className="flex gap-2">
            <Button onClick={handleAdd} disabled={submitting || !name.trim() || !domain.trim()} size="sm">
              {submitting ? "Adding..." : "Add College"}
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setShowAdd(false)}>Cancel</Button>
          </div>
        </div>
      )}

      {/* Edit modal */}
      {editing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-card rounded-2xl border border-border/60 shadow-xl p-6 w-full max-w-md space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-foreground">Edit College</h3>
              <button onClick={() => setEditing(null)} className="p-1 rounded-full hover:bg-muted"><X size={18} /></button>
            </div>
            <div className="space-y-3">
              <div className="space-y-1">
                <Label className="text-xs">College Name</Label>
                <Input value={editForm.name} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Email Domain</Label>
                <Input value={editForm.domain} onChange={(e) => setEditForm({ ...editForm, domain: e.target.value })} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Logo URL</Label>
                <Input value={editForm.logo_url} onChange={(e) => setEditForm({ ...editForm, logo_url: e.target.value })} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Primary Color (HSL)</Label>
                <Input value={editForm.primary_color} onChange={(e) => setEditForm({ ...editForm, primary_color: e.target.value })} />
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" size="sm" onClick={() => setEditing(null)}>Cancel</Button>
              <Button size="sm" onClick={saveEdit}>Save</Button>
            </div>
          </div>
        </div>
      )}

      {/* College list */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2].map((i) => <div key={i} className="h-20 bg-muted/50 rounded-xl animate-pulse" />)}
        </div>
      ) : colleges.length === 0 ? (
        <p className="text-center text-muted-foreground py-8">No colleges registered yet</p>
      ) : (
        <div className="space-y-3">
          {colleges.map((c) => (
            <div key={c.id} className="flex items-center gap-4 p-4 bg-card rounded-xl border border-border/60">
              {c.logo_url ? (
                <img src={c.logo_url} alt={c.name} className="w-10 h-10 rounded-lg object-cover shrink-0" />
              ) : (
                <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center shrink-0">
                  <Building2 size={18} className="text-muted-foreground" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">{c.name}</p>
                <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                  <span className="flex items-center gap-1"><Globe size={12} /> {c.domain}</span>
                  <span className="flex items-center gap-1"><Users size={12} /> {getProfileCount(c.id)} users</span>
                  {c.primary_color && (
                    <span className="flex items-center gap-1">
                      <Palette size={12} />
                      <span className="w-3 h-3 rounded-full border border-border" style={{ backgroundColor: `hsl(${c.primary_color})` }} />
                    </span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => startEdit(c)}>
                  <Edit2 size={14} />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => deleteCollege(c)}>
                  <Trash2 size={14} />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 gap-1.5 ml-1"
                  onClick={() => navigate(`/admin/college/${c.id}`)}
                >
                  <ExternalLink size={14} /> Manage
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Summary */}
      <div className="mt-6 p-4 bg-muted/30 rounded-xl border border-border/40">
        <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-2">Summary</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">{colleges.length}</p>
            <p className="text-xs text-muted-foreground">Colleges</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">{stats.reduce((sum, s) => sum + s.profile_count, 0)}</p>
            <p className="text-xs text-muted-foreground">Total Users</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">{colleges.filter((c) => getProfileCount(c.id) === 0).length}</p>
            <p className="text-xs text-muted-foreground">Empty Colleges</p>
          </div>
        </div>
      </div>
    </div>
  );
}
