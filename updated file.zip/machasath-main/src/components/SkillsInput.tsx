import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { X } from "lucide-react";

interface SkillsInputProps {
  skills: string[];
  onChange: (skills: string[]) => void;
  maxSkills?: number;
  disabled?: boolean;
}

export default function SkillsInput({ skills, onChange, maxSkills = 3, disabled = false }: SkillsInputProps) {
  const [inputValue, setInputValue] = useState("");

  const addSkill = (value: string) => {
    const trimmed = value.trim();
    if (!trimmed) return;
    if (trimmed.length > 30) return;
    if (skills.length >= maxSkills) return;
    if (skills.some((s) => s.toLowerCase() === trimmed.toLowerCase())) return;
    onChange([...skills, trimmed]);
    setInputValue("");
  };

  const removeSkill = (index: number) => {
    onChange(skills.filter((_, i) => i !== index));
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      addSkill(inputValue);
    }
    if (e.key === "Backspace" && !inputValue && skills.length > 0) {
      removeSkill(skills.length - 1);
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-2">
        {skills.map((skill, i) => (
          <Badge
            key={i}
            variant="secondary"
            className="gap-1 pr-1 text-sm font-medium"
          >
            {skill}
            {!disabled && (
              <button
                type="button"
                onClick={() => removeSkill(i)}
                className="ml-1 rounded-full p-0.5 hover:bg-foreground/10 transition-colors"
              >
                <X size={12} />
              </button>
            )}
          </Badge>
        ))}
      </div>
      {!disabled && skills.length < maxSkills && (
        <Input
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={handleKeyDown}
          onBlur={() => addSkill(inputValue)}
          placeholder={skills.length === 0 ? "Type a skill and press Enter..." : `Add ${maxSkills - skills.length} more...`}
          maxLength={30}
          className="text-sm"
        />
      )}
      {!disabled && (
        <p className="text-xs text-muted-foreground">
          {skills.length}/{maxSkills} skills · Press Enter or comma to add
        </p>
      )}
    </div>
  );
}
