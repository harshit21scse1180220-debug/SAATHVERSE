import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { ChevronLeft, ChevronRight, ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";

type Slide = {
  id: string;
  title: string;
  description: string | null;
  hyperlink: string | null;
  hyperlink_text: string | null;
  media_url: string | null;
  category: string;
};

interface AnnouncementCarouselProps {
  target?: string;
}

const SLIDE_HEIGHT = "h-[280px] sm:h-[320px] md:h-[280px]";

export default function AnnouncementCarousel({ target }: AnnouncementCarouselProps) {
  const { collegeId } = useAuth();
  const [slides, setSlides] = useState<Slide[]>([]);
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    let query = supabase
      .from("carousel_slides")
      .select("id, title, description, hyperlink, hyperlink_text, media_url, category")
      .eq("is_active", true)
      .order("display_order", { ascending: true });

    if (target) {
      query = query.eq("branch", target);
    } else {
      query = query.is("branch", null);
    }

    if (collegeId) {
      query = query.or(`college_id.eq.${collegeId},college_id.is.null`);
    }

    query.then(({ data }) => {
      if (data && data.length > 0) setSlides(data);
    });
  }, [target, collegeId]);

  const prev = useCallback(() => {
    setCurrent((c) => (c - 1 + slides.length) % slides.length);
  }, [slides.length]);

  const next = useCallback(() => {
    setCurrent((c) => (c + 1) % slides.length);
  }, [slides.length]);

  useEffect(() => {
    if (slides.length <= 1) return;
    const id = setInterval(next, 4000);
    return () => clearInterval(id);
  }, [next, slides.length]);

  if (slides.length === 0) return null;

  const slide = slides[current];
  const isBanner = slide.category === "banner";

  const categoryColor: Record<string, string> = {
    hackathon: "bg-secondary text-secondary-foreground",
    result: "bg-destructive/10 text-destructive",
    event: "bg-primary/10 text-primary",
    update: "bg-accent/10 text-accent-foreground",
    banner: "bg-primary/10 text-primary",
  };

  const NavArrows = ({ light }: { light?: boolean }) =>
    slides.length > 1 ? (
      <>
        <button
          onClick={prev}
          className={cn(
            "absolute left-2 top-1/2 -translate-y-1/2 z-20 w-8 h-8 rounded-full flex items-center justify-center transition-colors",
            light
              ? "bg-white/20 backdrop-blur-sm text-white hover:bg-white/30"
              : "bg-background/80 border border-border/60 text-muted-foreground hover:text-foreground hover:bg-muted shadow-sm"
          )}
        >
          <ChevronLeft size={16} />
        </button>
        <button
          onClick={next}
          className={cn(
            "absolute right-2 top-1/2 -translate-y-1/2 z-20 w-8 h-8 rounded-full flex items-center justify-center transition-colors",
            light
              ? "bg-white/20 backdrop-blur-sm text-white hover:bg-white/30"
              : "bg-background/80 border border-border/60 text-muted-foreground hover:text-foreground hover:bg-muted shadow-sm"
          )}
        >
          <ChevronRight size={16} />
        </button>
      </>
    ) : null;

  const Dots = ({ light }: { light?: boolean }) =>
    slides.length > 1 ? (
      <div className={cn("flex justify-center gap-1.5", light ? "absolute bottom-2 left-1/2 -translate-x-1/2 z-20" : "pb-3")}>
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className={cn(
              "h-1.5 rounded-full transition-all",
              i === current
                ? light ? "w-5 bg-white" : "w-5 bg-primary"
                : light ? "w-1.5 bg-white/40 hover:bg-white/60" : "w-1.5 bg-muted-foreground/30 hover:bg-muted-foreground/50"
            )}
          />
        ))}
      </div>
    ) : null;

  // Banner slide — full-bleed background image
  if (isBanner && slide.media_url) {
    return (
      <div className="mb-6">
        <div className={cn("relative w-full rounded-xl overflow-hidden", SLIDE_HEIGHT)}>
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${slide.media_url})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/30 to-transparent" />

          <div className="absolute inset-0 flex flex-col justify-end p-5 sm:p-6 z-10">
            {slide.title && (
              <h3 className="text-lg sm:text-xl font-bold text-white leading-tight line-clamp-1 drop-shadow-md">
                {slide.title}
              </h3>
            )}
            {slide.description && (
              <p className="text-sm text-white/80 line-clamp-2 mt-1 drop-shadow-sm">
                {slide.description}
              </p>
            )}
            {slide.hyperlink && (
              <a
                href={slide.hyperlink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-xs font-semibold text-white hover:underline mt-2 w-fit drop-shadow-sm"
              >
                {slide.hyperlink_text || "Learn more"} <ExternalLink size={12} />
              </a>
            )}
          </div>

          <NavArrows light />
          <Dots light />
        </div>
      </div>
    );
  }

  // Default card layout — on mobile, use media as background
  const hasMedia = !!slide.media_url;

  return (
    <div className="mb-6 overflow-hidden rounded-xl border border-border/60 bg-card shadow-sm">
      <div className={cn("relative", SLIDE_HEIGHT)}>
        {/* Mobile: full background image */}
        {hasMedia && (
          <div
            className="absolute inset-0 bg-cover bg-center sm:hidden"
            style={{ backgroundImage: `url(${slide.media_url})` }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/30" />
          </div>
        )}

        <div className="relative flex h-full">
          <NavArrows />

          {hasMedia && (
            <div className="hidden sm:block w-48 shrink-0">
              <img
                src={slide.media_url!}
                alt={slide.title}
                className="h-full w-full object-cover"
              />
            </div>
          )}

          <div className={cn("flex flex-1 flex-col justify-center gap-2 p-5 relative z-10", hasMedia ? "text-white sm:text-foreground" : "")}>
            <div className="flex items-center gap-2">
              <span
                className={cn(
                  "rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider",
                  categoryColor[slide.category] ?? categoryColor.update
                )}
              >
                {slide.category}
              </span>
            </div>

            <h3 className={cn("text-base font-bold leading-tight line-clamp-1", hasMedia ? "text-white sm:text-foreground" : "text-foreground")}>
              {slide.title}
            </h3>

            {slide.description && (
              <p className={cn("text-sm line-clamp-2", hasMedia ? "text-white/80 sm:text-muted-foreground" : "text-muted-foreground")}>
                {slide.description}
              </p>
            )}

            {slide.hyperlink && (
              <a
                href={slide.hyperlink}
                target="_blank"
                rel="noopener noreferrer"
                className={cn("inline-flex items-center gap-1 text-xs font-semibold hover:underline mt-1 w-fit", hasMedia ? "text-white sm:text-primary" : "text-primary")}
              >
                {slide.hyperlink_text || "Learn more"} <ExternalLink size={12} />
              </a>
            )}
          </div>
        </div>
      </div>

      <Dots />
    </div>
  );
}
