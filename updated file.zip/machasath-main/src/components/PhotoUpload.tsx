import { useState, useRef } from "react";
import { Camera, X, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface PhotoUploadProps {
  onFileSelect: (file: File | null) => void;
  maxSizeKB?: number;
}

const MAX_SIZE_DEFAULT = 1024;

export default function PhotoUpload({ onFileSelect, maxSizeKB = MAX_SIZE_DEFAULT }: PhotoUploadProps) {
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError(null);

    if (!file.type.startsWith("image/")) {
      setError("Please select an image file");
      return;
    }

    if (file.size > maxSizeKB * 1024) {
      setError(`File must be under ${maxSizeKB}KB`);
      return;
    }

    const url = URL.createObjectURL(file);
    setPreview(url);
    onFileSelect(file);
  };

  const handleRemove = () => {
    setPreview(null);
    setError(null);
    onFileSelect(null);
    if (inputRef.current) inputRef.current.value = "";
  };

  return (
    <div className="space-y-2">
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        onChange={handleFile}
        className="hidden"
      />

      {preview ? (
        <div className="relative w-20 h-20 mx-auto">
          <img
            src={preview}
            alt="Preview"
            className="w-20 h-20 rounded-full object-cover ring-2 ring-border/30"
          />
          <button
            type="button"
            onClick={handleRemove}
            className="absolute -top-1 -right-1 w-6 h-6 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center shadow-md"
          >
            <X size={12} />
          </button>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className={cn(
            "w-20 h-20 mx-auto rounded-full border-2 border-dashed border-border",
            "flex flex-col items-center justify-center gap-1 cursor-pointer",
            "hover:border-primary/50 hover:bg-muted/50 transition-colors"
          )}
        >
          <Camera size={20} className="text-muted-foreground" />
          <span className="text-[10px] text-muted-foreground">Photo</span>
        </button>
      )}

      {error && (
        <p className="text-xs text-destructive flex items-center justify-center gap-1">
          <AlertCircle size={12} /> {error}
        </p>
      )}

      <p className="text-[10px] text-muted-foreground text-center">
        JPG, PNG or WebP · Max {maxSizeKB}KB
      </p>
    </div>
  );
}
