import { useState, useRef, useCallback } from "react";
import ReactCrop, { type Crop, centerCrop, makeAspectCrop } from "react-image-crop";
import "react-image-crop/dist/ReactCrop.css";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Crop as CropIcon, ZoomIn } from "lucide-react";

export type ImageType = "banner" | "carousel" | "profile" | "cover" | "thumbnail";

const ASPECT_RATIOS: Record<ImageType, number> = {
  banner: 16 / 6,
  carousel: 4 / 3,
  profile: 1,
  cover: 16 / 9,
  thumbnail: 4 / 3,
};

const MAX_WIDTHS: Record<ImageType, number> = {
  banner: 1600,
  carousel: 800,
  profile: 400,
  cover: 1280,
  thumbnail: 800,
};

const TYPE_LABELS: Record<ImageType, string> = {
  banner: "Banner (16:6)",
  carousel: "Card (4:3)",
  profile: "Profile (1:1)",
  cover: "Cover (16:9)",
  thumbnail: "Thumbnail (4:3)",
};

interface ImageCropperProps {
  imageType: ImageType;
  onCropped: (file: File) => void;
  onCancel: () => void;
  file: File;
}

function centerAspectCrop(mediaWidth: number, mediaHeight: number, aspect: number): Crop {
  return centerCrop(
    makeAspectCrop({ unit: "%", width: 90 }, aspect, mediaWidth, mediaHeight),
    mediaWidth,
    mediaHeight
  );
}

async function getCroppedBlob(
  image: HTMLImageElement,
  crop: Crop,
  maxWidth: number
): Promise<Blob> {
  const canvas = document.createElement("canvas");
  const scaleX = image.naturalWidth / image.width;
  const scaleY = image.naturalHeight / image.height;

  const pixelCrop = {
    x: (crop.unit === "%" ? (crop.x / 100) * image.width : crop.x) * scaleX,
    y: (crop.unit === "%" ? (crop.y / 100) * image.height : crop.y) * scaleY,
    width: (crop.unit === "%" ? (crop.width / 100) * image.width : crop.width) * scaleX,
    height: (crop.unit === "%" ? (crop.height / 100) * image.height : crop.height) * scaleY,
  };

  let outW = pixelCrop.width;
  let outH = pixelCrop.height;
  if (outW > maxWidth) {
    const ratio = maxWidth / outW;
    outW = maxWidth;
    outH = outH * ratio;
  }

  canvas.width = outW;
  canvas.height = outH;
  const ctx = canvas.getContext("2d")!;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(image, pixelCrop.x, pixelCrop.y, pixelCrop.width, pixelCrop.height, 0, 0, outW, outH);

  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error("Canvas crop failed"))),
      "image/jpeg",
      0.85
    );
  });
}

export default function ImageCropper({ imageType, onCropped, onCancel, file }: ImageCropperProps) {
  const aspect = ASPECT_RATIOS[imageType];
  const maxWidth = MAX_WIDTHS[imageType];
  const [crop, setCrop] = useState<Crop>();
  const [zoom, setZoom] = useState(1);
  const [saving, setSaving] = useState(false);
  const imgRef = useRef<HTMLImageElement>(null);
  const [imgSrc] = useState(() => URL.createObjectURL(file));

  const onImageLoad = useCallback(
    (e: React.SyntheticEvent<HTMLImageElement>) => {
      const { width, height } = e.currentTarget;
      setCrop(centerAspectCrop(width, height, aspect));
    },
    [aspect]
  );

  const handleConfirm = async () => {
    if (!imgRef.current || !crop) return;
    setSaving(true);
    try {
      const blob = await getCroppedBlob(imgRef.current, crop, maxWidth);
      const croppedFile = new File([blob], file.name.replace(/\.\w+$/, ".jpg"), { type: "image/jpeg" });
      onCropped(croppedFile);
    } catch {
      // fallback: pass original
      onCropped(file);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={(open) => !open && onCancel()}>
      <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CropIcon size={16} /> Crop Image — {TYPE_LABELS[imageType]}
          </DialogTitle>
        </DialogHeader>

        <div
          className="relative overflow-hidden rounded-lg bg-muted/30 flex items-center justify-center"
          style={{ maxHeight: "60vh" }}
        >
          <ReactCrop
            crop={crop}
            onChange={(c) => setCrop(c)}
            aspect={aspect}
            className="max-h-[55vh]"
          >
            <img
              ref={imgRef}
              src={imgSrc}
              alt="Crop preview"
              onLoad={onImageLoad}
              style={{ transform: `scale(${zoom})`, transformOrigin: "center", maxHeight: "55vh" }}
              className="block"
            />
          </ReactCrop>
        </div>

        <div className="flex items-center gap-3 pt-1">
          <ZoomIn size={14} className="text-muted-foreground shrink-0" />
          <Slider
            min={1}
            max={3}
            step={0.05}
            value={[zoom]}
            onValueChange={([v]) => setZoom(v)}
            className="flex-1"
          />
          <span className="text-xs text-muted-foreground w-10 text-right">{Math.round(zoom * 100)}%</span>
        </div>

        <div className="flex gap-2 justify-end pt-2">
          <Button variant="outline" size="sm" onClick={onCancel}>
            Cancel
          </Button>
          <Button size="sm" onClick={handleConfirm} disabled={saving}>
            {saving ? "Cropping..." : "Confirm & Use"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/**
 * Hook-style helper: wraps a file input to open cropper before returning the file.
 * Usage:
 *   const { triggerUpload, CropperModal } = useImageUpload("banner", (file) => setMediaFile(file));
 *   <button onClick={triggerUpload}>Upload</button>
 *   <CropperModal />
 */
export function useImageUpload(imageType: ImageType, onFile: (file: File) => void) {
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const triggerUpload = () => inputRef.current?.click();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) setPendingFile(f);
    // Reset so same file can be re-selected
    if (inputRef.current) inputRef.current.value = "";
  };

  const CropperModal = () => (
    <>
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        onChange={handleChange}
      />
      {pendingFile && (
        <ImageCropper
          imageType={imageType}
          file={pendingFile}
          onCropped={(cropped) => {
            onFile(cropped);
            setPendingFile(null);
          }}
          onCancel={() => setPendingFile(null)}
        />
      )}
    </>
  );

  return { triggerUpload, CropperModal, inputRef };
}
