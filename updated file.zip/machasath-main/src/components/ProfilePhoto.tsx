import { User } from "lucide-react";

interface ProfilePhotoProps {
  fullName: string;
  gender: string;
  photoUrl?: string | null;
  showPhoto?: boolean | null;
  size?: "sm" | "md" | "lg";
}

const sizeClasses = {
  sm: "w-10 h-10 text-sm",
  md: "w-14 h-14 text-lg",
  lg: "w-20 h-20 text-2xl",
};

const iconSizes = {
  sm: 16,
  md: 22,
  lg: 32,
};

export default function ProfilePhoto({
  fullName,
  gender,
  photoUrl,
  showPhoto,
  size = "md",
}: ProfilePhotoProps) {
  const shouldShowPhoto = gender === "Male" ? true : showPhoto !== false;
  const initials = fullName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  if (gender === "Female" && !shouldShowPhoto) {
    return (
      <div
        className={`${sizeClasses[size]} rounded-full bg-muted flex items-center justify-center flex-shrink-0 ring-2 ring-border/30`}
      >
        <User size={iconSizes[size]} className="text-muted-foreground" />
      </div>
    );
  }

  if (photoUrl && shouldShowPhoto) {
    return (
      <img
        src={photoUrl}
        alt={fullName}
        className={`${sizeClasses[size]} rounded-full object-cover flex-shrink-0 ring-2 ring-border/30`}
      />
    );
  }

  return (
    <div
      className={`${sizeClasses[size]} rounded-full gradient-navy flex items-center justify-center text-primary-foreground font-bold flex-shrink-0 ring-2 ring-border/30 shadow-md`}
    >
      {initials}
    </div>
  );
}
