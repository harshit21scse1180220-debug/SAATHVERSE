import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";

import Index from "./pages/Index";
import SearchResults from "./pages/SearchResults";
import Auth from "./pages/Auth";
import Onboarding from "./pages/Onboarding";
import Search from "./pages/Search";
import ProfileView from "./pages/ProfileView";
import Requests from "./pages/Requests";
import Chat from "./pages/Chat";
import ChatRoom from "./pages/ChatRoom";
import Hackathons from "./pages/Hackathons";
import FindTeam from "./pages/FindTeam";
import HackathonDetail from "./pages/HackathonDetail";
import StartupHub from "./pages/StartupHub";
import Alumni from "./pages/Alumni";
import BranchStudents from "./pages/BranchStudents";
import AdminHackathons from "./pages/AdminHackathons";
import AdminCarousel from "./pages/AdminCarousel";
import AdminDashboard from "./pages/AdminDashboard";
import AdminFeaturedStudents from "./pages/AdminFeaturedStudents";
import AdminFormOptions from "./pages/AdminFormOptions";
import AdminAnalytics from "./pages/AdminAnalytics";
import AdminContentCarousel from "./pages/AdminContentCarousel";
import ContentDetail from "./pages/ContentDetail";
import SectionDetail from "./pages/SectionDetail";
import IEEEConferences from "./pages/IEEEConferences";
import IEEEPapers from "./pages/IEEEPapers";
import AdminIEEE from "./pages/AdminIEEE";
import AdminCollege from "./pages/AdminCollege";
import MyProfile from "./pages/MyProfile";
import ResetPassword from "./pages/ResetPassword";
import NotFound from "./pages/NotFound";
import AppLayout from "./components/AppLayout";

const queryClient = new QueryClient();

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) return <Navigate to="/auth" replace />;
  if (!profile) return <Navigate to="/onboarding" replace />;

  return <AppLayout>{children}</AppLayout>;
}

function AuthRoute({ children }: { children: React.ReactNode }) {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (user && profile) return <Navigate to="/search" replace />;
  if (user && !profile) return <Navigate to="/onboarding" replace />;

  return <>{children}</>;
}

function OnboardingRoute({ children }: { children: React.ReactNode }) {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) return <Navigate to="/auth" replace />;
  if (profile) return <Navigate to="/search" replace />;

  return <>{children}</>;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/auth" element={<AuthRoute><Auth /></AuthRoute>} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="/onboarding" element={<OnboardingRoute><Onboarding /></OnboardingRoute>} />

            <Route path="/search" element={<ProtectedRoute><Search /></ProtectedRoute>} />
            <Route path="/search/results" element={<ProtectedRoute><SearchResults /></ProtectedRoute>} />
            <Route path="/profile/:userId" element={<ProtectedRoute><ProfileView /></ProtectedRoute>} />
            <Route path="/branch/:branch" element={<ProtectedRoute><BranchStudents /></ProtectedRoute>} />
            <Route path="/requests" element={<ProtectedRoute><Requests /></ProtectedRoute>} />
            <Route path="/chat" element={<ProtectedRoute><Chat /></ProtectedRoute>} />
            <Route path="/chat/:partnerId" element={<ProtectedRoute><ChatRoom /></ProtectedRoute>} />
            <Route path="/alumni" element={<ProtectedRoute><Alumni /></ProtectedRoute>} />
            <Route path="/hackathons" element={<ProtectedRoute><Hackathons /></ProtectedRoute>} />
            <Route path="/find-team" element={<ProtectedRoute><FindTeam /></ProtectedRoute>} />
            <Route path="/hackathons/:id" element={<ProtectedRoute><HackathonDetail /></ProtectedRoute>} />
            <Route path="/startups" element={<ProtectedRoute><StartupHub /></ProtectedRoute>} />
            <Route path="/admin/hackathons" element={<ProtectedRoute><AdminHackathons /></ProtectedRoute>} />
            <Route path="/admin/carousel" element={<ProtectedRoute><AdminCarousel /></ProtectedRoute>} />
            <Route path="/admin/dashboard" element={<ProtectedRoute><AdminDashboard /></ProtectedRoute>} />
            <Route path="/admin/featured-students" element={<ProtectedRoute><AdminFeaturedStudents /></ProtectedRoute>} />
            <Route path="/admin/form-options" element={<ProtectedRoute><AdminFormOptions /></ProtectedRoute>} />
            <Route path="/admin/analytics" element={<ProtectedRoute><AdminAnalytics /></ProtectedRoute>} />
            <Route path="/admin/content-carousel" element={<ProtectedRoute><AdminContentCarousel /></ProtectedRoute>} />
            <Route path="/admin/ieee" element={<ProtectedRoute><AdminIEEE /></ProtectedRoute>} />
            <Route path="/admin/college/:collegeId" element={<ProtectedRoute><AdminCollege /></ProtectedRoute>} />
            <Route path="/section/:sectionId" element={<ProtectedRoute><SectionDetail /></ProtectedRoute>} />
            <Route path="/section/ieee/conferences" element={<ProtectedRoute><IEEEConferences /></ProtectedRoute>} />
            <Route path="/section/ieee/papers" element={<ProtectedRoute><IEEEPapers /></ProtectedRoute>} />
            <Route path="/content/:cardId" element={<ProtectedRoute><ContentDetail /></ProtectedRoute>} />
            <Route path="/my-profile" element={<ProtectedRoute><MyProfile /></ProtectedRoute>} />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
