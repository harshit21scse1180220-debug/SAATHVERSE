import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useMainBranches } from "@/hooks/useFormOptions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import ProfilePhoto from "@/components/ProfilePhoto";
import { toast } from "sonner";
import { mapErrorMessage } from "@/lib/errorMessages";
import { logEvent } from "@/lib/eventLog";
import type { Tables } from "@/integrations/supabase/types";
import { ArrowLeft, Plus, Users, Check, X, Search, UserPlus } from "lucide-react";
import { format } from "date-fns";
import { motion } from "framer-motion";

type Hackathon = Tables<"hackathons">;
type Team = Tables<"hackathon_teams">;
type JoinRequest = Tables<"team_join_requests">;
type Profile = Tables<"profiles">;

interface TeamInvite {
  id: string;
  team_id: string;
  invited_user_id: string;
  invited_by: string;
  status: string;
}

interface TeamWithDetails extends Team {
  creatorProfile?: Profile;
  joinRequests?: (JoinRequest & { profile?: Profile })[];
  invites?: (TeamInvite & { profile?: Profile })[];
}

export default function HackathonDetail() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [hackathon, setHackathon] = useState<Hackathon | null>(null);
  const [teams, setTeams] = useState<TeamWithDetails[]>([]);
  const [loading, setLoading] = useState(true);

  const [showCreateForm, setShowCreateForm] = useState(false);
  const [teamName, setTeamName] = useState("");
  const [rolesNeeded, setRolesNeeded] = useState("");
  const [creating, setCreating] = useState(false);

  // Member invite state
  const [inviteTeamId, setInviteTeamId] = useState<string | null>(null);
  const [searchBranch, setSearchBranch] = useState("");
  const [memberSearch, setMemberSearch] = useState("");
  const [searchResults, setSearchResults] = useState<Profile[]>([]);
  const [searching, setSearching] = useState(false);
  const { branches } = useMainBranches();

  const fetchData = async () => {
    if (!id) return;
    setLoading(true);

    const { data: hackathonData } = await supabase
      .from("hackathons")
      .select("*")
      .eq("id", id)
      .maybeSingle();
    setHackathon(hackathonData);

    const { data: teamsData } = await supabase
      .from("hackathon_teams")
      .select("*")
      .eq("hackathon_id", id)
      .order("created_at", { ascending: false });

    if (teamsData && teamsData.length > 0) {
      const creatorIds = teamsData.map((t) => t.creator_id);
      const teamIds = teamsData.map((t) => t.id);

      const [{ data: profiles }, { data: joinRequests }, { data: invites }] = await Promise.all([
        supabase.from("profiles").select("*").in("user_id", creatorIds),
        supabase.from("team_join_requests").select("*").in("team_id", teamIds),
        supabase.from("team_invites").select("*").in("team_id", teamIds),
      ]);

      const requestUserIds = joinRequests?.map((jr) => jr.user_id) || [];
      const inviteUserIds = invites?.map((inv) => inv.invited_user_id) || [];
      const allUserIds = [...new Set([...requestUserIds, ...inviteUserIds])];
      
      const { data: allProfiles } = allUserIds.length > 0
        ? await supabase.from("profiles").select("*").in("user_id", allUserIds)
        : { data: [] };

      const profileMap = new Map<string, Profile>();
      profiles?.forEach((p) => profileMap.set(p.user_id, p));
      allProfiles?.forEach((p) => profileMap.set(p.user_id, p));

      const enrichedTeams: TeamWithDetails[] = teamsData.map((team) => ({
        ...team,
        creatorProfile: profileMap.get(team.creator_id),
        joinRequests: joinRequests
          ?.filter((jr) => jr.team_id === team.id)
          .map((jr) => ({ ...jr, profile: profileMap.get(jr.user_id) })),
        invites: invites
          ?.filter((inv) => inv.team_id === team.id)
          .map((inv) => ({ ...inv, profile: profileMap.get(inv.invited_user_id) })),
      }));

      setTeams(enrichedTeams);
    } else {
      setTeams([]);
    }

    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, [id]);

  const createTeam = async () => {
    if (!user || !id || !teamName.trim()) return;
    setCreating(true);
    try {
      const { error } = await supabase.from("hackathon_teams").insert({
        hackathon_id: id,
        creator_id: user.id,
        name: teamName.trim(),
        roles_needed: rolesNeeded.trim(),
      });
      if (error) throw error;
      await logEvent(user.id, "hackathon_team_created", { hackathon_id: id });
      toast.success("Team created!");
      setTeamName("");
      setRolesNeeded("");
      setShowCreateForm(false);
      fetchData();
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    } finally {
      setCreating(false);
    }
  };

  const requestToJoin = async (teamId: string) => {
    if (!user) return;
    try {
      const { error } = await supabase.from("team_join_requests").insert({
        team_id: teamId,
        user_id: user.id,
      });
      if (error) throw error;
      toast.success("Join request sent!");
      fetchData();
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    }
  };

  const handleJoinRequest = async (requestId: string, status: "accepted" | "rejected") => {
    try {
      const { error } = await supabase
        .from("team_join_requests")
        .update({ status })
        .eq("id", requestId);
      if (error) throw error;
      toast.success(status === "accepted" ? "Member accepted!" : "Request declined");
      fetchData();
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    }
  };

  const searchByBranch = async (branch: string, nameQuery?: string) => {
    setSearchBranch(branch);
    if (!branch) { setSearchResults([]); return; }
    setSearching(true);
    let query = supabase
      .from("profiles")
      .select("*")
      .eq("branch", branch)
      .neq("user_id", user?.id || "")
      .order("full_name")
      .limit(50);
    if (nameQuery?.trim()) {
      query = query.ilike("full_name", `%${nameQuery.trim()}%`);
    }
    const { data } = await query;
    setSearchResults(data || []);
    setSearching(false);
  };

  const inviteUser = async (teamId: string, userId: string) => {
    if (!user) return;
    try {
      const { error } = await supabase.from("team_invites").insert({
        team_id: teamId,
        invited_user_id: userId,
        invited_by: user.id,
      });
      if (error) throw error;
      toast.success("Invite sent!");
      fetchData();
    } catch (e: unknown) {
      toast.error(mapErrorMessage(e));
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!hackathon) {
    return (
      <div className="text-center py-20 text-muted-foreground">
        <p>Hackathon not found</p>
        <Button variant="ghost" onClick={() => navigate("/hackathons")} className="mt-4">
          <ArrowLeft size={16} className="mr-2" /> Back
        </Button>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <Button variant="ghost" onClick={() => navigate("/hackathons")} className="mb-4">
        <ArrowLeft size={16} className="mr-2" /> Back to Hackathons
      </Button>

      {/* Hackathon info */}
      <Card className="border-border/60 shadow-lg mb-6">
        <CardContent className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">{hackathon.name}</h1>
              <p className="text-muted-foreground mt-1">By {hackathon.organizer}</p>
            </div>
            <Badge variant={hackathon.status === "open" ? "default" : "outline"}>
              {hackathon.status === "open" ? "Open" : "Closed"}
            </Badge>
          </div>
          {hackathon.description && (
            <p className="text-sm text-muted-foreground mt-3">{hackathon.description}</p>
          )}
          <div className="flex gap-4 mt-3 text-sm text-muted-foreground">
            <span>📍 {hackathon.mode}</span>
            <span>
              📅 Deadline: {format(new Date(hackathon.registration_deadline), "MMM d, yyyy")}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Teams section */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-foreground">Teams</h2>
        {hackathon.status === "open" && (
          <Button onClick={() => setShowCreateForm(!showCreateForm)} size="sm">
            <Plus size={16} className="mr-1" /> Create Team
          </Button>
        )}
      </div>

      {showCreateForm && (
        <Card className="border-border/60 mb-4">
          <CardContent className="p-4 space-y-3">
            <div className="space-y-2">
              <Label>Team Name</Label>
              <Input
                value={teamName}
                onChange={(e) => setTeamName(e.target.value)}
                placeholder="Your team name"
                maxLength={100}
              />
            </div>
            <div className="space-y-2">
              <Label>Roles Needed</Label>
              <Textarea
                value={rolesNeeded}
                onChange={(e) => setRolesNeeded(e.target.value)}
                placeholder="e.g. Frontend developer, UI designer..."
                maxLength={500}
                rows={2}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={createTeam} disabled={creating || !teamName.trim()}>
                {creating ? "Creating..." : "Create Team"}
              </Button>
              <Button variant="outline" onClick={() => setShowCreateForm(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {teams.length === 0 ? (
        <p className="text-center py-8 text-muted-foreground">
          No teams yet. Be the first to create one!
        </p>
      ) : (
        <div className="space-y-4">
          {teams.map((team) => {
            const isCreator = team.creator_id === user?.id;
            const myRequest = team.joinRequests?.find(
              (jr) => jr.user_id === user?.id
            );

            return (
              <Card key={team.id} className="border-border/60">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <Users size={16} className="text-muted-foreground" />
                        <h3 className="font-bold text-foreground">{team.name}</h3>
                        {isCreator && (
                          <Badge variant="outline" className="text-xs">
                            Your Team
                          </Badge>
                        )}
                      </div>
                      {team.creatorProfile && (
                        <p className="text-xs text-muted-foreground mt-1">
                          Created by {team.creatorProfile.full_name}
                        </p>
                      )}
                      {team.roles_needed && (
                        <p className="text-sm text-muted-foreground mt-2">
                          <span className="font-medium">Looking for:</span>{" "}
                          {team.roles_needed}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {isCreator && hackathon.status === "open" && (
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => setInviteTeamId(inviteTeamId === team.id ? null : team.id)}
                        >
                          <UserPlus size={14} className="mr-1" /> Add Members
                        </Button>
                      )}
                      {!isCreator && !myRequest && hackathon.status === "open" && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => requestToJoin(team.id)}
                        >
                          Request to Join
                        </Button>
                      )}
                      {myRequest && (
                        <Badge
                          variant={
                            myRequest.status === "accepted"
                              ? "default"
                              : myRequest.status === "rejected"
                              ? "destructive"
                              : "outline"
                          }
                        >
                          {myRequest.status === "pending" && "⏳ Pending"}
                          {myRequest.status === "accepted" && "✅ Joined"}
                          {myRequest.status === "rejected" && "❌ Declined"}
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Invite members panel */}
                  {isCreator && inviteTeamId === team.id && (
                    <div className="mt-4 pt-3 border-t border-border">
                      <p className="text-sm font-semibold text-foreground mb-2 flex items-center gap-2">
                        <Search size={14} /> Find Members by Branch
                      </p>
                      <Select value={searchBranch} onValueChange={(v) => { searchByBranch(v, memberSearch); }}>
                        <SelectTrigger className="mb-2">
                          <SelectValue placeholder="Select a branch" />
                        </SelectTrigger>
                        <SelectContent>
                          {branches.map(b => (
                            <SelectItem key={b.id} value={b.label}>{b.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {searchBranch && (
                        <Input
                          placeholder="Search by name..."
                          value={memberSearch}
                          onChange={(e) => {
                            setMemberSearch(e.target.value);
                            searchByBranch(searchBranch, e.target.value);
                          }}
                          className="mb-3"
                        />
                      )}

                      {searching && <p className="text-xs text-muted-foreground">Searching...</p>}
                      {searchResults.length > 0 && (
                        <div className="space-y-2 max-h-48 overflow-y-auto">
                          {searchResults.map(p => {
                            const alreadyInvited = team.invites?.some(inv => inv.invited_user_id === p.user_id);
                            const alreadyMember = team.joinRequests?.some(jr => jr.user_id === p.user_id && jr.status === "accepted");
                            return (
                              <div key={p.id} className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <ProfilePhoto fullName={p.full_name} gender={p.gender} photoUrl={p.photo_url} showPhoto={p.show_photo} size="sm" />
                                  <div>
                                    <p className="text-sm font-medium">{p.full_name}</p>
                                    <p className="text-xs text-muted-foreground">{p.branch} • Year {p.year_of_study}</p>
                                  </div>
                                </div>
                                {alreadyMember ? (
                                  <Badge className="text-xs">Member</Badge>
                                ) : alreadyInvited ? (
                                  <Badge variant="outline" className="text-xs">Invited</Badge>
                                ) : (
                                  <Button size="sm" variant="outline" onClick={() => inviteUser(team.id, p.user_id)}>
                                    Invite
                                  </Button>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                      {searchBranch && !searching && searchResults.length === 0 && (
                        <p className="text-xs text-muted-foreground">No students found in this branch.</p>
                      )}
                    </div>
                  )}

                  {/* Join requests (visible to team creator) */}
                  {isCreator &&
                    team.joinRequests &&
                    team.joinRequests.length > 0 && (
                      <div className="mt-4 pt-3 border-t border-border">
                        <p className="text-sm font-semibold text-foreground mb-2">
                          Join Requests
                        </p>
                        <div className="space-y-2">
                          {team.joinRequests.map((jr) => (
                            <div
                              key={jr.id}
                              className="flex items-center justify-between"
                            >
                              <div className="flex items-center gap-2">
                                {jr.profile && (
                                  <ProfilePhoto
                                    fullName={jr.profile.full_name}
                                    gender={jr.profile.gender}
                                    photoUrl={jr.profile.photo_url}
                                    showPhoto={jr.profile.show_photo}
                                    size="sm"
                                  />
                                )}
                                <div>
                                  <p className="text-sm font-medium">
                                    {jr.profile?.full_name || "Unknown"}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    {jr.profile?.branch}
                                  </p>
                                </div>
                              </div>
                              {jr.status === "pending" ? (
                                <div className="flex gap-1">
                                  <Button
                                    size="sm"
                                    onClick={() =>
                                      handleJoinRequest(jr.id, "accepted")
                                    }
                                  >
                                    <Check size={14} />
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() =>
                                      handleJoinRequest(jr.id, "rejected")
                                    }
                                  >
                                    <X size={14} />
                                  </Button>
                                </div>
                              ) : (
                                <Badge
                                  variant={
                                    jr.status === "accepted"
                                      ? "default"
                                      : "destructive"
                                  }
                                  className="text-xs"
                                >
                                  {jr.status}
                                </Badge>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </motion.div>
  );
}
