import { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { ArrowLeft, ChevronLeft, ChevronRight, UserPlus, Check, Loader2, Calendar, FileText } from "lucide-react";
import AnnouncementCarousel from "@/components/AnnouncementCarousel";
import BranchFeaturedCarousel from "@/components/BranchFeaturedCarousel";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { toast } from "sonner";

type Section = {
  id: string;
  title: string;
  section_type: string;
  cover_image_url: string | null;
  description: string | null;
};

type Row = { id: string; section_id: string; title: string };
type Card = { id: string; row_id: string; title: string; subtitle: string | null; image_url: string | null; link_url: string | null };

const typeColor: Record<string, string> = {
  professional_org: "from-blue-600/80 to-indigo-700/80",
  college_club: "from-emerald-600/80 to-teal-700/80",
  entrepreneurship: "from-orange-500/80 to-red-600/80",
  general: "from-primary/80 to-primary/60",
};

const typeBadgeLabel: Record<string, string> = {
  professional_org: "Professional Org",
  college_club: "College Club",
  entrepreneurship: "Entrepreneurship",
  general: "General",
};

export default function SectionDetail() {
  const { sectionId } = useParams<{ sectionId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [section, setSection] = useState<Section | null>(null);
  const [rows, setRows] = useState<Row[]>([]);
  const [cards, setCards] = useState<Card[]>([]);
  const [loading, setLoading] = useState(true);

  // Affiliation state
  const [myAffiliations, setMyAffiliations] = useState<string[]>([]);
  const [totalAffiliations, setTotalAffiliations] = useState(0);
  const [joining, setJoining] = useState(false);
  const [isJoined, setIsJoined] = useState(false);

  useEffect(() => {
    if (!sectionId) return;
    const load = async () => {
      const [sRes, rRes] = await Promise.all([
        supabase.from("content_sections").select("id, title, section_type, cover_image_url, description").eq("id", sectionId).maybeSingle(),
        supabase.from("content_rows").select("id, section_id, title").eq("section_id", sectionId).eq("is_active", true).order("display_order"),
      ]);
      setSection(sRes.data);
      setRows(rRes.data || []);

      if (rRes.data && rRes.data.length > 0) {
        const rowIds = rRes.data.map(r => r.id);
        const { data: cardData } = await supabase
          .from("content_cards")
          .select("id, row_id, title, subtitle, image_url, link_url")
          .in("row_id", rowIds)
          .eq("is_active", true)
          .order("display_order");
        setCards(cardData || []);
      }

      // Check user affiliations
      if (user) {
        const [{ data: myAff }, { count }] = await Promise.all([
          supabase.from("student_affiliations").select("section_id").eq("profile_id", user.id),
          supabase.from("student_affiliations").select("*", { count: "exact", head: true }).eq("profile_id", user.id),
        ]);
        const affSectionIds = (myAff || []).map(a => a.section_id);
        setMyAffiliations(affSectionIds);
        setTotalAffiliations(count || 0);
        setIsJoined(affSectionIds.includes(sectionId));
      }

      setLoading(false);
    };
    load();
  }, [sectionId, user]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!section) {
    return (
      <div className="text-center py-20 text-muted-foreground">
        <p className="font-medium">Section not found</p>
        <Button variant="ghost" onClick={() => navigate(-1)} className="mt-4"><ArrowLeft size={16} className="mr-2" /> Go Back</Button>
      </div>
    );
  }

  const getCardsForRow = (rowId: string) => cards.filter(c => c.row_id === rowId);
  const gradient = typeColor[section.section_type] || typeColor.general;

  const handleJoinSection = async () => {
    if (!user || !sectionId || !section) return;
    setJoining(true);
    try {
      if (isJoined) {
        // Leave
        await supabase.from("student_affiliations").delete().eq("profile_id", user.id).eq("section_id", sectionId);
        setIsJoined(false);
        setTotalAffiliations(prev => prev - 1);
        toast.success(`Left ${section.title}`);
      } else {
        if (totalAffiliations >= 2) {
          toast.error("You can join a maximum of 2 clubs/organizations. Leave one first.");
          setJoining(false);
          return;
        }
        await supabase.from("student_affiliations").insert({ profile_id: user.id, section_id: sectionId });
        setIsJoined(true);
        setTotalAffiliations(prev => prev + 1);
        toast.success(`Joined ${section.title}!`);
      }
    } catch (e: any) {
      toast.error(e?.message || "Something went wrong");
    } finally {
      setJoining(false);
    }
  };

  const sectionTarget = section.section_type === "professional_org"
    ? "section:ieee"
    : section.section_type === "college_club"
    ? "section:club"
    : section.section_type === "entrepreneurship"
    ? "section:startup"
    : undefined;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <Button variant="ghost" onClick={() => navigate(-1)} className="mb-4">
        <ArrowLeft size={16} className="mr-2" /> Back
      </Button>

      {/* Section Banner */}
      <div className={`relative rounded-2xl overflow-hidden mb-4 ${section.cover_image_url ? "h-[200px] sm:h-[220px] md:aspect-[16/6] md:h-auto" : "py-8 px-6"} bg-gradient-to-r ${gradient}`}>
        {section.cover_image_url && (
          <img src={section.cover_image_url} alt="" className="absolute inset-0 w-full h-full object-cover mix-blend-overlay opacity-40" loading="lazy" />
        )}
        <div className={`relative z-10 ${section.cover_image_url ? "flex flex-col justify-end h-full p-6" : ""}`}>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight drop-shadow-lg">{section.title}</h1>
          {section.description && <p className="text-white/80 text-sm mt-1 max-w-xl">{section.description}</p>}
          <span className="mt-2 inline-block text-[10px] uppercase tracking-widest font-bold text-white/60 bg-white/10 rounded-full px-3 py-1 w-fit">
            {typeBadgeLabel[section.section_type] || "General"}
          </span>
        </div>
      </div>

      {/* Announcement Carousel — below banner */}
      {sectionTarget && <AnnouncementCarousel target={sectionTarget} />}

      {/* IEEE Sub-modules: Conferences & Papers */}
      {section.section_type === "professional_org" && (
        <div className="grid grid-cols-2 gap-3 mb-6">
          <Card
            className="cursor-pointer hover:shadow-lg transition-all duration-200 border-primary/30 bg-gradient-to-br from-primary/10 to-primary/5 group"
            onClick={() => navigate("/section/ieee/conferences")}
          >
            <CardContent className="p-5 text-center">
              <div className="w-12 h-12 rounded-full bg-primary/15 flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                <Calendar size={22} className="text-primary" />
              </div>
              <h3 className="font-bold text-foreground text-sm">Upcoming / Recent Conferences</h3>
              <p className="text-xs text-muted-foreground mt-1">Browse IEEE conferences</p>
            </CardContent>
          </Card>
          <Card
            className="cursor-pointer hover:shadow-lg transition-all duration-200 border-accent/30 bg-gradient-to-br from-accent/10 to-accent/5 group"
            onClick={() => navigate("/section/ieee/papers")}
          >
            <CardContent className="p-5 text-center">
              <div className="w-12 h-12 rounded-full bg-accent/15 flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                <FileText size={22} className="text-accent-foreground" />
              </div>
              <h3 className="font-bold text-foreground text-sm">Published Papers</h3>
              <p className="text-xs text-muted-foreground mt-1">View research publications</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Featured Students Carousel — uses section title as branch */}
      <BranchFeaturedCarousel branch={section.title} />
      {/* Join / Leave Button — only for entrepreneurship sections */}
      {section.section_type === "entrepreneurship" && (
        <div className="mb-6 flex items-center gap-3">
          <Button
            onClick={handleJoinSection}
            disabled={joining}
            variant={isJoined ? "outline" : "default"}
            className="gap-2"
          >
            {joining ? <Loader2 size={16} className="animate-spin" /> : isJoined ? <Check size={16} /> : <UserPlus size={16} />}
            {isJoined ? "Joined" : "Join"}
          </Button>
          {isJoined && <Badge variant="secondary">Member</Badge>}
          {!isJoined && totalAffiliations >= 2 && (
            <span className="text-xs text-muted-foreground">Max 2 clubs — leave one to join</span>
          )}
        </div>
      )}

      {/* Rows */}
      {rows.length === 0 ? (
        <p className="text-center text-muted-foreground py-10">No content added to this section yet.</p>
      ) : (
        rows.map(row => {
          const rowCards = getCardsForRow(row.id);
          if (rowCards.length === 0) return (
            <div key={row.id} className="mb-6">
              <h3 className="text-base font-bold text-foreground mb-3 px-1">{row.title}</h3>
              <p className="text-sm text-muted-foreground px-1">No cards yet.</p>
            </div>
          );
          return <CarouselRow key={row.id} title={row.title} cards={rowCards} navigate={navigate} />;
        })
      )}
    </motion.div>
  );
}

function CarouselRow({ title, cards, navigate }: { title: string; cards: Card[]; navigate: (to: string) => void }) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  const checkScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    setCanScrollLeft(el.scrollLeft > 2);
    setCanScrollRight(el.scrollLeft < el.scrollWidth - el.clientWidth - 2);
  };

  useEffect(() => { checkScroll(); }, [cards]);

  const scroll = (dir: number) => {
    scrollRef.current?.scrollBy({ left: dir * 280, behavior: "smooth" });
  };

  return (
    <div className="mb-8">
      <h3 className="text-base font-bold text-foreground mb-3 px-1">{title}</h3>
      <div className="relative group">
        {canScrollLeft && (
          <button onClick={() => scroll(-1)} className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-9 h-9 rounded-full bg-card/90 border border-border shadow-lg flex items-center justify-center text-foreground hover:bg-card transition-all opacity-0 group-hover:opacity-100">
            <ChevronLeft size={18} />
          </button>
        )}
        {canScrollRight && (
          <button onClick={() => scroll(1)} className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-9 h-9 rounded-full bg-card/90 border border-border shadow-lg flex items-center justify-center text-foreground hover:bg-card transition-all opacity-0 group-hover:opacity-100">
            <ChevronRight size={18} />
          </button>
        )}
        <div ref={scrollRef} onScroll={checkScroll} className="flex gap-4 overflow-x-auto scrollbar-hide pb-2 snap-x snap-mandatory" style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}>
          {cards.map(card => (
            <div
              key={card.id}
              onClick={() => navigate(`/content/${card.id}`)}
              className="shrink-0 w-48 sm:w-56 cursor-pointer group/card snap-start"
            >
              <div className="relative rounded-xl overflow-hidden border border-border/40 bg-card hover:border-primary/40 hover:shadow-lg transition-all duration-300">
                {card.image_url ? (
                  <img src={card.image_url} alt={card.title} className="w-full aspect-[4/3] object-cover group-hover/card:scale-105 transition-transform duration-300" loading="lazy" />
                ) : (
                  <div className="w-full aspect-[4/3] bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center">
                    <span className="text-2xl font-extrabold text-muted-foreground/20">{card.title[0]}</span>
                  </div>
                )}
                <div className="p-3">
                  <p className="text-sm font-semibold text-foreground truncate">{card.title}</p>
                  {card.subtitle && <p className="text-xs text-muted-foreground truncate mt-0.5">{card.subtitle}</p>}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
