import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { Tables } from "@/integrations/supabase/types";
import { Trophy, Calendar, MapPin, Plus, Search, ArrowRight, X, Users } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { toast } from "sonner";
import { mapErrorMessage } from "@/lib/errorMessages";
import { logEvent } from "@/lib/eventLog";

type Hackathon = Tables<"hackathons">;

interface DummyHackathon {
  id: string;
  name: string;
  organizer: string;
  description: string;
  mode: string;
  status: string;
  registration_deadline: string;
  isDummy: true;
}

const dummyHackathons: DummyHackathon[] = [
  {
    id: "demo-1",
    name: "CodeStorm 2026",
    organizer: "Tech Club GU",
    description: "48-hour coding marathon. Build innovative solutions for real-world problems. Cash prizes worth ₹50,000!",
    mode: "Offline",
    status: "open",
    registration_deadline: new Date(Date.now() + 15 * 86400000).toISOString(),
    isDummy: true,
  },
  {
    id: "demo-2",
    name: "HackTheVerse",
    organizer: "Google DSC GU",
    description: "A national-level hackathon focused on AI/ML, Web3, and sustainability. Open to all branches.",
    mode: "Hybrid",
    status: "open",
    registration_deadline: new Date(Date.now() + 30 * 86400000).toISOString(),
    isDummy: true,
  },
  {
    id: "demo-3",
    name: "DevSprint '26",
    organizer: "CSE Department",
    description: "Department-level sprint to build campus utility apps. Great for first-time hackers!",
    mode: "Online",
    status: "open",
    registration_deadline: new Date(Date.now() + 7 * 86400000).toISOString(),
    isDummy: true,
  },
  {
    id: "demo-4",
    name: "InnoHacks 5.0",
    organizer: "E-Cell Galgotias",
    description: "Entrepreneurship meets engineering. Pitch your startup idea with a working prototype.",
    mode: "Offline",
    status: "closed",
    registration_deadline: new Date(Date.now() - 5 * 86400000).toISOString(),
    isDummy: true,
  },
];

export default function Hackathons() {
  const navigate = useNavigate();
  const { user, collegeId } = useAuth();
  const [hackathons, setHackathons] = useState<Hackathon[]>([]);
  const [loading, setLoading] = useState(true);

  // Create Team state
  const [showCreateTeam, setShowCreateTeam] = useState(false);
  const [teamName, setTeamName] = useState("");
  const [teamDescription, setTeamDescription] = useState("");
  const [teamSize, setTeamSize] = useState("4");
  const [rolesNeeded, setRolesNeeded] = useState("");
  const [selectedHackathonId, setSelectedHackathonId] = useState("");
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    if (!collegeId) return;
    const fetch = async () => {
      const { data } = await supabase
        .from("hackathons")
        .select("*")
        .or(`college_id.eq.${collegeId},college_id.is.null`)
        .order("registration_deadline", { ascending: true });
      setHackathons(data || []);
      setLoading(false);
    };
    fetch();
  }, [collegeId]);

  const openHackathons = hackathons.filter((h) => h.status === "open");

  const allHackathons = [
    ...hackathons.map((h) => ({ ...h, isDummy: false as const })),
    ...dummyHackathons,
  ];

  const resetCreateForm = () => {
    setTeamName("");
    setTeamDescription("");
    setTeamSize("4");
    setRolesNeeded("");
    setSelectedHackathonId("");
    setShowCreateTeam(false);
  };

  const handleCreateTeam = async () => {
    if (!user || !teamName.trim() || !selectedHackathonId) {
      toast.error("Please fill in team name and select a hackathon");
      return;
    }
    setCreating(true);
    try {
      const { error } = await supabase.from("hackathon_teams").insert({
        hackathon_id: selectedHackathonId,
        creator_id: user.id,
        name: teamName.trim(),
        roles_needed: rolesNeeded.trim() || null,
        team_size: parseInt(teamSize),
        description: teamDescription.trim() || null,
      });
      if (error) throw error;
      await logEvent(user.id, "hackathon_team_created", { hackathon_id: selectedHackathonId });
      toast.success("Team created successfully!");
      resetCreateForm();
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    } finally {
      setCreating(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      {/* Header */}
      <div className="flex items-center gap-3 mb-1">
        <Trophy size={28} className="text-primary" />
        <h1 className="text-2xl font-bold text-foreground">Hackathons</h1>
      </div>
      <p className="text-muted-foreground text-sm mb-6">
        Compete, collaborate, and build something amazing
      </p>

      {/* Team Action Cards */}
      <div className="grid grid-cols-2 gap-3 mb-8">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card
            className="cursor-pointer hover:shadow-lg transition-all duration-200 border-primary/30 bg-gradient-to-br from-primary/10 to-primary/5 group"
            onClick={() => navigate("/find-team")}
          >
            <CardContent className="p-5 text-center">
              <div className="w-12 h-12 rounded-full bg-primary/15 flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                <Search size={22} className="text-primary" />
              </div>
              <h3 className="font-bold text-foreground text-sm">Find a Team</h3>
              <p className="text-xs text-muted-foreground mt-1">Browse open teams looking for members</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <Card
            className="cursor-pointer hover:shadow-lg transition-all duration-200 border-accent/30 bg-gradient-to-br from-accent/10 to-accent/5 group"
            onClick={() => setShowCreateTeam(true)}
          >
            <CardContent className="p-5 text-center">
              <div className="w-12 h-12 rounded-full bg-accent/15 flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                <Plus size={22} className="text-accent-foreground" />
              </div>
              <h3 className="font-bold text-foreground text-sm">Create a Team</h3>
              <p className="text-xs text-muted-foreground mt-1">Start your own squad for a hackathon</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Create Team Modal */}
      {showCreateTeam && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-md p-6 space-y-4 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users size={20} className="text-primary" />
                <h3 className="font-bold text-lg text-foreground">Create a Team</h3>
              </div>
              <button onClick={resetCreateForm} className="text-muted-foreground hover:text-foreground">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-2">
              <Label>Select Hackathon *</Label>
              <Select value={selectedHackathonId} onValueChange={setSelectedHackathonId}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a hackathon" />
                </SelectTrigger>
                <SelectContent>
                  {openHackathons.map((h) => (
                    <SelectItem key={h.id} value={h.id}>{h.name}</SelectItem>
                  ))}
                  {openHackathons.length === 0 && (
                    <SelectItem value="none" disabled>No open hackathons</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Team Name *</Label>
              <Input
                value={teamName}
                onChange={(e) => setTeamName(e.target.value)}
                placeholder="e.g. Code Crushers"
                maxLength={100}
              />
            </div>

            <div className="space-y-2">
              <Label>Team Description</Label>
              <Textarea
                value={teamDescription}
                onChange={(e) => setTeamDescription(e.target.value)}
                placeholder="What's your team about? What problem are you solving?"
                maxLength={500}
                rows={2}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Team Size</Label>
                <Select value={teamSize} onValueChange={setTeamSize}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[2, 3, 4, 5, 6].map((n) => (
                      <SelectItem key={n} value={String(n)}>{n} members</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Roles Needed</Label>
              <Textarea
                value={rolesNeeded}
                onChange={(e) => setRolesNeeded(e.target.value)}
                placeholder="e.g. Frontend dev, UI/UX designer, ML engineer..."
                maxLength={500}
                rows={2}
              />
            </div>

            <div className="flex gap-2 pt-2">
              <Button
                onClick={handleCreateTeam}
                disabled={creating || !teamName.trim() || !selectedHackathonId}
                className="flex-1"
              >
                {creating ? "Creating..." : "Create Team"}
              </Button>
              <Button variant="outline" onClick={resetCreateForm}>
                Cancel
              </Button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Hackathon List */}
      <h2 className="text-lg font-bold text-foreground mb-3 flex items-center gap-2">
        <Calendar size={18} className="text-muted-foreground" />
        Upcoming & Recent
      </h2>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-32 bg-muted rounded-lg animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          {allHackathons.map((h, i) => {
            const isOpen = h.status === "open";
            const isPast = new Date(h.registration_deadline) < new Date();

            return (
              <motion.div
                key={h.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Card
                  className="cursor-pointer hover:shadow-lg transition-all duration-200 border-border/60"
                  onClick={() => {
                    if (!h.isDummy) navigate(`/hackathons/${h.id}`);
                  }}
                >
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <h3 className="text-lg font-bold text-foreground">
                            {h.name}
                          </h3>
                          <Badge
                            variant={isOpen && !isPast ? "default" : "outline"}
                            className="text-xs"
                          >
                            {!isOpen ? "Closed" : isPast ? "Deadline Passed" : "Open"}
                          </Badge>
                          {h.isDummy && (
                            <Badge variant="secondary" className="text-xs">
                              Demo
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          By {h.organizer}
                        </p>
                        {h.description && (
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {h.description}
                          </p>
                        )}
                        <div className="flex items-center justify-between mt-3">
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <MapPin size={12} /> {h.mode}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar size={12} />{" "}
                              {format(new Date(h.registration_deadline), "MMM d, yyyy")}
                            </span>
                          </div>
                          {isOpen && !isPast && (
                            <div className="flex items-center gap-1 text-xs font-medium text-primary">
                              View <ArrowRight size={12} />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}
    </motion.div>
  );
}
