import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import ProfilePhoto from "@/components/ProfilePhoto";
import SkillsInput from "@/components/SkillsInput";
import { toast } from "sonner";
import { mapErrorMessage } from "@/lib/errorMessages";
import { motion } from "framer-motion";
import { Pencil, GraduationCap, BookOpen, Calendar, Sparkles, Lock, Building2, Briefcase, KeyRound } from "lucide-react";

export default function MyProfile() {
  const { profile, refreshProfile, user } = useAuth();
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [changePasswordOpen, setChangePasswordOpen] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [changingPassword, setChangingPassword] = useState(false);

  const [bio, setBio] = useState(profile?.bio || "");
  const [skills, setSkills] = useState<string[]>(profile?.skills || []);
  const [interestedInHackathons, setInterestedInHackathons] = useState(
    profile?.interested_in_hackathons || false
  );
  const [showPhoto, setShowPhoto] = useState(profile?.show_photo !== false);

  const startEdit = () => {
    setBio(profile?.bio || "");
    setSkills(profile?.skills || []);
    setInterestedInHackathons(profile?.interested_in_hackathons || false);
    setShowPhoto(profile?.show_photo !== false);
    setEditing(true);
  };

  const handleSave = async () => {
    if (!user || !profile) return;
    setSaving(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({
          bio: bio.trim(),
          skills,
          interested_in_hackathons: interestedInHackathons,
          show_photo: profile.gender === "Male" ? true : showPhoto,
        })
        .eq("user_id", user.id);
      if (error) throw error;
      await refreshProfile();
      toast.success("Profile updated!");
      setEditing(false);
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async () => {
    if (newPassword.length < 6) {
      toast.error("Password must be at least 6 characters");
      return;
    }
    if (newPassword !== confirmNewPassword) {
      toast.error("Passwords do not match");
      return;
    }
    setChangingPassword(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
      toast.success("Password changed successfully!");
      setChangePasswordOpen(false);
      setNewPassword("");
      setConfirmNewPassword("");
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    } finally {
      setChangingPassword(false);
    }
  };

  if (!profile) {
    return (
      <div className="text-center py-20 text-muted-foreground">
        <p>No profile found. Please complete onboarding.</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="max-w-2xl mx-auto"
    >
      <h1 className="text-2xl font-bold text-foreground text-center mb-6">My Profile</h1>

      <Card className="border-border/60 shadow-xl overflow-hidden">
        <div className="h-24 gradient-navy relative">
          <div className="absolute -bottom-10 left-6">
            <div className="ring-4 ring-card rounded-full">
              <ProfilePhoto
                fullName={profile.full_name}
                gender={profile.gender}
                photoUrl={profile.photo_url}
                showPhoto={profile.show_photo}
                size="lg"
              />
            </div>
          </div>
        </div>

        <CardContent className="pt-14 pb-6 px-6">
          {!editing ? (
            <div className="space-y-5">
              {/* Name and info */}
              <div>
                <h2 className="text-xl font-bold text-foreground">{profile.full_name}</h2>
                <div className="flex flex-wrap items-center gap-3 mt-1.5 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <BookOpen size={14} /> {profile.branch}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar size={14} /> {profile.year_of_study === 0 ? "N/A" : `Year ${profile.year_of_study}`}
                  </span>
                  <span className="flex items-center gap-1">
                    <GraduationCap size={14} /> {profile.college_name}
                  </span>
                </div>
              </div>

              {/* Bio */}
              {profile.bio && (
                <div className="p-4 bg-muted/40 rounded-xl">
                  <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5">About</h3>
                  <p className="text-sm text-foreground leading-relaxed">{profile.bio}</p>
                </div>
              )}

              {/* Skills */}
              {profile.skills && profile.skills.length > 0 && (
                <div>
                  <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Sparkles size={12} /> Skills
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {profile.skills.map((s) => (
                      <Badge key={s} variant="secondary" className="text-sm px-3 py-1">{s}</Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Alumni info */}
              {profile.is_alumni && (
                <div className="p-4 bg-muted/40 rounded-xl">
                  <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <GraduationCap size={12} /> Alumni Details
                  </h3>
                  <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
                    {profile.company_name && (
                      <span className="flex items-center gap-1"><Building2 size={13} /> {profile.company_name}</span>
                    )}
                    {profile.tech_or_non_tech && (
                      <span className="flex items-center gap-1"><Briefcase size={13} /> {profile.tech_or_non_tech}</span>
                    )}
                    {profile.year_of_passout && (
                      <span className="flex items-center gap-1"><Calendar size={13} /> Passout: {profile.year_of_passout}</span>
                    )}
                  </div>
                </div>
              )}

              {/* Hackathon interest */}
              <div>
                <Badge
                  variant={profile.interested_in_hackathons ? "default" : "outline"}
                  className="text-sm px-3 py-1"
                >
                  {profile.interested_in_hackathons
                    ? "🏆 Interested in Hackathons"
                    : "Not interested in hackathons"}
                </Badge>
              </div>

              {profile.gender === "Female" && (
                <p className="text-xs text-muted-foreground">
                  📷 Photo visibility: {profile.show_photo ? "Visible" : "Hidden"}
                </p>
              )}
            </div>
          ) : (
            /* Edit mode */
            <div className="space-y-5">
              {/* Locked fields info */}
              <div className="p-3 bg-muted/40 rounded-xl border border-border/50">
                <div className="flex items-center gap-2 mb-2">
                  <Lock size={14} className="text-muted-foreground" />
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    Locked Fields
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-muted-foreground text-xs">Name</span>
                    <p className="font-medium text-foreground">{profile.full_name}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground text-xs">Gender</span>
                    <p className="font-medium text-foreground capitalize">{profile.gender}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground text-xs">Branch</span>
                    <p className="font-medium text-foreground">{profile.branch}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground text-xs">Year</span>
                    <p className="font-medium text-foreground">{profile.year_of_study === 0 ? "N/A" : `Year ${profile.year_of_study}`}</p>
                  </div>
                  <div className="col-span-2">
                    <span className="text-muted-foreground text-xs">College</span>
                    <p className="font-medium text-foreground">{profile.college_name}</p>
                  </div>
                </div>
              </div>

              {/* Editable: Bio */}
              <div className="space-y-2">
                <Label className="text-sm font-semibold">Bio</Label>
                <Textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  maxLength={500}
                  rows={3}
                  placeholder="Tell others about yourself..."
                />
              </div>

              {/* Editable: Skills */}
              <div className="space-y-2">
                <Label className="text-sm font-semibold flex items-center gap-1.5">
                  <Sparkles size={14} className="text-accent" />
                  Skills (up to 3)
                </Label>
                <SkillsInput skills={skills} onChange={setSkills} maxSkills={3} />
              </div>

              {/* Editable: Hackathon interest */}
              <div className="flex items-center justify-between p-3 bg-muted/40 rounded-xl">
                <Label className="text-sm font-medium">🏆 Interested in hackathons?</Label>
                <Switch checked={interestedInHackathons} onCheckedChange={setInterestedInHackathons} />
              </div>

              {/* Editable: Photo visibility (female only) */}
              {profile.gender === "Female" && (
                <div className="flex items-center justify-between p-3 bg-muted/40 rounded-xl">
                  <div>
                    <Label className="text-sm font-medium">Show profile photo</Label>
                    <p className="text-xs text-muted-foreground">When hidden, a neutral avatar appears</p>
                  </div>
                  <Switch checked={showPhoto} onCheckedChange={setShowPhoto} />
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <Button onClick={handleSave} disabled={saving} className="font-semibold">
                  {saving ? "Saving..." : "Save Changes"}
                </Button>
                <Button variant="outline" onClick={() => setEditing(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Action buttons at the bottom for mobile, inline for desktop */}
      {!editing && (
        <div className="flex flex-col sm:flex-row gap-2 mt-6 sm:justify-end">
          <Button variant="outline" size="sm" onClick={() => setChangePasswordOpen(true)} className="gap-1.5 w-full sm:w-auto">
            <KeyRound size={14} />
            Change Password
          </Button>
          <Button variant="outline" onClick={startEdit} className="gap-2 w-full sm:w-auto">
            <Pencil size={14} />
            Edit Profile
          </Button>
        </div>
      )}

      {/* Change Password Dialog */}
      <Dialog open={changePasswordOpen} onOpenChange={(open) => {
        setChangePasswordOpen(open);
        if (!open) { setNewPassword(""); setConfirmNewPassword(""); }
      }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-lg font-bold flex items-center gap-2">
              <KeyRound size={18} /> Change Password
            </DialogTitle>
            <DialogDescription className="text-xs">
              Enter your new password below. Must be at least 6 characters.
            </DialogDescription>
          </DialogHeader>
          <form
            onSubmit={(e) => { e.preventDefault(); handleChangePassword(); }}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label htmlFor="newPassword" className="text-sm font-semibold">New Password</Label>
              <Input
                id="newPassword"
                type="password"
                placeholder="At least 6 characters"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                minLength={6}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirmNewPassword" className="text-sm font-semibold">Confirm Password</Label>
              <Input
                id="confirmNewPassword"
                type="password"
                placeholder="Re-enter your password"
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
                required
                minLength={6}
              />
            </div>
            <Button type="submit" className="w-full h-10 font-semibold" disabled={changingPassword}>
              {changingPassword ? "Changing..." : "Change Password →"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
