import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import ProfilePhoto from "@/components/ProfilePhoto";
import type { Tables } from "@/integrations/supabase/types";
import { MessageCircle } from "lucide-react";
import { motion } from "framer-motion";

type Profile = Tables<"profiles">;

type ContactWithLastMsg = Profile & {
  lastMessage?: string | null;
  lastMessageTime?: string | null;
  lastMessageSenderId?: string | null;
  unreadCount?: number;
};

export default function Chat() {
  const { user, collegeId } = useAuth();
  const navigate = useNavigate();
  const [contacts, setContacts] = useState<ContactWithLastMsg[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const fetchContacts = async () => {
      setLoading(true);

      // Get all accepted collaboration requests
      const { data: requests } = await supabase
        .from("collaboration_requests")
        .select("*")
        .eq("status", "accepted")
        .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`);

      if (!requests || requests.length === 0) {
        setContacts([]);
        setLoading(false);
        return;
      }

      // Get partner IDs
      const partnerIds = requests.map((r) =>
        r.sender_id === user.id ? r.receiver_id : r.sender_id
      );

      // Fetch partner profiles, filtered by college
      let profileQuery = supabase
        .from("profiles")
        .select("*")
        .in("user_id", partnerIds);
      if (collegeId) profileQuery = profileQuery.eq("college_id", collegeId);
      const { data: profiles } = await profileQuery;

      if (!profiles || profiles.length === 0) {
        setContacts([]);
        setLoading(false);
        return;
      }

      // Fetch last message and unread count for each partner
      const enrichedContacts: ContactWithLastMsg[] = await Promise.all(
        profiles.map(async (profile) => {
          const pid = profile.user_id;

          // Last message between the two
          const { data: lastMsgs } = await supabase
            .from("messages")
            .select("content, created_at, sender_id")
            .or(
              `and(sender_id.eq.${user.id},receiver_id.eq.${pid}),and(sender_id.eq.${pid},receiver_id.eq.${user.id})`
            )
            .order("created_at", { ascending: false })
            .limit(1);

          const lastMsg = lastMsgs?.[0] ?? null;

          // Unread count (messages FROM this partner that I haven't read)
          const { count } = await supabase
            .from("messages")
            .select("*", { count: "exact", head: true })
            .eq("sender_id", pid)
            .eq("receiver_id", user.id)
            .is("read_at", null);

          return {
            ...profile,
            lastMessage: lastMsg?.content ?? null,
            lastMessageTime: lastMsg?.created_at ?? null,
            lastMessageSenderId: lastMsg?.sender_id ?? null,
            unreadCount: count || 0,
          };
        })
      );

      // Sort by last message time (most recent first)
      enrichedContacts.sort((a, b) => {
        if (!a.lastMessageTime && !b.lastMessageTime) return 0;
        if (!a.lastMessageTime) return 1;
        if (!b.lastMessageTime) return -1;
        return new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime();
      });

      setContacts(enrichedContacts);
      setLoading(false);
    };

    fetchContacts();
  }, [user, collegeId]);

  const formatTime = (dateStr: string | null | undefined) => {
    if (!dateStr) return "";
    const d = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    const oneDay = 86400000;

    if (diff < oneDay && d.getDate() === now.getDate()) {
      return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    }
    if (diff < 2 * oneDay) return "Yesterday";
    return d.toLocaleDateString([], { month: "short", day: "numeric" });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <h1 className="text-2xl font-bold text-foreground mb-1">Messages</h1>
      <p className="text-muted-foreground text-sm mb-6">
        Chat with your accepted collaborators
      </p>

      {loading ? (
        <div className="space-y-3">
          {[1, 2].map((i) => (
            <div key={i} className="h-16 bg-muted rounded-lg animate-pulse" />
          ))}
        </div>
      ) : contacts.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <MessageCircle size={48} className="mx-auto mb-4 opacity-30" />
          <p className="font-medium">No conversations yet</p>
          <p className="text-sm">
            Accept a collaboration request to start chatting
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {contacts.map((contact) => (
            <Card
              key={contact.id}
              className={`cursor-pointer hover:shadow-md transition-all duration-200 border-border/60 ${
                contact.unreadCount && contact.unreadCount > 0
                  ? "border-primary/40 bg-primary/5"
                  : ""
              }`}
              onClick={() => navigate(`/chat/${contact.user_id}`)}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <ProfilePhoto
                      fullName={contact.full_name}
                      gender={contact.gender}
                      photoUrl={contact.photo_url}
                      showPhoto={contact.show_photo}
                      size="sm"
                    />
                    {contact.unreadCount !== undefined && contact.unreadCount > 0 && (
                      <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center">
                        {contact.unreadCount}
                      </span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className={`font-semibold text-foreground truncate ${
                        contact.unreadCount && contact.unreadCount > 0 ? "text-foreground" : ""
                      }`}>
                        {contact.full_name}
                      </p>
                      {contact.lastMessageTime && (
                        <span className={`text-[10px] shrink-0 ml-2 ${
                          contact.unreadCount && contact.unreadCount > 0
                            ? "text-primary font-semibold"
                            : "text-muted-foreground"
                        }`}>
                          {formatTime(contact.lastMessageTime)}
                        </span>
                      )}
                    </div>
                    {contact.lastMessage ? (
                      <p className={`text-xs truncate mt-0.5 ${
                        contact.unreadCount && contact.unreadCount > 0
                          ? "text-foreground font-medium"
                          : "text-muted-foreground"
                      }`}>
                        {contact.lastMessageSenderId === user?.id ? "You: " : ""}
                        {contact.lastMessage}
                      </p>
                    ) : (
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {contact.branch} · {contact.year_of_study === 0 ? "N/A" : `Year ${contact.year_of_study}`}
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </motion.div>
  );
}
