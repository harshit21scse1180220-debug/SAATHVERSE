import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Search as SearchIcon, Building2, GraduationCap, Briefcase, Calendar } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import ProfilePhoto from "@/components/ProfilePhoto";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { motion } from "framer-motion";
import type { Tables } from "@/integrations/supabase/types";

type Profile = Tables<"profiles">;

export default function Alumni() {
  const navigate = useNavigate();
  const { user, collegeId } = useAuth();
  const [alumni, setAlumni] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const fetchAlumni = async () => {
      setLoading(true);
      let query = supabase
        .from("profiles")
        .select("*")
        .eq("is_alumni", true)
        .order("year_of_passout", { ascending: false });
      if (collegeId) query = query.eq("college_id", collegeId);
      const { data } = await query;
      setAlumni(data || []);
      setLoading(false);
    };
    fetchAlumni();
  }, []);

  const filtered = alumni.filter((a) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      a.full_name?.toLowerCase().includes(q) ||
      a.company_name?.toLowerCase().includes(q) ||
      a.branch?.toLowerCase().includes(q) ||
      a.tech_or_non_tech?.toLowerCase().includes(q) ||
      a.skills?.some((s) => s.toLowerCase().includes(q))
    );
  });

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-1">
          <div className="w-10 h-10 rounded-xl gradient-saffron flex items-center justify-center shadow-md">
            <GraduationCap size={20} className="text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-foreground tracking-tight">Connect with Alumni</h1>
            <p className="text-sm text-muted-foreground">Reach out to alumni from your college for guidance & opportunities</p>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative mb-6 max-w-xl">
        <SearchIcon size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search by name, company, branch, or domain..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-11 h-12 rounded-full text-sm shadow-sm border-border/60 bg-background"
        />
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-44 bg-muted/50 rounded-xl animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <GraduationCap size={48} className="mx-auto mb-4 opacity-20" />
          <p className="font-medium text-lg">No alumni found</p>
          <p className="text-sm mt-1">
            {searchQuery ? "Try a different search term" : "No alumni have registered yet"}
          </p>
        </div>
      ) : (
        <>
          <p className="text-sm text-muted-foreground mb-4">{filtered.length} alumni found</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((profile, i) => (
              <motion.div
                key={profile.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
              >
                <Card
                  className="cursor-pointer hover:shadow-lg transition-all duration-200 hover:-translate-y-1 border-border/60 group overflow-hidden"
                  onClick={() => navigate(`/profile/${profile.user_id}`)}
                >
                  <CardContent className="p-0">
                    <div className="h-1 gradient-saffron opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <div className="p-5">
                      <div className="flex items-start gap-4">
                        <ProfilePhoto
                          fullName={profile.full_name}
                          gender={profile.gender}
                          photoUrl={profile.photo_url}
                          showPhoto={profile.show_photo}
                          size="md"
                        />
                        <div className="flex-1 min-w-0">
                          <h3 className="font-bold text-foreground truncate text-base">{profile.full_name}</h3>
                          <div className="flex flex-col gap-1 mt-1 text-xs text-muted-foreground">
                            {profile.company_name && (
                              <span className="flex items-center gap-1">
                                <Building2 size={11} /> {profile.company_name}
                              </span>
                            )}
                            <span className="flex items-center gap-1">
                              <Briefcase size={11} /> {profile.tech_or_non_tech || "N/A"}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar size={11} /> Passout: {profile.year_of_passout || "N/A"}
                            </span>
                            <span className="flex items-center gap-1">
                              <GraduationCap size={11} /> {profile.branch}
                            </span>
                          </div>
                          {profile.skills && profile.skills.length > 0 && (
                            <div className="flex flex-wrap gap-1.5 mt-2">
                              {profile.skills.map((skill) => (
                                <Badge key={skill} variant="secondary" className="text-xs font-medium px-2 py-0.5">
                                  {skill}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </>
      )}
    </motion.div>
  );
}
