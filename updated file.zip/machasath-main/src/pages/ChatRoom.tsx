import { useEffect, useRef, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import ProfilePhoto from "@/components/ProfilePhoto";
import type { Tables } from "@/integrations/supabase/types";
import { ArrowLeft, Send, AlertTriangle, Check, CheckCheck } from "lucide-react";
import { toast } from "sonner";
import { mapErrorMessage } from "@/lib/errorMessages";

type Message = Tables<"messages"> & { read_at?: string | null };
type Profile = Tables<"profiles">;

const DAILY_MESSAGE_LIMIT = 25;

export default function ChatRoom() {
  const { partnerId } = useParams<{ partnerId: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [messages, setMessages] = useState<Message[]>([]);
  const [partner, setPartner] = useState<Profile | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const [dailyCount, setDailyCount] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const fetchDailyCount = async () => {
    if (!user) return;
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const { count } = await supabase
      .from("messages")
      .select("*", { count: "exact", head: true })
      .eq("sender_id", user.id)
      .gte("created_at", todayStart.toISOString());

    setDailyCount(count || 0);
  };

  // Mark unread messages from partner as read
  const markAsRead = async () => {
    if (!user || !partnerId) return;
    await supabase
      .from("messages")
      .update({ read_at: new Date().toISOString() })
      .eq("sender_id", partnerId)
      .eq("receiver_id", user.id)
      .is("read_at", null);
  };

  useEffect(() => {
    if (!user || !partnerId) return;

    const fetchData = async () => {
      setLoading(true);

      const { data: partnerData } = await supabase
        .from("profiles")
        .select("*")
        .eq("user_id", partnerId)
        .maybeSingle();
      setPartner(partnerData);

      const { data: messagesData } = await supabase
        .from("messages")
        .select("*")
        .or(
          `and(sender_id.eq.${user.id},receiver_id.eq.${partnerId}),and(sender_id.eq.${partnerId},receiver_id.eq.${user.id})`
        )
        .order("created_at", { ascending: true });

      setMessages((messagesData || []) as Message[]);
      setLoading(false);

      // Mark messages as read after loading
      await markAsRead();
    };

    fetchData();
    fetchDailyCount();

    const channel = supabase
      .channel(`chat-${user.id}-${partnerId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
        },
        (payload) => {
          const newMsg = payload.new as Message;
          if (
            (newMsg.sender_id === user.id && newMsg.receiver_id === partnerId) ||
            (newMsg.sender_id === partnerId && newMsg.receiver_id === user.id)
          ) {
            setMessages((prev) => {
              if (prev.find((m) => m.id === newMsg.id)) return prev;
              return [...prev, newMsg];
            });
            // If it's from partner, mark as read immediately
            if (newMsg.sender_id === partnerId) {
              markAsRead();
            }
          }
        }
      )
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "messages",
        },
        (payload) => {
          const updated = payload.new as Message;
          // Update read_at for our sent messages (partner read them)
          if (updated.sender_id === user.id && updated.receiver_id === partnerId && updated.read_at) {
            setMessages((prev) =>
              prev.map((m) => (m.id === updated.id ? { ...m, read_at: updated.read_at } : m))
            );
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, partnerId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const remainingMessages = DAILY_MESSAGE_LIMIT - dailyCount;
  const isLimitReached = remainingMessages <= 0;

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !partnerId || !newMessage.trim()) return;

    if (isLimitReached) {
      toast.error("Daily message limit reached", {
        description: `You can send up to ${DAILY_MESSAGE_LIMIT} messages per day.`,
      });
      return;
    }

    setSending(true);
    try {
      const { error } = await supabase.from("messages").insert({
        sender_id: user.id,
        receiver_id: partnerId,
        content: newMessage.trim(),
      });
      if (error) throw error;
      setNewMessage("");
      setDailyCount((prev) => prev + 1);
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    } finally {
      setSending(false);
    }
  };

  // Find the last message sent by me that has been read
  const getLastReadId = () => {
    const myMessages = messages.filter(m => m.sender_id === user?.id);
    for (let i = myMessages.length - 1; i >= 0; i--) {
      if (myMessages[i].read_at) return myMessages[i].id;
    }
    return null;
  };

  const lastReadId = getLastReadId();

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-7rem)]">
      {/* Header */}
      <div className="flex items-center gap-3 pb-4 border-b border-border">
        <Button variant="ghost" size="sm" onClick={() => navigate("/chat")}>
          <ArrowLeft size={16} />
        </Button>
        {partner && (
          <>
            <ProfilePhoto
              fullName={partner.full_name}
              gender={partner.gender}
              photoUrl={partner.photo_url}
              showPhoto={partner.show_photo}
              size="sm"
            />
            <div className="flex-1">
              <p className="font-semibold text-foreground">{partner.full_name}</p>
              <p className="text-xs text-muted-foreground">
                {partner.branch} · {partner.year_of_study === 0 ? "N/A" : `Year ${partner.year_of_study}`}
              </p>
            </div>
          </>
        )}
        <div className="text-xs text-muted-foreground text-right">
          <span className={remainingMessages <= 5 ? "text-destructive font-semibold" : ""}>
            {remainingMessages}/{DAILY_MESSAGE_LIMIT}
          </span>
          <p className="text-[10px]">msgs left today</p>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto py-4 space-y-3">
        {messages.length === 0 ? (
          <div className="text-center text-muted-foreground text-sm py-8">
            <p className="text-2xl mb-2">👋</p>
            <p className="font-medium">No messages yet</p>
            <p className="text-xs mt-1">Say hello to start collaborating!</p>
          </div>
        ) : (
          messages.map((msg) => {
            const isMine = msg.sender_id === user?.id;
            const isRead = isMine && !!msg.read_at;
            const isLastRead = isMine && msg.id === lastReadId;
            return (
              <div key={msg.id}>
                <div className={`flex ${isMine ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[75%] px-4 py-2.5 text-sm ${
                      isMine
                        ? "bg-primary text-primary-foreground rounded-2xl rounded-br-md"
                        : "bg-muted text-foreground rounded-2xl rounded-bl-md"
                    }`}
                  >
                    <p className="leading-relaxed">{msg.content}</p>
                    <div className={`flex items-center gap-1 mt-1 ${
                      isMine ? "justify-end" : ""
                    }`}>
                      <p className={`text-[10px] ${
                        isMine ? "text-primary-foreground/60" : "text-muted-foreground"
                      }`}>
                        {new Date(msg.created_at).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </p>
                      {isMine && (
                        isRead ? (
                          <CheckCheck size={12} className="text-blue-300" />
                        ) : (
                          <Check size={12} className="text-primary-foreground/50" />
                        )
                      )}
                    </div>
                  </div>
                </div>
                {isLastRead && (
                  <p className="text-[10px] text-blue-400 text-right mt-0.5 mr-1 font-medium">Seen</p>
                )}
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Daily limit warning */}
      {isLimitReached && (
        <div className="flex items-center gap-2 px-3 py-2 bg-destructive/10 rounded-lg text-sm text-destructive mb-2">
          <AlertTriangle size={14} />
          Daily message limit reached ({DAILY_MESSAGE_LIMIT}/day). Try again tomorrow.
        </div>
      )}

      {/* Send form */}
      <form onSubmit={sendMessage} className="flex gap-2 pt-4 border-t border-border">
        <Input
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder={isLimitReached ? "Limit reached for today" : "Type a message..."}
          maxLength={1000}
          className="flex-1"
          disabled={isLimitReached}
        />
        <Button
          type="submit"
          disabled={sending || !newMessage.trim() || isLimitReached}
          className="px-4"
        >
          <Send size={16} />
        </Button>
      </form>
    </div>
  );
}
