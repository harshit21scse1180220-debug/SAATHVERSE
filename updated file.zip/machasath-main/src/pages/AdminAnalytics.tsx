import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import {
  Shield, BarChart3, TrendingUp, Download, FileSpreadsheet,
  Users, Activity, Zap, GraduationCap, MapPin, GitBranch, ArrowLeft
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, AreaChart, Area, RadialBarChart, RadialBar
} from "recharts";

const COLORS = [
  "hsl(24, 95%, 53%)", "hsl(221, 83%, 53%)", "hsl(142, 71%, 45%)",
  "hsl(280, 67%, 50%)", "hsl(0, 72%, 50%)", "hsl(45, 93%, 47%)",
  "hsl(180, 60%, 45%)", "hsl(330, 70%, 55%)"
];

const fadeUp = {
  initial: { opacity: 0, y: 16 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4 },
};

export default function AdminAnalytics() {
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [pageViews, setPageViews] = useState<{ page: string; count: number }[]>([]);
  const [eventBreakdown, setEventBreakdown] = useState<{ event: string; count: number }[]>([]);
  const [dailySignups, setDailySignups] = useState<{ date: string; count: number }[]>([]);
  const [branchDistribution, setBranchDistribution] = useState<{ branch: string; count: number }[]>([]);
  const [genderDistribution, setGenderDistribution] = useState<{ gender: string; count: number }[]>([]);
  const [collegeDistribution, setCollegeDistribution] = useState<{ college: string; count: number }[]>([]);
  const [skillsPopularity, setSkillsPopularity] = useState<{ skill: string; count: number }[]>([]);
  const [hackathonInterest, setHackathonInterest] = useState({ interested: 0, notInterested: 0 });
  const [alumniCount, setAlumniCount] = useState({ alumni: 0, students: 0 });
  const [totalEvents, setTotalEvents] = useState(0);
  const [totalProfiles, setTotalProfiles] = useState(0);
  const [mutationFailures, setMutationFailures] = useState(0);
  const [adminActions, setAdminActions] = useState(0);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    if (!isAdmin) return;
    fetchAnalytics();
  }, [isAdmin]);

  const fetchAnalytics = async () => {
    setLoading(true);

    const [eventsRes, profilesRes] = await Promise.all([
      supabase.from("event_logs").select("event_type, metadata, created_at").order("created_at", { ascending: false }).limit(1000),
      supabase.from("profiles").select("branch, gender, college_name, skills, interested_in_hackathons, is_alumni, created_at").limit(1000),
    ]);

    const events = eventsRes.data || [];
    const profiles = profilesRes.data || [];

    setTotalEvents(events.length);
    setTotalProfiles(profiles.length);

    // Event analytics
    const pvMap: Record<string, number> = {};
    const evMap: Record<string, number> = {};
    const signupMap: Record<string, number> = {};

    let failCount = 0;
    let adminCount = 0;

    events.forEach((e) => {
      evMap[e.event_type] = (evMap[e.event_type] || 0) + 1;
      if (e.event_type === "page_view") {
        const meta = e.metadata as Record<string, unknown> | null;
        const label = (meta?.label as string) || (meta?.page as string) || "Unknown";
        pvMap[label] = (pvMap[label] || 0) + 1;
      }
      if (e.event_type === "profile_created") {
        const day = e.created_at.slice(0, 10);
        signupMap[day] = (signupMap[day] || 0) + 1;
      }
      // Track mutation failures & admin actions
      if (e.event_type === "feature_click") {
        const meta = e.metadata as Record<string, unknown> | null;
        if (meta?.action === "mutation_failed") failCount++;
        if (meta?.type === "admin_action") adminCount++;
      }
    });

    setMutationFailures(failCount);
    setAdminActions(adminCount);

    setPageViews(Object.entries(pvMap).map(([page, count]) => ({ page, count })).sort((a, b) => b.count - a.count));
    setEventBreakdown(Object.entries(evMap).map(([event, count]) => ({ event: event.replace(/_/g, " "), count })).sort((a, b) => b.count - a.count));
    setDailySignups(Object.entries(signupMap).map(([date, count]) => ({ date, count })).sort((a, b) => a.date.localeCompare(b.date)).slice(-30));

    // Profile analytics
    const brMap: Record<string, number> = {};
    const gnMap: Record<string, number> = {};
    const clMap: Record<string, number> = {};
    const skMap: Record<string, number> = {};
    let hackYes = 0, hackNo = 0, alum = 0, stu = 0;

    profiles.forEach((p) => {
      brMap[p.branch] = (brMap[p.branch] || 0) + 1;
      gnMap[p.gender] = (gnMap[p.gender] || 0) + 1;
      clMap[p.college_name] = (clMap[p.college_name] || 0) + 1;
      (p.skills || []).forEach((s: string) => { skMap[s] = (skMap[s] || 0) + 1; });
      if (p.interested_in_hackathons) hackYes++; else hackNo++;
      if (p.is_alumni) alum++; else stu++;
    });

    setBranchDistribution(Object.entries(brMap).map(([branch, count]) => ({ branch, count })).sort((a, b) => b.count - a.count));
    setGenderDistribution(Object.entries(gnMap).map(([gender, count]) => ({ gender, count })));
    setCollegeDistribution(Object.entries(clMap).map(([college, count]) => ({ college, count })).sort((a, b) => b.count - a.count).slice(0, 10));
    setSkillsPopularity(Object.entries(skMap).map(([skill, count]) => ({ skill, count })).sort((a, b) => b.count - a.count).slice(0, 12));
    setHackathonInterest({ interested: hackYes, notInterested: hackNo });
    setAlumniCount({ alumni: alum, students: stu });

    setLoading(false);
  };

  const handleExportCSV = async () => {
    setExporting(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Not authenticated");

      const res = await supabase.functions.invoke("export-profiles-excel", {
        headers: { Authorization: `Bearer ${session.access_token}` },
      });

      if (res.error) throw res.error;

      // The response is CSV text
      const csvText = typeof res.data === "string" ? res.data : await res.data?.text?.() || JSON.stringify(res.data);
      
      const blob = new Blob(["\uFEFF" + csvText], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `student_registrations_${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast.success("CSV file downloaded! Open with Excel.");
    } catch (error: unknown) {
      console.error(error);
      toast.error("Failed to export.");
    } finally {
      setExporting(false);
    }
  };

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-muted-foreground">
        <Shield size={48} className="mb-4 opacity-20" />
        <p className="text-lg font-semibold">Access Denied</p>
      </div>
    );
  }

  const hackathonData = [
    { name: "Interested", value: hackathonInterest.interested, fill: COLORS[0] },
    { name: "Not Interested", value: hackathonInterest.notInterested, fill: COLORS[1] },
  ];

  const alumniData = [
    { name: "Alumni", value: alumniCount.alumni, fill: COLORS[2] },
    { name: "Students", value: alumniCount.students, fill: COLORS[3] },
  ];

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate("/admin/dashboard")} className="p-2 rounded-full hover:bg-muted transition-colors">
              <ArrowLeft size={20} className="text-foreground" />
            </button>
            <div className="w-12 h-12 rounded-2xl gradient-saffron flex items-center justify-center shadow-lg">
              <BarChart3 size={24} className="text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-extrabold text-foreground tracking-tight">Analytics & Insights</h1>
              <p className="text-sm text-muted-foreground">Understand student behavior & export data</p>
            </div>
          </div>
          <Button onClick={handleExportCSV} disabled={exporting} size="lg" className="gap-2 shadow-lg">
            <FileSpreadsheet size={18} />
            {exporting ? "Exporting..." : "📥 Export All Registrations (CSV)"}
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => <div key={i} className="h-28 bg-muted/50 rounded-2xl animate-pulse" />)}
          {[1, 2].map(i => <div key={i} className="h-72 bg-muted/50 rounded-2xl animate-pulse col-span-1 sm:col-span-2" />)}
        </div>
      ) : (
        <div className="space-y-6">
          {/* Stat Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: "Total Students", value: totalProfiles, icon: Users, gradient: "gradient-saffron" },
              { label: "Total Events", value: totalEvents, icon: Activity, gradient: "gradient-navy" },
              { label: "Mutation Failures", value: mutationFailures, icon: Zap, gradient: mutationFailures > 0 ? "bg-destructive/80" : "gradient-saffron" },
              { label: "Admin Actions", value: adminActions, icon: Shield, gradient: "gradient-navy" },
            ].map((card, i) => (
              <motion.div key={card.label} {...fadeUp} transition={{ delay: i * 0.1 }}>
                <Card className="relative overflow-hidden border-border/40 hover:border-primary/30 transition-colors">
                  <div className={`absolute inset-0 ${card.gradient} opacity-[0.04]`} />
                  <CardContent className="pt-5 pb-4 relative">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl ${card.gradient} flex items-center justify-center shadow-md`}>
                        <card.icon size={18} className="text-primary-foreground" />
                      </div>
                      <div>
                        <p className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">{card.label}</p>
                        <p className="text-2xl font-extrabold text-foreground">{card.value}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Row: Page Views + Activity Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {pageViews.length > 0 && (
              <motion.div {...fadeUp} transition={{ delay: 0.2 }}>
                <Card className="border-border/40">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-bold flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-primary" />
                      Most Visited Pages
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={280}>
                      <BarChart data={pageViews} layout="vertical" margin={{ left: 20 }}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border/40" />
                        <XAxis type="number" tick={{ fontSize: 11 }} className="fill-muted-foreground" />
                        <YAxis type="category" dataKey="page" tick={{ fontSize: 11 }} width={90} className="fill-muted-foreground" />
                        <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))" }} />
                        <Bar dataKey="count" fill="hsl(24, 95%, 53%)" radius={[0, 8, 8, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {eventBreakdown.length > 0 && (
              <motion.div {...fadeUp} transition={{ delay: 0.3 }}>
                <Card className="border-border/40">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-bold flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-accent" />
                      Activity Breakdown
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={280}>
                      <PieChart>
                        <Pie
                          data={eventBreakdown}
                          dataKey="count"
                          nameKey="event"
                          cx="50%"
                          cy="50%"
                          outerRadius={90}
                          innerRadius={45}
                          paddingAngle={3}
                          label={({ event, percent }) => `${event} ${(percent * 100).toFixed(0)}%`}
                          labelLine={{ strokeWidth: 1 }}
                        >
                          {eventBreakdown.map((_, i) => (
                            <Cell key={i} fill={COLORS[i % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))" }} />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>

          {/* Row: Branch Distribution + Gender */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {branchDistribution.length > 0 && (
              <motion.div {...fadeUp} transition={{ delay: 0.35 }}>
                <Card className="border-border/40">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-bold flex items-center gap-2">
                      <GraduationCap size={14} className="text-primary" />
                      Students by Branch
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={280}>
                      <BarChart data={branchDistribution}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border/40" />
                        <XAxis dataKey="branch" tick={{ fontSize: 9 }} angle={-25} textAnchor="end" height={60} className="fill-muted-foreground" />
                        <YAxis tick={{ fontSize: 11 }} className="fill-muted-foreground" />
                        <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))" }} />
                        <Bar dataKey="count" radius={[8, 8, 0, 0]}>
                          {branchDistribution.map((_, i) => (
                            <Cell key={i} fill={COLORS[i % COLORS.length]} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {genderDistribution.length > 0 && (
              <motion.div {...fadeUp} transition={{ delay: 0.4 }}>
                <Card className="border-border/40">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-bold flex items-center gap-2">
                      <Users size={14} className="text-primary" />
                      Gender & Interest Split
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      {/* Gender Pie */}
                      <div>
                        <p className="text-xs font-semibold text-muted-foreground text-center mb-1">Gender</p>
                        <ResponsiveContainer width="100%" height={200}>
                          <PieChart>
                            <Pie data={genderDistribution} dataKey="count" nameKey="gender" cx="50%" cy="50%" outerRadius={60} innerRadius={30}>
                              {genderDistribution.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                            </Pie>
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 10 }} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                      {/* Hackathon Interest Pie */}
                      <div>
                        <p className="text-xs font-semibold text-muted-foreground text-center mb-1">Hackathon Interest</p>
                        <ResponsiveContainer width="100%" height={200}>
                          <PieChart>
                            <Pie data={hackathonData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={60} innerRadius={30}>
                              {hackathonData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                            </Pie>
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 10 }} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>

          {/* Row: Daily Signups (Area) + Top Skills */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {dailySignups.length > 0 && (
              <motion.div {...fadeUp} transition={{ delay: 0.45 }}>
                <Card className="border-border/40">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-bold flex items-center gap-2">
                      <TrendingUp size={14} className="text-primary" />
                      Signup Trend (Last 30 days)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={250}>
                      <AreaChart data={dailySignups}>
                        <defs>
                          <linearGradient id="signupGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="hsl(24, 95%, 53%)" stopOpacity={0.4} />
                            <stop offset="100%" stopColor="hsl(24, 95%, 53%)" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border/40" />
                        <XAxis dataKey="date" tick={{ fontSize: 9 }} className="fill-muted-foreground" />
                        <YAxis tick={{ fontSize: 11 }} className="fill-muted-foreground" />
                        <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))" }} />
                        <Area type="monotone" dataKey="count" stroke="hsl(24, 95%, 53%)" fill="url(#signupGrad)" strokeWidth={2.5} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {skillsPopularity.length > 0 && (
              <motion.div {...fadeUp} transition={{ delay: 0.5 }}>
                <Card className="border-border/40">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-bold flex items-center gap-2">
                      <Zap size={14} className="text-primary" />
                      Most Popular Skills
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={250}>
                      <BarChart data={skillsPopularity} layout="vertical" margin={{ left: 10 }}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border/40" />
                        <XAxis type="number" tick={{ fontSize: 11 }} className="fill-muted-foreground" />
                        <YAxis type="category" dataKey="skill" tick={{ fontSize: 10 }} width={100} className="fill-muted-foreground" />
                        <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))" }} />
                        <Bar dataKey="count" radius={[0, 8, 8, 0]}>
                          {skillsPopularity.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>

          {/* Row: College Distribution + Alumni vs Students */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {collegeDistribution.length > 0 && (
              <motion.div {...fadeUp} transition={{ delay: 0.55 }}>
                <Card className="border-border/40">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-bold flex items-center gap-2">
                      <MapPin size={14} className="text-primary" />
                      Top Colleges
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={280}>
                      <BarChart data={collegeDistribution}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border/40" />
                        <XAxis dataKey="college" tick={{ fontSize: 8 }} angle={-20} textAnchor="end" height={70} className="fill-muted-foreground" />
                        <YAxis tick={{ fontSize: 11 }} className="fill-muted-foreground" />
                        <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))" }} />
                        <Bar dataKey="count" fill="hsl(221, 83%, 53%)" radius={[8, 8, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            <motion.div {...fadeUp} transition={{ delay: 0.6 }}>
              <Card className="border-border/40">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-bold flex items-center gap-2">
                    <GraduationCap size={14} className="text-primary" />
                    Alumni vs Active Students
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={280}>
                    <PieChart>
                      <Pie data={alumniData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} innerRadius={55} paddingAngle={4}>
                        {alumniData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                      </Pie>
                      <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))" }} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex justify-center gap-6 mt-2">
                    <Badge variant="outline" className="text-xs">🎓 Alumni: {alumniCount.alumni}</Badge>
                    <Badge variant="outline" className="text-xs">📚 Students: {alumniCount.students}</Badge>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      )}
    </motion.div>
  );
}
