import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, GripVertical, Image as ImageIcon, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { mapErrorMessage } from "@/lib/errorMessages";
import { useImageUpload } from "@/components/ImageCropper";

type Slide = {
  id: string;
  title: string;
  description: string | null;
  hyperlink: string | null;
  media_url: string | null;
  category: string;
  is_active: boolean;
  display_order: number;
  created_by: string;
};

const CATEGORIES = [
  { value: "hackathon", label: "Hackathon" },
  { value: "result", label: "Results" },
  { value: "event", label: "Event" },
  { value: "update", label: "Update" },
  { value: "ieee", label: "IEEE" },
  { value: "club", label: "Club" },
  { value: "startup", label: "Startups" },
];

export default function AdminCarousel() {
  const { user, activeCollegeId: collegeId } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [slides, setSlides] = useState<Slide[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  // New slide form
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [hyperlink, setHyperlink] = useState("");
  const [category, setCategory] = useState("update");
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const slideCrop = useImageUpload("carousel", (f) => setMediaFile(f));

  useEffect(() => {
    if (!user) return;
    supabase.rpc("has_role", { _user_id: user.id, _role: "admin" }).then(({ data }) => {
      setIsAdmin(!!data);
    });
  }, [user]);

  const fetchSlides = async () => {
    let query = supabase
      .from("carousel_slides")
      .select("*")
      .order("display_order", { ascending: true });
    if (collegeId) query = query.eq("college_id", collegeId);
    const { data } = await query;
    if (data) setSlides(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchSlides();
  }, []);

  const uploadMedia = async (file: File): Promise<string | null> => {
    const ext = file.name.split(".").pop();
    const path = `${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from("carousel-media").upload(path, file);
    if (error) {
      toast({ title: "Upload failed", description: mapErrorMessage(error), variant: "destructive" });
      return null;
    }
    const { data } = supabase.storage.from("carousel-media").getPublicUrl(path);
    return data.publicUrl;
  };

  const handleAdd = async () => {
    if (!title.trim() || !user) return;
    setSubmitting(true);

    let media_url: string | null = null;
    if (mediaFile) {
      media_url = await uploadMedia(mediaFile);
      if (!media_url) { setSubmitting(false); return; }
    }

    const { error } = await supabase.from("carousel_slides").insert({
      title: title.trim(),
      description: description.trim() || null,
      hyperlink: hyperlink.trim() || null,
      media_url,
      category,
      display_order: slides.length,
      created_by: user.id,
      college_id: collegeId,
    });

    if (error) {
      toast({ title: "Error", description: mapErrorMessage(error), variant: "destructive" });
    } else {
      toast({ title: "Slide added" });
      setTitle(""); setDescription(""); setHyperlink(""); setMediaFile(null); setCategory("update");
      fetchSlides();
    }
    setSubmitting(false);
  };

  const toggleActive = async (slide: Slide) => {
    await supabase.from("carousel_slides").update({ is_active: !slide.is_active }).eq("id", slide.id);
    fetchSlides();
  };

  const deleteSlide = async (id: string, media_url: string | null) => {
    if (media_url) {
      const path = media_url.split("/carousel-media/")[1];
      if (path) await supabase.storage.from("carousel-media").remove([path]);
    }
    await supabase.from("carousel_slides").delete().eq("id", id);
    fetchSlides();
  };

  if (!isAdmin) {
    return (
      <div className="text-center py-16 text-muted-foreground">
        <p className="text-lg font-medium">Admin access required</p>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center gap-3 mb-1">
        <button onClick={() => navigate("/admin/dashboard")} className="p-2 rounded-full hover:bg-muted transition-colors">
          <ArrowLeft size={20} className="text-foreground" />
        </button>
        <h1 className="text-2xl font-bold text-foreground">Manage Carousel</h1>
      </div>
      <p className="text-muted-foreground text-sm mb-6">Add announcements, hackathons & college updates</p>

      {/* Add form */}
      <div className="p-4 bg-card rounded-xl border border-border/60 shadow-sm mb-6 space-y-3">
        <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <Plus size={14} /> New Slide
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Input placeholder="Title *" value={title} onChange={(e) => setTitle(e.target.value)} />
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {CATEGORIES.map((c) => (
                <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Textarea placeholder="Description (optional)" value={description} onChange={(e) => setDescription(e.target.value)} rows={2} />
        <Input placeholder="Hyperlink (optional)" value={hyperlink} onChange={(e) => setHyperlink(e.target.value)} />
        <div>
          <button type="button" onClick={slideCrop.triggerUpload} className="flex items-center gap-2 cursor-pointer text-sm text-muted-foreground border border-dashed border-border rounded-lg px-4 py-2 hover:bg-muted/50 transition-colors w-full">
            <ImageIcon size={14} />
            {mediaFile ? mediaFile.name : "Upload & crop image (4:3)"}
          </button>
          <slideCrop.CropperModal />
        </div>
        <Button onClick={handleAdd} disabled={submitting || !title.trim()} size="sm">
          {submitting ? "Adding..." : "Add Slide"}
        </Button>
      </div>

      {/* Existing slides */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2].map((i) => <div key={i} className="h-20 bg-muted/50 rounded-xl animate-pulse" />)}
        </div>
      ) : slides.length === 0 ? (
        <p className="text-center text-muted-foreground py-8">No slides yet</p>
      ) : (
        <div className="space-y-3">
          {slides.map((slide) => (
            <div key={slide.id} className="flex items-center gap-3 p-3 bg-card rounded-xl border border-border/60">
              <GripVertical size={16} className="text-muted-foreground/40 shrink-0" />
              {slide.media_url && (
                <img src={slide.media_url} alt="" className="w-16 h-12 rounded-lg object-cover shrink-0" />
              )}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">{slide.title}</p>
                <p className="text-xs text-muted-foreground capitalize">{slide.category}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Switch checked={slide.is_active} onCheckedChange={() => toggleActive(slide)} />
                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => deleteSlide(slide.id, slide.media_url)}>
                  <Trash2 size={14} />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
