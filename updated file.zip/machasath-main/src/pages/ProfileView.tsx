import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import ProfilePhoto from "@/components/ProfilePhoto";
import { toast } from "sonner";
import { mapErrorMessage } from "@/lib/errorMessages";
import { logEvent } from "@/lib/eventLog";
import type { Tables } from "@/integrations/supabase/types";
import { ArrowLeft, Send, Check, X, MessageCircle, Building2, Briefcase, Calendar, GraduationCap, Award, UserX, ShieldBan } from "lucide-react";
import { motion } from "framer-motion";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

type Profile = Tables<"profiles">;

export default function ProfileView() {
  const { userId } = useParams<{ userId: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [profile, setProfile] = useState<Profile | null>(null);
  const [myProfile, setMyProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [requestMessage, setRequestMessage] = useState("");
  const [showRequestForm, setShowRequestForm] = useState(false);
  const [sendingRequest, setSendingRequest] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [existingRequest, setExistingRequest] = useState<Tables<"collaboration_requests"> | null>(null);
  const [affiliations, setAffiliations] = useState<{ role: string; section_title: string; section_type: string }[]>([]);

  const fetchConnectionState = async () => {
    if (!user || !userId || userId === user.id) return;
    const { data: requestData } = await supabase
      .from("collaboration_requests")
      .select("*")
      .or(
        `and(sender_id.eq.${user.id},receiver_id.eq.${userId}),and(sender_id.eq.${userId},receiver_id.eq.${user.id})`
      )
      .maybeSingle();
    setExistingRequest(requestData);
  };

  useEffect(() => {
    if (!userId) return;

    const fetchData = async () => {
      setLoading(true);

      const [profileRes, myProfileRes] = await Promise.all([
        supabase.from("profiles").select("*").eq("user_id", userId).maybeSingle(),
        user ? supabase.from("profiles").select("*").eq("user_id", user.id).maybeSingle() : Promise.resolve({ data: null }),
      ]);

      const profileData = profileRes.data;
      setProfile(profileData);
      setMyProfile(myProfileRes.data);

      if (profileData) {
        const { data: affData } = await supabase
          .from("student_affiliations")
          .select("role, section_id")
          .eq("profile_id", profileData.id);
        if (affData && affData.length > 0) {
          const sectionIds = affData.map(a => a.section_id);
          const { data: sections } = await supabase
            .from("content_sections")
            .select("id, title, section_type")
            .in("id", sectionIds);
          const sectionMap = new Map((sections || []).map(s => [s.id, s]));
          setAffiliations(affData.map(a => {
            const sec = sectionMap.get(a.section_id);
            return { role: a.role, section_title: sec?.title || "", section_type: sec?.section_type || "" };
          }));
        }
      }

      await fetchConnectionState();
      setLoading(false);
    };

    fetchData();
  }, [userId, user]);

  const sendRequest = async () => {
    if (!user || !userId) return;
    setSendingRequest(true);
    try {
      const { error } = await supabase.from("collaboration_requests").insert({
        sender_id: user.id,
        receiver_id: userId,
        message: requestMessage.trim(),
      });
      if (error) throw error;
      await logEvent(user.id, "collaboration_request_sent", { receiver_id: userId });
      toast.success("Collaboration request sent!");
      setShowRequestForm(false);
      await fetchConnectionState();
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    } finally {
      setSendingRequest(false);
    }
  };

  const handleUnfriend = async () => {
    if (!existingRequest || !user) return;
    setActionLoading(true);
    try {
      const { error, count } = await supabase
        .from("collaboration_requests")
        .delete()
        .eq("id", existingRequest.id)
        .select();
      if (error) throw error;
      toast.success("Connection removed.");
      setExistingRequest(null);
      // Invalidate all relevant caches so Chat, Requests pages update
      queryClient.invalidateQueries({ queryKey: ["collaboration_requests"] });
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
      queryClient.invalidateQueries({ queryKey: ["chat"] });
      // Re-fetch connection state to confirm deletion
      await fetchConnectionState();
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    } finally {
      setActionLoading(false);
    }
  };

  const handleBlock = async () => {
    if (!existingRequest) return;
    setActionLoading(true);
    try {
      const { error } = await supabase
        .from("collaboration_requests")
        .update({ status: "blocked" })
        .eq("id", existingRequest.id);
      if (error) throw error;
      toast.success("User blocked successfully");
      setExistingRequest({ ...existingRequest, status: "blocked" });
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="text-center py-20 text-muted-foreground">
        <p className="font-medium">Profile not found</p>
        <Button variant="ghost" onClick={() => navigate(-1)} className="mt-4">
          <ArrowLeft size={16} className="mr-2" /> Go Back
        </Button>
      </div>
    );
  }

  const isSelf = user?.id === userId;
  const isAccepted = existingRequest?.status === "accepted";
  const isBlocked = existingRequest?.status === "blocked";
  const myGender = myProfile?.gender?.toLowerCase();
  const canBlock = myGender === "female" && profile.gender?.toLowerCase() === "male";

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <Button variant="ghost" onClick={() => navigate(-1)} className="mb-4">
        <ArrowLeft size={16} className="mr-2" /> Back
      </Button>

      <Card className="border-border/60 shadow-lg max-w-2xl">
        <CardContent className="p-6">
          <div className="flex items-start gap-5">
            <ProfilePhoto
              fullName={profile.full_name}
              gender={profile.gender}
              photoUrl={profile.photo_url}
              showPhoto={profile.show_photo}
              size="lg"
            />
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-foreground">{profile.full_name}</h1>
              <p className="text-muted-foreground">
                {profile.branch} · {profile.year_of_study === 0 ? "N/A" : `Year ${profile.year_of_study}`}
              </p>
              <p className="text-sm text-muted-foreground">{profile.college_name}</p>
              <p className="text-sm text-muted-foreground capitalize">{profile.gender}</p>
            </div>
          </div>

          {profile.bio && (
            <div className="mt-5">
              <h3 className="text-sm font-semibold text-foreground mb-1">About</h3>
              <p className="text-sm text-muted-foreground">{profile.bio}</p>
            </div>
          )}

          {profile.skills && profile.skills.length > 0 && (
            <div className="mt-4">
              <h3 className="text-sm font-semibold text-foreground mb-2">Skills</h3>
              <div className="flex flex-wrap gap-2">
                {profile.skills.map((skill) => (
                  <Badge key={skill} variant="secondary">{skill}</Badge>
                ))}
              </div>
            </div>
          )}

          {profile.is_alumni && (
            <div className="mt-4 p-4 bg-muted/40 rounded-xl">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <GraduationCap size={12} /> Alumni
              </h3>
              <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
                {profile.company_name && (
                  <span className="flex items-center gap-1"><Building2 size={13} /> {profile.company_name}</span>
                )}
                {profile.tech_or_non_tech && (
                  <span className="flex items-center gap-1"><Briefcase size={13} /> {profile.tech_or_non_tech}</span>
                )}
                {profile.year_of_passout && (
                  <span className="flex items-center gap-1"><Calendar size={13} /> Passout: {profile.year_of_passout}</span>
                )}
              </div>
            </div>
          )}

          {affiliations.length > 0 && (
            <div className="mt-4 p-4 bg-muted/40 rounded-xl">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Award size={12} /> Organizations & Affiliations
              </h3>
              <div className="flex flex-wrap gap-2">
                {affiliations.map((aff, i) => (
                  <Badge key={i} variant="outline" className="gap-1.5 py-1 px-3">
                    <span className="font-semibold">{aff.section_title}</span>
                    <span className="text-muted-foreground">·</span>
                    <span className="text-muted-foreground">{aff.role}</span>
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <div className="mt-4">
            <Badge variant={profile.interested_in_hackathons ? "default" : "outline"}>
              {profile.interested_in_hackathons
                ? "🏆 Interested in Hackathons"
                : "Not interested in hackathons"}
            </Badge>
          </div>

          {/* Action buttons */}
          {!isSelf && (
            <div className="mt-6 pt-4 border-t border-border">
              {/* No existing request — show send button */}
              {!existingRequest && !showRequestForm && (
                <Button onClick={() => setShowRequestForm(true)}>
                  <Send size={16} className="mr-2" /> Send Collaboration Request
                </Button>
              )}

              {isBlocked && (
                <Badge variant="destructive">🚫 Blocked</Badge>
              )}

              {showRequestForm && (
                <div className="space-y-3">
                  <Textarea
                    placeholder="Write a short message about why you'd like to collaborate..."
                    value={requestMessage}
                    onChange={(e) => setRequestMessage(e.target.value)}
                    maxLength={500}
                    rows={3}
                  />
                  <div className="flex gap-2">
                    <Button onClick={sendRequest} disabled={sendingRequest}>
                      {sendingRequest ? "Sending..." : "Send Request"}
                    </Button>
                    <Button variant="outline" onClick={() => setShowRequestForm(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              )}

              {existingRequest && !isBlocked && (
                <div className="space-y-3">
                  <Badge
                    variant={
                      existingRequest.status === "accepted"
                        ? "default"
                        : existingRequest.status === "rejected"
                        ? "destructive"
                        : "outline"
                    }
                  >
                    {existingRequest.status === "pending" && "⏳ Request Pending"}
                    {existingRequest.status === "accepted" && "✅ Connected"}
                    {existingRequest.status === "rejected" && "❌ Request Declined"}
                  </Badge>

                  {isAccepted && (
                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => navigate(`/chat/${userId}`)}
                      >
                        <MessageCircle size={16} className="mr-2" /> Open Chat
                      </Button>

                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="outline" size="sm" className="text-destructive border-destructive/30 hover:bg-destructive/10" disabled={actionLoading}>
                            <UserX size={16} className="mr-2" /> Unfriend
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Unfriend {profile.full_name}?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will remove your connection. You won't be able to chat anymore. You can send a new request later.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleUnfriend} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                              Unfriend
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>

                      {canBlock && (
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="destructive" size="sm" disabled={actionLoading}>
                              <ShieldBan size={16} className="mr-2" /> Block
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Block {profile.full_name}?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This will permanently block this user. They won't be able to send you requests or messages anymore.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={handleBlock} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                                Block
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
