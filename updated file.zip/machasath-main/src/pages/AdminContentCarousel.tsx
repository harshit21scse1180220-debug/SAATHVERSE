import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { mapErrorMessage } from "@/lib/errorMessages";
import {
  Shield, Plus, Trash2, Edit2, ChevronDown, ChevronRight,
  Image as ImageIcon, X, GripVertical, Eye, EyeOff, Layers, LayoutGrid, ExternalLink, Search, Crown, User, ArrowLeft
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import type { Tables } from "@/integrations/supabase/types";
import { useImageUpload } from "@/components/ImageCropper";
import { motion } from "framer-motion";

type Section = {
  id: string;
  title: string;
  section_type: string;
  cover_image_url: string | null;
  description: string | null;
  display_order: number;
  is_active: boolean;
  created_by: string;
};

type Card = {
  id: string;
  row_id: string;
  title: string;
  subtitle: string | null;
  image_url: string | null;
  link_url: string | null;
  about_text: string | null;
  banner_image_url: string | null;
  leader_id: string | null;
  co_leader_id: string | null;
  profile_id: string | null;
  display_order: number;
  is_active: boolean;
};

const SECTION_TYPES = [
  { value: "general", label: "General Content" },
  { value: "professional_org", label: "Professional Organization" },
  { value: "college_club", label: "College Club" },
  { value: "entrepreneurship", label: "Entrepreneurship" },
];

export default function AdminContentCarousel() {
  const { isAdmin, user, activeCollegeId: collegeId } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [sections, setSections] = useState<Section[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedSection, setExpandedSection] = useState<string | null>(null);

  // Section form
  const [showSectionForm, setShowSectionForm] = useState(false);
  const [editingSection, setEditingSection] = useState<Section | null>(null);
  const [sTitle, setSTitle] = useState("");
  const [sType, setSType] = useState("general");
  const [sDesc, setSDesc] = useState("");
  const [sCoverFile, setSCoverFile] = useState<File | null>(null);
  const [sSubmitting, setSSubmitting] = useState(false);

  // CTA form
  const [cards, setCards] = useState<Record<string, Card[]>>({});
  const [defaultRowIds, setDefaultRowIds] = useState<Record<string, string>>({});
  const [showCardForm, setShowCardForm] = useState<string | null>(null);
  const [editingCard, setEditingCard] = useState<Card | null>(null);
  const [cTitle, setCTitle] = useState("");
  const [cSubtitle, setCSubtitle] = useState("");
  const [cLink, setCLink] = useState("");
  const [cAbout, setCAbout] = useState("");
  const [cImageFile, setCImageFile] = useState<File | null>(null);
  const [cBannerFile, setCBannerFile] = useState<File | null>(null);
  const [cLeaderId, setCLeaderId] = useState<string | null>(null);

  const coverCrop = useImageUpload("cover", (f) => setSCoverFile(f));
  const thumbnailCrop = useImageUpload("thumbnail", (f) => setCImageFile(f));
  const bannerCrop = useImageUpload("banner", (f) => setCBannerFile(f));
  const [cCoLeaderId, setCCoLeaderId] = useState<string | null>(null);
  const [cSubmitting, setCSubmitting] = useState(false);

  // Student search for leader assignment
  const [leaderSearch, setLeaderSearch] = useState("");
  const [leaderResults, setLeaderResults] = useState<Tables<"profiles">[]>([]);
  const [coLeaderSearch, setCoLeaderSearch] = useState("");
  const [coLeaderResults, setCoLeaderResults] = useState<Tables<"profiles">[]>([]);
  const [leaderProfile, setLeaderProfile] = useState<Tables<"profiles"> | null>(null);
  const [coLeaderProfile, setCoLeaderProfile] = useState<Tables<"profiles"> | null>(null);

  const fetchSections = async () => {
    let query = supabase.from("content_sections").select("*").order("display_order");
    if (collegeId) query = query.eq("college_id", collegeId);
    const { data } = await query;
    if (data) setSections(data as Section[]);
    setLoading(false);
  };

  useEffect(() => { fetchSections(); }, []);

  const ensureDefaultRow = async (sectionId: string): Promise<string> => {
    if (defaultRowIds[sectionId]) return defaultRowIds[sectionId];
    const { data: existingRows } = await supabase.from("content_rows").select("id").eq("section_id", sectionId).order("display_order").limit(1);
    if (existingRows && existingRows.length > 0) {
      setDefaultRowIds(prev => ({ ...prev, [sectionId]: existingRows[0].id }));
      return existingRows[0].id;
    }
    const { data: newRow } = await supabase.from("content_rows").insert({ section_id: sectionId, title: "CTAs", display_order: 0 }).select("id").single();
    if (newRow) {
      setDefaultRowIds(prev => ({ ...prev, [sectionId]: newRow.id }));
      return newRow.id;
    }
    return "";
  };

  const fetchCards = async (sectionId: string) => {
    const { data: rowData } = await supabase.from("content_rows").select("id").eq("section_id", sectionId);
    if (!rowData || rowData.length === 0) { setCards(prev => ({ ...prev, [sectionId]: [] })); return; }
    const rowIds = rowData.map(r => r.id);
    const { data: cardData } = await supabase.from("content_cards").select("*").in("row_id", rowIds).order("display_order");
    setCards(prev => ({ ...prev, [sectionId]: (cardData || []) as Card[] }));
  };

  const searchStudents = async (q: string, setter: (r: Tables<"profiles">[]) => void) => {
    if (!q.trim()) { setter([]); return; }
    const { data } = await supabase.from("profiles").select("*").ilike("full_name", `%${q.trim()}%`).limit(5);
    setter(data || []);
  };

  const uploadMedia = async (file: File): Promise<string | null> => {
    const ext = file.name.split(".").pop();
    const path = `${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from("content-media").upload(path, file);
    if (error) { toast({ title: "Upload failed", description: mapErrorMessage(error), variant: "destructive" }); return null; }
    return supabase.storage.from("content-media").getPublicUrl(path).data.publicUrl;
  };

  // Section CRUD
  const resetSectionForm = () => { setSTitle(""); setSType("general"); setSDesc(""); setSCoverFile(null); setEditingSection(null); setShowSectionForm(false); };
  const startEditSection = (s: Section) => { setSTitle(s.title); setSType(s.section_type); setSDesc(s.description || ""); setEditingSection(s); setShowSectionForm(true); };

  const saveSection = async () => {
    if (!sTitle.trim() || !user) return;
    setSSubmitting(true);
    let cover_image_url = editingSection?.cover_image_url ?? null;
    if (sCoverFile) { cover_image_url = await uploadMedia(sCoverFile); if (!cover_image_url) { setSSubmitting(false); return; } }
    if (editingSection) {
      const { error } = await supabase.from("content_sections").update({ title: sTitle.trim(), section_type: sType, description: sDesc.trim() || null, cover_image_url }).eq("id", editingSection.id);
      if (error) toast({ title: "Error", description: mapErrorMessage(error), variant: "destructive" });
      else { toast({ title: "Section updated" }); resetSectionForm(); fetchSections(); }
    } else {
      const { error } = await supabase.from("content_sections").insert({ title: sTitle.trim(), section_type: sType, description: sDesc.trim() || null, cover_image_url, display_order: sections.length, created_by: user.id, college_id: collegeId });
      if (error) toast({ title: "Error", description: mapErrorMessage(error), variant: "destructive" });
      else { toast({ title: "Section created" }); resetSectionForm(); fetchSections(); }
    }
    setSSubmitting(false);
  };

  const deleteSection = async (id: string) => {
    if (!confirm("Delete this section and all its content?")) return;
    await supabase.from("content_sections").delete().eq("id", id);
    fetchSections();
  };

  const toggleSectionActive = async (s: Section) => {
    await supabase.from("content_sections").update({ is_active: !s.is_active }).eq("id", s.id);
    fetchSections();
  };

  // CTA CRUD
  const resetCardForm = () => {
    setCTitle(""); setCSubtitle(""); setCLink(""); setCAbout(""); setCImageFile(null); setCBannerFile(null);
    setCLeaderId(null); setCCoLeaderId(null); setLeaderProfile(null); setCoLeaderProfile(null);
    setLeaderSearch(""); setCoLeaderSearch(""); setLeaderResults([]); setCoLeaderResults([]);
    setEditingCard(null); setShowCardForm(null);
  };

  const startEditCard = async (card: Card, sectionId: string) => {
    setCTitle(card.title); setCSubtitle(card.subtitle || ""); setCLink(card.link_url || ""); setCAbout(card.about_text || "");
    setCLeaderId(card.leader_id); setCCoLeaderId(card.co_leader_id);
    setEditingCard(card); setShowCardForm(sectionId);
    // Fetch leader profiles
    const ids = [card.leader_id, card.co_leader_id].filter(Boolean) as string[];
    if (ids.length > 0) {
      const { data } = await supabase.from("profiles").select("*").in("id", ids);
      if (data) {
        setLeaderProfile(data.find(p => p.id === card.leader_id) || null);
        setCoLeaderProfile(data.find(p => p.id === card.co_leader_id) || null);
      }
    }
  };

  const saveCard = async (sectionId: string) => {
    if (!cTitle.trim()) return;
    setCSubmitting(true);
    let image_url = editingCard?.image_url ?? null;
    let banner_image_url = editingCard?.banner_image_url ?? null;
    if (cImageFile) { image_url = await uploadMedia(cImageFile); if (!image_url) { setCSubmitting(false); return; } }
    if (cBannerFile) { banner_image_url = await uploadMedia(cBannerFile); if (!banner_image_url) { setCSubmitting(false); return; } }

    const payload = {
      title: cTitle.trim(),
      subtitle: cSubtitle.trim() || null,
      link_url: cLink.trim() || null,
      image_url,
      about_text: cAbout.trim() || null,
      banner_image_url,
      leader_id: cLeaderId,
      co_leader_id: cCoLeaderId,
    };

    if (editingCard) {
      await supabase.from("content_cards").update(payload).eq("id", editingCard.id);
      toast({ title: "CTA updated" });
    } else {
      const rowId = await ensureDefaultRow(sectionId);
      if (!rowId) { setCSubmitting(false); return; }
      const existingCards = cards[sectionId] || [];
      await supabase.from("content_cards").insert({ ...payload, row_id: rowId, display_order: existingCards.length });
      toast({ title: "CTA added" });
    }
    resetCardForm();
    fetchCards(sectionId);
    setCSubmitting(false);
  };

  const deleteCard = async (cardId: string, sectionId: string) => {
    if (!confirm("Delete this CTA?")) return;
    await supabase.from("content_cards").delete().eq("id", cardId);
    fetchCards(sectionId);
  };

  const toggleExpand = (sectionId: string) => {
    if (expandedSection === sectionId) { setExpandedSection(null); return; }
    setExpandedSection(sectionId);
    if (!cards[sectionId]) fetchCards(sectionId);
  };

  if (!isAdmin) {
    return <div className="text-center py-16 text-muted-foreground"><Shield size={48} className="mx-auto mb-4 opacity-20" /><p>Admin access required</p></div>;
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/admin/dashboard")} className="p-2 rounded-full hover:bg-muted transition-colors">
            <ArrowLeft size={20} className="text-foreground" />
          </button>
          <div>
            <h1 className="text-2xl font-extrabold text-foreground tracking-tight flex items-center gap-2">
              <Layers size={22} /> Content Sections
            </h1>
            <p className="text-sm text-muted-foreground">Manage sections & CTA buttons</p>
          </div>
        </div>
        <Button size="sm" onClick={() => { resetSectionForm(); setShowSectionForm(true); }}>
          <Plus size={14} className="mr-1" /> New Section
        </Button>
      </div>

      {/* Section Form Modal */}
      {showSectionForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-lg p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-foreground">{editingSection ? "Edit Section" : "New Section"}</h3>
              <button onClick={resetSectionForm} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
            </div>
            <div className="space-y-1.5"><Label>Title *</Label><Input value={sTitle} onChange={e => setSTitle(e.target.value)} placeholder="e.g. IEEE, Tech Club" /></div>
            <div className="space-y-1.5">
              <Label>Type</Label>
              <Select value={sType} onValueChange={setSType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent side="bottom">{SECTION_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Description</Label><Textarea value={sDesc} onChange={e => setSDesc(e.target.value)} rows={2} placeholder="Short description..." /></div>
            <div className="space-y-1.5">
              <Label>Cover Image — Recommended: 1280×720 px (16:9)</Label>
              {editingSection?.cover_image_url && !sCoverFile && <img src={editingSection.cover_image_url} alt="" className="w-full aspect-[16/9] rounded-xl object-cover mb-2" />}
              <button type="button" onClick={coverCrop.triggerUpload} className="flex items-center gap-2 cursor-pointer text-sm text-muted-foreground border border-dashed border-border rounded-xl px-4 py-3 hover:bg-muted/50 transition-colors w-full">
                <ImageIcon size={16} />{sCoverFile ? sCoverFile.name : "Upload & crop image"}
              </button>
              <coverCrop.CropperModal />
            </div>
            <div className="flex gap-2 pt-2">
              <Button onClick={saveSection} disabled={sSubmitting || !sTitle.trim()} size="sm">{sSubmitting ? "Saving..." : editingSection ? "Update" : "Create Section"}</Button>
              <Button variant="outline" size="sm" onClick={resetSectionForm}>Cancel</Button>
            </div>
          </motion.div>
        </div>
      )}

      {/* CTA Form Modal */}
      {showCardForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-lg p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-foreground">{editingCard ? "Edit CTA" : "New CTA"}</h3>
              <button onClick={resetCardForm} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
            </div>

            {/* Basic Info */}
            <div className="space-y-1.5"><Label>Title / Club Name *</Label><Input value={cTitle} onChange={e => setCTitle(e.target.value)} placeholder="e.g. GU Management Club" /></div>
            <div className="space-y-1.5"><Label>Subtitle</Label><Input value={cSubtitle} onChange={e => setCSubtitle(e.target.value)} placeholder="Short tagline or description" /></div>
            <div className="space-y-1.5"><Label>About Text</Label><Textarea value={cAbout} onChange={e => setCAbout(e.target.value)} rows={3} placeholder="Detailed description about the club..." /></div>
            <div className="space-y-1.5"><Label>Link URL</Label><Input value={cLink} onChange={e => setCLink(e.target.value)} placeholder="https://..." /></div>

            {/* Banner Image */}
            <div className="space-y-1.5">
              <Label>Banner Image — Recommended: 1600×600 px (16:6)</Label>
              {editingCard?.banner_image_url && !cBannerFile && <img src={editingCard.banner_image_url} alt="" className="w-full aspect-[16/6] rounded-xl object-cover mb-2" />}
              <button type="button" onClick={bannerCrop.triggerUpload} className="flex items-center gap-2 cursor-pointer text-sm text-muted-foreground border border-dashed border-border rounded-xl px-4 py-3 hover:bg-muted/50 transition-colors w-full">
                <ImageIcon size={16} />{cBannerFile ? cBannerFile.name : "Upload & crop banner"}
              </button>
              <bannerCrop.CropperModal />
            </div>

            {/* Thumbnail */}
            <div className="space-y-1.5">
              <Label>Thumbnail — Recommended: 800×600 px (4:3)</Label>
              {editingCard?.image_url && !cImageFile && <img src={editingCard.image_url} alt="" className="w-24 aspect-[4/3] rounded-lg object-cover mb-2" />}
              <button type="button" onClick={thumbnailCrop.triggerUpload} className="flex items-center gap-2 cursor-pointer text-sm text-muted-foreground border border-dashed border-border rounded-xl px-4 py-3 hover:bg-muted/50 transition-colors w-full">
                <ImageIcon size={16} />{cImageFile ? cImageFile.name : "Upload & crop thumbnail"}
              </button>
              <thumbnailCrop.CropperModal />
            </div>

            {/* Leadership */}
            <div className="border-t border-border/40 pt-4">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Leadership</p>

              {/* Leader */}
              <div className="space-y-1.5 mb-3">
                <Label className="flex items-center gap-1"><Crown size={12} className="text-amber-500" /> Leader</Label>
                {leaderProfile ? (
                  <div className="flex items-center gap-2 p-2 bg-muted/30 rounded-lg">
                    <div className="w-8 h-8 rounded-full bg-muted overflow-hidden shrink-0">
                      {leaderProfile.photo_url ? <img src={leaderProfile.photo_url} className="w-full h-full object-cover" /> : <User size={16} className="m-auto mt-1.5 text-muted-foreground" />}
                    </div>
                    <span className="text-sm font-medium text-foreground flex-1 truncate">{leaderProfile.full_name}</span>
                    <button onClick={() => { setLeaderProfile(null); setCLeaderId(null); }} className="text-muted-foreground hover:text-destructive"><X size={14} /></button>
                  </div>
                ) : (
                  <div>
                    <Input value={leaderSearch} onChange={e => { setLeaderSearch(e.target.value); searchStudents(e.target.value, setLeaderResults); }} placeholder="Search student by name..." />
                    {leaderResults.length > 0 && (
                      <div className="border border-border rounded-lg mt-1 max-h-32 overflow-y-auto bg-background">
                        {leaderResults.map(p => (
                          <button key={p.id} className="w-full text-left px-3 py-2 text-sm hover:bg-muted/50 flex items-center gap-2" onClick={() => { setLeaderProfile(p); setCLeaderId(p.id); setLeaderSearch(""); setLeaderResults([]); }}>
                            <span className="font-medium">{p.full_name}</span>
                            <span className="text-xs text-muted-foreground">{p.branch}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Co-Leader */}
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1"><Shield size={12} className="text-blue-500" /> Co-Leader</Label>
                {coLeaderProfile ? (
                  <div className="flex items-center gap-2 p-2 bg-muted/30 rounded-lg">
                    <div className="w-8 h-8 rounded-full bg-muted overflow-hidden shrink-0">
                      {coLeaderProfile.photo_url ? <img src={coLeaderProfile.photo_url} className="w-full h-full object-cover" /> : <User size={16} className="m-auto mt-1.5 text-muted-foreground" />}
                    </div>
                    <span className="text-sm font-medium text-foreground flex-1 truncate">{coLeaderProfile.full_name}</span>
                    <button onClick={() => { setCoLeaderProfile(null); setCCoLeaderId(null); }} className="text-muted-foreground hover:text-destructive"><X size={14} /></button>
                  </div>
                ) : (
                  <div>
                    <Input value={coLeaderSearch} onChange={e => { setCoLeaderSearch(e.target.value); searchStudents(e.target.value, setCoLeaderResults); }} placeholder="Search student by name..." />
                    {coLeaderResults.length > 0 && (
                      <div className="border border-border rounded-lg mt-1 max-h-32 overflow-y-auto bg-background">
                        {coLeaderResults.map(p => (
                          <button key={p.id} className="w-full text-left px-3 py-2 text-sm hover:bg-muted/50 flex items-center gap-2" onClick={() => { setCoLeaderProfile(p); setCCoLeaderId(p.id); setCoLeaderSearch(""); setCoLeaderResults([]); }}>
                            <span className="font-medium">{p.full_name}</span>
                            <span className="text-xs text-muted-foreground">{p.branch}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <Button onClick={() => showCardForm && saveCard(showCardForm)} disabled={cSubmitting || !cTitle.trim()} size="sm">{cSubmitting ? "Saving..." : editingCard ? "Update" : "Add CTA"}</Button>
              <Button variant="outline" size="sm" onClick={resetCardForm}>Cancel</Button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Sections List */}
      {loading ? (
        <div className="space-y-3">{[1, 2].map(i => <div key={i} className="h-20 bg-muted/50 rounded-xl animate-pulse" />)}</div>
      ) : sections.length === 0 ? (
        <p className="text-center text-muted-foreground py-12">No sections yet. Create your first one!</p>
      ) : (
        <div className="space-y-3">
          {sections.map(section => (
            <div key={section.id} className="bg-card rounded-xl border border-border/60 overflow-hidden">
              <div className="flex items-center gap-3 p-3 cursor-pointer hover:bg-muted/30 transition-colors" onClick={() => toggleExpand(section.id)}>
                <GripVertical size={16} className="text-muted-foreground/40 shrink-0" />
                {expandedSection === section.id ? <ChevronDown size={16} className="text-muted-foreground shrink-0" /> : <ChevronRight size={16} className="text-muted-foreground shrink-0" />}
                {section.cover_image_url ? (
                  <img src={section.cover_image_url} alt="" className="w-14 h-10 rounded-lg object-cover shrink-0" />
                ) : (
                  <div className="w-14 h-10 rounded-lg bg-muted/50 flex items-center justify-center shrink-0"><LayoutGrid size={14} className="text-muted-foreground/40" /></div>
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground truncate">{section.title}</p>
                  <Badge variant="outline" className="text-[10px] capitalize">{section.section_type.replace("_", " ")}</Badge>
                </div>
                <div className="flex items-center gap-1.5 shrink-0" onClick={e => e.stopPropagation()}>
                  <button onClick={() => toggleSectionActive(section)} className="text-muted-foreground hover:text-foreground">
                    {section.is_active ? <Eye size={15} /> : <EyeOff size={15} className="opacity-50" />}
                  </button>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => startEditSection(section)}><Edit2 size={13} /></Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => deleteSection(section.id)}><Trash2 size={13} /></Button>
                </div>
              </div>

              {expandedSection === section.id && (
                <div className="border-t border-border/40 bg-muted/10 p-3 space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">CTA Buttons</p>
                      <Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => { resetCardForm(); setShowCardForm(section.id); }}>
                        <Plus size={12} className="mr-1" /> Add CTA
                      </Button>
                    </div>
                    {(cards[section.id] || []).length === 0 ? (
                      <p className="text-xs text-muted-foreground text-center py-3">No CTAs yet.</p>
                    ) : (
                      <div className="space-y-2">
                        {(cards[section.id] || []).map(card => (
                          <div key={card.id} className="flex items-center gap-3 p-2.5 bg-background rounded-lg border border-border/40">
                            {card.image_url ? (
                              <img src={card.image_url} alt="" className="w-12 h-12 rounded-lg object-cover shrink-0" />
                            ) : (
                              <div className="w-12 h-12 rounded-lg bg-muted/30 flex items-center justify-center shrink-0"><ExternalLink size={14} className="text-muted-foreground/40" /></div>
                            )}
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-semibold text-foreground truncate">{card.title}</p>
                              {card.subtitle && <p className="text-xs text-muted-foreground truncate">{card.subtitle}</p>}
                              {card.leader_id && <span className="text-[10px] text-primary">Leader assigned</span>}
                            </div>
                            <div className="flex gap-1 shrink-0">
                              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => startEditCard(card, section.id)}><Edit2 size={12} /></Button>
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => deleteCard(card.id, section.id)}><Trash2 size={12} /></Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
}
