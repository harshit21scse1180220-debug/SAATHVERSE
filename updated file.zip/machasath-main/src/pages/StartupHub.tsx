import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import ProfilePhoto from "@/components/ProfilePhoto";
import AnnouncementCarousel from "@/components/AnnouncementCarousel";
import AIScoreBadge from "@/components/AIScoreBadge";
import AIReportModal from "@/components/AIReportModal";
import { Rocket, Plus, X, Send, MessageCircle, Users, ArrowLeft, Check, Filter, Brain, ArrowUpDown } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { mapErrorMessage } from "@/lib/errorMessages";
import type { Tables } from "@/integrations/supabase/types";

type Profile = Tables<"profiles">;

const STARTUP_CATEGORIES = [
  "Tech / SaaS", "EdTech", "FinTech", "HealthTech", "E-Commerce",
  "Social Impact", "Food & Beverage", "Media & Content", "Hardware / IoT",
  "AI / ML", "Gaming", "Other",
] as const;

interface StartupIdea {
  id: string;
  creator_id: string;
  title: string;
  description: string | null;
  category: string | null;
  status: string;
  created_at: string;
  ai_overall_score: number | null;
  ai_clarity_score: number | null;
  ai_market_score: number | null;
  ai_feasibility_score: number | null;
  ai_innovation: string | null;
  ai_difficulty: string | null;
  ai_strengths: string | null;
  ai_risks: string | null;
  ai_suggestions: string | null;
  ai_summary: string | null;
  ai_evaluated_at: string | null;
}

interface StartupJoinRequest {
  id: string;
  startup_id: string;
  user_id: string;
  message: string | null;
  status: string;
  created_at: string;
}

export default function StartupHub() {
  const { user, collegeId } = useAuth();
  const navigate = useNavigate();
  const [ideas, setIdeas] = useState<StartupIdea[]>([]);
  const [profiles, setProfiles] = useState<Map<string, Profile>>(new Map());
  const [joinRequests, setJoinRequests] = useState<StartupJoinRequest[]>([]);
  const [loading, setLoading] = useState(true);

  // Create idea
  const [showCreate, setShowCreate] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newCategory, setNewCategory] = useState("Other");
  const [creating, setCreating] = useState(false);
  const [filterCategory, setFilterCategory] = useState("all");
  const [sortBy, setSortBy] = useState("newest");

  // Chat
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [msgInput, setMsgInput] = useState("");
  const [sendingMsg, setSendingMsg] = useState(false);
  const chatRef = useRef<HTMLDivElement>(null);

  // AI
  const [evaluatingIds, setEvaluatingIds] = useState<Set<string>>(new Set());
  const [reportIdea, setReportIdea] = useState<StartupIdea | null>(null);

  const fetchData = async () => {
    let query = supabase
      .from("startup_ideas")
      .select("*")
      .order("created_at", { ascending: false });
    if (collegeId) query = query.or(`college_id.eq.${collegeId},college_id.is.null`);
    const { data: ideasData } = await query;
    setIdeas((ideasData as StartupIdea[]) || []);

    if (ideasData && ideasData.length > 0) {
      const creatorIds = ideasData.map(i => i.creator_id);
      const startupIds = ideasData.map(i => i.id);

      const [{ data: profilesData }, { data: jrData }] = await Promise.all([
        supabase.from("profiles").select("*").in("user_id", creatorIds),
        supabase.from("startup_join_requests").select("*").in("startup_id", startupIds),
      ]);

      const pMap = new Map<string, Profile>();
      profilesData?.forEach(p => pMap.set(p.user_id, p));

      const jrUserIds = jrData?.map(jr => jr.user_id) || [];
      if (jrUserIds.length > 0) {
        const { data: jrProfiles } = await supabase.from("profiles").select("*").in("user_id", jrUserIds);
        jrProfiles?.forEach(p => pMap.set(p.user_id, p));
      }

      setProfiles(pMap);
      setJoinRequests(jrData || []);
    }
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const triggerAIEvaluation = async (startupId: string) => {
    setEvaluatingIds(prev => new Set(prev).add(startupId));
    try {
      const { data, error } = await supabase.functions.invoke("evaluate-startup", {
        body: { startup_id: startupId },
      });
      if (error) throw error;
      if (data?.error) {
        toast.error(data.error);
      } else {
        toast.success("AI evaluation complete!");
        fetchData();
      }
    } catch (e: unknown) {
      toast.error(mapErrorMessage(e));
    } finally {
      setEvaluatingIds(prev => {
        const next = new Set(prev);
        next.delete(startupId);
        return next;
      });
    }
  };

  const handleCreateIdea = async () => {
    if (!user || !newTitle.trim()) return;
    setCreating(true);
    try {
      const { data: inserted, error } = await supabase.from("startup_ideas").insert({
        creator_id: user.id,
        title: newTitle.trim(),
        description: newDesc.trim() || null,
        category: newCategory,
        college_id: collegeId,
      }).select("id").single();
      if (error) throw error;
      toast.success("Startup idea posted!");
      setNewTitle("");
      setNewDesc("");
      setShowCreate(false);
      fetchData();

      // Auto-trigger AI evaluation if description is long enough
      if (newDesc.trim().length >= 100 && inserted?.id) {
        setTimeout(() => triggerAIEvaluation(inserted.id), 500);
      }
    } catch (e: unknown) {
      toast.error(mapErrorMessage(e));
    } finally {
      setCreating(false);
    }
  };

  const handleJoinRequest = async (startupId: string) => {
    if (!user) return;
    try {
      const { error } = await supabase.from("startup_join_requests").insert({
        startup_id: startupId,
        user_id: user.id,
        message: "I'd like to join your startup!",
      });
      if (error) throw error;
      toast.success("Join request sent!");
      fetchData();
    } catch (e: unknown) {
      toast.error(mapErrorMessage(e));
    }
  };

  const handleRequestAction = async (requestId: string, status: "accepted" | "rejected") => {
    try {
      const { error } = await supabase.from("startup_join_requests").update({ status }).eq("id", requestId);
      if (error) throw error;
      toast.success(status === "accepted" ? "Member accepted!" : "Request declined");
      fetchData();
    } catch (e: unknown) {
      toast.error(mapErrorMessage(e));
    }
  };

  const canChat = (idea: StartupIdea) => {
    if (idea.creator_id === user?.id) return true;
    return joinRequests.some(jr => jr.startup_id === idea.id && jr.user_id === user?.id && jr.status === "accepted");
  };

  const getCanReEvaluate = (idea: StartupIdea) => {
    if (!idea.ai_evaluated_at) return true;
    const hours = (Date.now() - new Date(idea.ai_evaluated_at).getTime()) / (1000 * 60 * 60);
    return hours >= 24;
  };

  const getHoursUntilReEval = (idea: StartupIdea) => {
    if (!idea.ai_evaluated_at) return null;
    const hours = (Date.now() - new Date(idea.ai_evaluated_at).getTime()) / (1000 * 60 * 60);
    return hours >= 24 ? null : Math.ceil(24 - hours);
  };

  // Sort ideas
  const sortedIdeas = [...ideas]
    .filter(idea => filterCategory === "all" || idea.category === filterCategory)
    .sort((a, b) => {
      if (sortBy === "highest_score") return (b.ai_overall_score ?? -1) - (a.ai_overall_score ?? -1);
      if (sortBy === "most_feasible") return (b.ai_feasibility_score ?? -1) - (a.ai_feasibility_score ?? -1);
      if (sortBy === "most_innovative") {
        const rank = { High: 3, Moderate: 2, Low: 1 };
        return (rank[b.ai_innovation as keyof typeof rank] ?? 0) - (rank[a.ai_innovation as keyof typeof rank] ?? 0);
      }
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    });

  // Chat functions
  const openChat = async (startupId: string) => {
    setActiveChatId(startupId);
    const { data } = await supabase
      .from("startup_messages")
      .select("*")
      .eq("startup_id", startupId)
      .order("created_at", { ascending: true });
    setMessages(data || []);
    const senderIds = [...new Set((data || []).map(m => m.sender_id))];
    if (senderIds.length > 0) {
      const { data: senderProfiles } = await supabase.from("profiles").select("*").in("user_id", senderIds);
      setProfiles(prev => {
        const newMap = new Map(prev);
        senderProfiles?.forEach(p => newMap.set(p.user_id, p));
        return newMap;
      });
    }
    setTimeout(() => chatRef.current?.scrollTo({ top: chatRef.current.scrollHeight }), 100);
  };

  useEffect(() => {
    if (!activeChatId) return;
    const channel = supabase
      .channel(`startup-chat-${activeChatId}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "startup_messages", filter: `startup_id=eq.${activeChatId}` }, (payload) => {
        setMessages(prev => [...prev, payload.new]);
        setTimeout(() => chatRef.current?.scrollTo({ top: chatRef.current.scrollHeight, behavior: "smooth" }), 50);
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [activeChatId]);

  const sendMessage = async () => {
    if (!user || !activeChatId || !msgInput.trim()) return;
    setSendingMsg(true);
    try {
      const { error } = await supabase.from("startup_messages").insert({
        startup_id: activeChatId,
        sender_id: user.id,
        content: msgInput.trim(),
      });
      if (error) throw error;
      setMsgInput("");
    } catch (e: unknown) {
      toast.error(mapErrorMessage(e));
    } finally {
      setSendingMsg(false);
    }
  };

  // Chat modal
  if (activeChatId) {
    const idea = ideas.find(i => i.id === activeChatId);
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col h-[calc(100vh-120px)]">
        <div className="flex items-center gap-2 mb-3">
          <Button variant="ghost" size="sm" onClick={() => setActiveChatId(null)}>
            <ArrowLeft size={16} className="mr-1" /> Back
          </Button>
          <h2 className="font-bold text-foreground truncate">{idea?.title} — Group Chat</h2>
        </div>
        <div ref={chatRef} className="flex-1 overflow-y-auto space-y-3 border border-border rounded-xl p-4 bg-muted/30">
          {messages.length === 0 && <p className="text-center text-muted-foreground text-sm py-8">No messages yet. Start the conversation!</p>}
          {messages.map((msg: any) => {
            const isMe = msg.sender_id === user?.id;
            const senderProfile = profiles.get(msg.sender_id);
            return (
              <div key={msg.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[75%] rounded-2xl px-4 py-2 ${isMe ? "bg-primary text-primary-foreground" : "bg-card border border-border"}`}>
                  {!isMe && <p className="text-xs font-semibold mb-1 text-muted-foreground">{senderProfile?.full_name || "Unknown"}</p>}
                  <p className="text-sm">{msg.content}</p>
                </div>
              </div>
            );
          })}
        </div>
        <div className="flex gap-2 mt-3">
          <Input value={msgInput} onChange={(e) => setMsgInput(e.target.value)} placeholder="Type a message..." maxLength={500} onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage()} />
          <Button onClick={sendMessage} disabled={sendingMsg || !msgInput.trim()} size="icon"><Send size={16} /></Button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      {/* Sticky Back Button */}
      <div className="sticky top-0 z-20 bg-background/80 backdrop-blur-sm py-2 -mx-1 px-1 mb-2">
        <Button variant="ghost" size="sm" onClick={() => navigate(-1)} className="gap-1.5">
          <ArrowLeft size={16} /> Back
        </Button>
      </div>

      {/* Startup Banner */}
      <div className="relative rounded-2xl overflow-hidden mb-4 py-8 px-6 bg-gradient-to-r from-orange-500/80 to-red-600/80">
        <div className="relative z-10">
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight drop-shadow-lg flex items-center gap-3">
            <Rocket size={32} /> Startup Hub
          </h1>
          <p className="text-white/80 text-sm mt-1 max-w-xl">Propose your startup idea or join an exciting venture</p>
          <span className="mt-2 inline-block text-[10px] uppercase tracking-widest font-bold text-white/60 bg-white/10 rounded-full px-3 py-1 w-fit">Entrepreneurship</span>
        </div>
      </div>

      <AnnouncementCarousel target="section:startups" />

      {/* Filter + Sort + Post CTA */}
      <div className="flex flex-wrap items-center gap-3 mb-6">
        <Button onClick={() => setShowCreate(true)} className="w-full sm:w-auto">
          <Plus size={16} className="mr-2" /> Post Your Startup Idea
        </Button>
        <div className="flex items-center gap-2">
          <Filter size={14} className="text-muted-foreground" />
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="w-[160px] h-9"><SelectValue placeholder="All Categories" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {STARTUP_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-2">
          <ArrowUpDown size={14} className="text-muted-foreground" />
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[160px] h-9"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest First</SelectItem>
              <SelectItem value="highest_score">Highest AI Score</SelectItem>
              <SelectItem value="most_feasible">Most Feasible</SelectItem>
              <SelectItem value="most_innovative">Most Innovative</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Create Idea Modal */}
      {showCreate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-lg text-foreground">Post Startup Idea</h3>
              <button onClick={() => setShowCreate(false)} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
            </div>
            <div className="space-y-2">
              <Label>Startup Name / Title *</Label>
              <Input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} placeholder="e.g. FoodDash — campus food delivery" maxLength={150} />
            </div>
            <div className="space-y-2">
              <Label>Category *</Label>
              <Select value={newCategory} onValueChange={setNewCategory}>
                <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                <SelectContent>
                  {STARTUP_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea value={newDesc} onChange={(e) => setNewDesc(e.target.value)} placeholder="Describe your idea, the problem it solves, tech stack, what kind of co-founders you're looking for..." rows={4} maxLength={1000} />
              <p className="text-[10px] text-muted-foreground">
                {newDesc.length}/1000 {newDesc.length < 100 ? `(min 100 chars for AI evaluation — ${100 - newDesc.length} more)` : "✅ AI will evaluate this"}
              </p>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleCreateIdea} disabled={creating || !newTitle.trim()} className="flex-1">
                {creating ? "Posting..." : "Post Idea"}
              </Button>
              <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Ideas list */}
      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map(i => <div key={i} className="h-32 bg-muted rounded-lg animate-pulse" />)}
        </div>
      ) : ideas.length === 0 ? (
        <p className="text-center py-12 text-muted-foreground">No startup ideas yet. Be the first to post one!</p>
      ) : (
        <div className="space-y-4">
          {sortedIdeas.map((idea, i) => {
            const creator = profiles.get(idea.creator_id);
            const isCreator = idea.creator_id === user?.id;
            const myRequest = joinRequests.find(jr => jr.startup_id === idea.id && jr.user_id === user?.id);
            const ideaRequests = joinRequests.filter(jr => jr.startup_id === idea.id);
            const acceptedCount = ideaRequests.filter(jr => jr.status === "accepted").length;
            const isEvaluating = evaluatingIds.has(idea.id);

            return (
              <motion.div key={idea.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                <Card className="border-border/60 hover:shadow-lg transition-all">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <h3 className="text-lg font-bold text-foreground">{idea.title}</h3>
                          {idea.category && <Badge variant="secondary" className="text-[10px]">{idea.category}</Badge>}
                          {isCreator && <Badge variant="outline" className="text-xs">Your Idea</Badge>}
                        </div>
                        {creator && (
                          <p className="text-xs text-muted-foreground mb-2">
                            By {creator.full_name} • {creator.branch}
                          </p>
                        )}
                        {idea.description && (
                          <p className="text-sm text-muted-foreground line-clamp-3">{idea.description}</p>
                        )}

                        {/* AI Score + Actions */}
                        <div className="flex items-center gap-3 mt-3 flex-wrap">
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Users size={12} /> {acceptedCount + 1} member{acceptedCount > 0 ? "s" : ""}
                          </span>

                          <AIScoreBadge score={idea.ai_overall_score} evaluating={isEvaluating} />

                          {idea.ai_overall_score !== null && (
                            <Button variant="ghost" size="sm" className="text-xs h-7 gap-1" onClick={() => setReportIdea(idea)}>
                              <Brain size={14} /> View AI Report
                            </Button>
                          )}

                          {isCreator && !idea.ai_evaluated_at && !isEvaluating && idea.description && idea.description.length >= 100 && (
                            <Button variant="ghost" size="sm" className="text-xs h-7 gap-1" onClick={() => triggerAIEvaluation(idea.id)}>
                              <Brain size={14} /> Get AI Evaluation
                            </Button>
                          )}

                          {canChat(idea) && (
                            <Button variant="ghost" size="sm" className="text-xs h-7" onClick={() => openChat(idea.id)}>
                              <MessageCircle size={14} className="mr-1" /> Group Chat
                            </Button>
                          )}
                        </div>
                      </div>

                      <div className="shrink-0">
                        {!isCreator && !myRequest && (
                          <Button size="sm" variant="outline" onClick={() => handleJoinRequest(idea.id)}>Request to Join</Button>
                        )}
                        {myRequest && (
                          <Badge variant={myRequest.status === "accepted" ? "default" : myRequest.status === "rejected" ? "destructive" : "outline"}>
                            {myRequest.status === "pending" && "⏳ Pending"}
                            {myRequest.status === "accepted" && "✅ Joined"}
                            {myRequest.status === "rejected" && "❌ Declined"}
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Join requests for creator */}
                    {isCreator && ideaRequests.length > 0 && (
                      <div className="mt-4 pt-3 border-t border-border">
                        <p className="text-sm font-semibold text-foreground mb-2">Join Requests</p>
                        <div className="space-y-2">
                          {ideaRequests.map(jr => {
                            const reqProfile = profiles.get(jr.user_id);
                            return (
                              <div key={jr.id} className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  {reqProfile && (
                                    <ProfilePhoto fullName={reqProfile.full_name} gender={reqProfile.gender} photoUrl={reqProfile.photo_url} showPhoto={reqProfile.show_photo} size="sm" />
                                  )}
                                  <div>
                                    <p className="text-sm font-medium">{reqProfile?.full_name || "Unknown"}</p>
                                    <p className="text-xs text-muted-foreground">{reqProfile?.branch}</p>
                                  </div>
                                </div>
                                {jr.status === "pending" ? (
                                  <div className="flex gap-1">
                                    <Button size="sm" onClick={() => handleRequestAction(jr.id, "accepted")}><Check size={14} /></Button>
                                    <Button size="sm" variant="outline" onClick={() => handleRequestAction(jr.id, "rejected")}><X size={14} /></Button>
                                  </div>
                                ) : (
                                  <Badge variant={jr.status === "accepted" ? "default" : "destructive"} className="text-xs">{jr.status}</Badge>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* AI Report Modal */}
      {reportIdea && (
        <AIReportModal
          idea={reportIdea}
          onClose={() => setReportIdea(null)}
          onReEvaluate={() => {
            triggerAIEvaluation(reportIdea.id);
            setReportIdea(null);
          }}
          reEvaluating={evaluatingIds.has(reportIdea.id)}
          canReEvaluate={getCanReEvaluate(reportIdea)}
          hoursUntilReEval={getHoursUntilReEval(reportIdea)}
        />
      )}
    </motion.div>
  );
}
