import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { mapErrorMessage } from "@/lib/errorMessages";
import type { Tables } from "@/integrations/supabase/types";
import { Plus, Edit2, XCircle, Trash2, ArrowLeft, Download, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";

type Hackathon = Tables<"hackathons">;

export default function AdminHackathons() {
  const { user, isAdmin, activeCollegeId: collegeId } = useAuth();
  const [hackathons, setHackathons] = useState<Hackathon[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Hackathon | null>(null);

  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [organizer, setOrganizer] = useState("");
  const [mode, setMode] = useState("Online");
  const [deadline, setDeadline] = useState("");
  const [description, setDescription] = useState("");
  const [linkUrl, setLinkUrl] = useState("");
  const [saving, setSaving] = useState(false);
  const [fetching, setFetching] = useState(false);

  const fetchHackathons = async () => {
    let query = supabase
      .from("hackathons")
      .select("*")
      .order("created_at", { ascending: false });
    if (collegeId) query = query.eq("college_id", collegeId);
    const { data } = await query;
    setHackathons(data || []);
    setLoading(false);
  };

  useEffect(() => {
    fetchHackathons();
  }, []);

  const resetForm = () => {
    setName("");
    setOrganizer("");
    setMode("Online");
    setDeadline("");
    setDescription("");
    setLinkUrl("");
    setEditing(null);
    setShowForm(false);
  };

  const startEdit = (h: Hackathon) => {
    setName(h.name);
    setOrganizer(h.organizer);
    setMode(h.mode);
    setDeadline(h.registration_deadline.split("T")[0]);
    setDescription(h.description || "");
    setLinkUrl((h as any).link_url || "");
    setEditing(h);
    setShowForm(true);
  };

  const handleFetchDetails = async () => {
    if (!linkUrl.trim()) { toast.error("Paste a hackathon link first"); return; }
    setFetching(true);
    try {
      const { data, error } = await supabase.functions.invoke("fetch-conference-details", {
        body: { url: linkUrl.trim() },
      });
      if (error) throw error;
      if (data?.title) setName(data.title);
      if (data?.description) setDescription(data.description);
      if (data?.organizer) setOrganizer(data.organizer);
      if (data?.mode) setMode(data.mode);
      if (data?.deadline) setDeadline(data.deadline);
      toast.success("Details fetched! Review and save.");
    } catch {
      toast.error("Unable to fetch details. Please fill manually.");
    } finally {
      setFetching(false);
    }
  };

  const handleSave = async () => {
    if (!user || !name.trim() || !organizer.trim() || !deadline) {
      toast.error("Please fill in all required fields");
      return;
    }

    setSaving(true);
    try {
      if (editing) {
        const { error } = await supabase
          .from("hackathons")
          .update({
            name: name.trim(),
            organizer: organizer.trim(),
            mode,
            registration_deadline: new Date(deadline).toISOString(),
            description: description.trim(),
            link_url: linkUrl.trim() || null,
          } as any)
          .eq("id", editing.id);
        if (error) throw error;
        toast.success("Hackathon updated!");
      } else {
        const { error } = await supabase.from("hackathons").insert({
          name: name.trim(),
          organizer: organizer.trim(),
          mode,
          registration_deadline: new Date(deadline).toISOString(),
          description: description.trim(),
          link_url: linkUrl.trim() || null,
          created_by: user.id,
          college_id: collegeId,
        } as any);
        if (error) throw error;
        toast.success("Hackathon created!");
      }
      resetForm();
      fetchHackathons();
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  const toggleStatus = async (h: Hackathon) => {
    const newStatus = h.status === "open" ? "closed" : "open";
    try {
      const { error } = await supabase
        .from("hackathons")
        .update({ status: newStatus })
        .eq("id", h.id);
      if (error) throw error;
      toast.success(`Hackathon ${newStatus === "open" ? "reopened" : "closed"}`);
      fetchHackathons();
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    }
  };

  const deleteHackathon = async (h: Hackathon) => {
    if (!confirm(`Delete "${h.name}"? This will also delete all teams and join requests.`)) return;
    try {
      const { error } = await supabase
        .from("hackathons")
        .delete()
        .eq("id", h.id);
      if (error) throw error;
      toast.success("Hackathon deleted");
      fetchHackathons();
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    }
  };

  if (!isAdmin) {
    return (
      <div className="text-center py-20 text-muted-foreground">
        <p className="font-medium">Access Denied</p>
        <p className="text-sm">You need admin privileges to access this page.</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/admin/dashboard")} className="p-2 rounded-full hover:bg-muted transition-colors">
            <ArrowLeft size={20} className="text-foreground" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Manage Hackathons</h1>
            <p className="text-muted-foreground text-sm">Admin panel</p>
          </div>
        </div>
        <Button onClick={() => { resetForm(); setShowForm(true); }}>
          <Plus size={16} className="mr-1" /> New Hackathon
        </Button>
      </div>

      {showForm && (
        <Card className="border-border/60 mb-6">
          <CardHeader>
            <CardTitle className="text-lg">
              {editing ? "Edit Hackathon" : "Create Hackathon"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Link + fetch */}
            <div className="space-y-2">
              <Label>Hackathon Link (URL)</Label>
              <div className="flex gap-2">
                <Input value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} placeholder="https://..." className="flex-1" />
                <Button variant="outline" onClick={handleFetchDetails} disabled={fetching}>
                  {fetching ? <Loader2 size={16} className="animate-spin mr-1" /> : <Download size={16} className="mr-1" />}
                  Fetch details
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Hackathon Name *</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Hackathon name" maxLength={200} />
              </div>
              <div className="space-y-2">
                <Label>Organizer *</Label>
                <Input value={organizer} onChange={(e) => setOrganizer(e.target.value)} placeholder="Organizing body" maxLength={200} />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Mode *</Label>
                <Select value={mode} onValueChange={setMode}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Online">Online</SelectItem>
                    <SelectItem value="Offline">Offline</SelectItem>
                    <SelectItem value="Hybrid">Hybrid</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Registration Deadline *</Label>
                <Input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Hackathon description..." maxLength={1000} rows={3} />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={saving}>
                {saving ? "Saving..." : editing ? "Update" : "Create"}
              </Button>
              <Button variant="outline" onClick={resetForm}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {loading ? (
        <div className="space-y-3">
          {[1, 2].map((i) => (
            <div key={i} className="h-20 bg-muted rounded-lg animate-pulse" />
          ))}
        </div>
      ) : hackathons.length === 0 ? (
        <p className="text-center py-8 text-muted-foreground">
          No hackathons created yet
        </p>
      ) : (
        <div className="space-y-3">
          {hackathons.map((h) => (
            <Card key={h.id} className="border-border/60">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-foreground">{h.name}</h3>
                      <Badge
                        variant={h.status === "open" ? "default" : "outline"}
                        className="text-xs"
                      >
                        {h.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {h.organizer} · {h.mode} · Deadline:{" "}
                      {format(new Date(h.registration_deadline), "MMM d, yyyy")}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => startEdit(h)}
                    >
                      <Edit2 size={14} />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => toggleStatus(h)}
                    >
                      <XCircle size={14} />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-destructive hover:text-destructive"
                      onClick={() => deleteHackathon(h)}
                    >
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </motion.div>
  );
}
