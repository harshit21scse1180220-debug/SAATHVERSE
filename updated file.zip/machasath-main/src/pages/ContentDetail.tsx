import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { ArrowLeft, User, Crown, Shield } from "lucide-react";
import { motion } from "framer-motion";
import type { Tables } from "@/integrations/supabase/types";

type CardDetail = {
  id: string;
  title: string;
  subtitle: string | null;
  image_url: string | null;
  link_url: string | null;
  about_text: string | null;
  banner_image_url: string | null;
  leader_id: string | null;
  co_leader_id: string | null;
  row: { title: string; section: { title: string; section_type: string; cover_image_url: string | null } } | null;
};

type LeaderProfile = {
  id: string;
  full_name: string;
  photo_url: string | null;
  branch: string;
  year_of_study: number;
};

export default function ContentDetail() {
  const { cardId } = useParams<{ cardId: string }>();
  const navigate = useNavigate();
  const [card, setCard] = useState<CardDetail | null>(null);
  const [leader, setLeader] = useState<LeaderProfile | null>(null);
  const [coLeader, setCoLeader] = useState<LeaderProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!cardId) return;
    const load = async () => {
      const { data: cardData } = await supabase
        .from("content_cards")
        .select("*")
        .eq("id", cardId)
        .maybeSingle();

      if (!cardData) { setLoading(false); return; }

      const { data: rowData } = await supabase
        .from("content_rows")
        .select("title, section_id")
        .eq("id", cardData.row_id)
        .maybeSingle();

      let sectionData = null;
      if (rowData) {
        const { data } = await supabase
          .from("content_sections")
          .select("title, section_type, cover_image_url")
          .eq("id", rowData.section_id)
          .maybeSingle();
        sectionData = data;
      }

      // Fetch leader profiles
      const profileIds = [cardData.leader_id, cardData.co_leader_id].filter(Boolean) as string[];
      if (profileIds.length > 0) {
        const { data: profiles } = await supabase.from("profiles").select("id, full_name, photo_url, branch, year_of_study").in("id", profileIds);
        if (profiles) {
          setLeader(profiles.find(p => p.id === cardData.leader_id) || null);
          setCoLeader(profiles.find(p => p.id === cardData.co_leader_id) || null);
        }
      }

      setCard({
        ...cardData,
        row: rowData ? { title: rowData.title, section: sectionData || { title: "", section_type: "", cover_image_url: null } } : null,
      } as CardDetail);
      setLoading(false);
    };
    load();
  }, [cardId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!card) {
    return (
      <div className="text-center py-20 text-muted-foreground">
        <p className="font-medium">Content not found</p>
        <Button variant="ghost" onClick={() => navigate(-1)} className="mt-4"><ArrowLeft size={16} className="mr-2" /> Go Back</Button>
      </div>
    );
  }

  const bannerUrl = card.banner_image_url || card.image_url || card.row?.section?.cover_image_url;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }} className="max-w-3xl mx-auto">
      <Button variant="ghost" onClick={() => navigate(-1)} className="mb-4">
        <ArrowLeft size={16} className="mr-2" /> Back
      </Button>

      {/* Banner */}
      <div className="rounded-2xl overflow-hidden mb-6 bg-muted/30">
        {bannerUrl ? (
          <img src={bannerUrl} alt={card.title} className="w-full aspect-[16/6] object-cover" />
        ) : (
          <div className="w-full aspect-[16/6] flex items-center justify-center">
            <p className="text-muted-foreground text-sm">No banner image</p>
          </div>
        )}
      </div>

      {/* Title & Subtitle */}
      <div className="mb-6">
        {card.row && (
          <div className="flex items-center gap-2 mb-2 text-xs text-muted-foreground">
            <span className="font-medium">{card.row.section.title}</span>
            <span>›</span>
            <span>{card.row.title}</span>
          </div>
        )}
        <h1 className="text-3xl font-extrabold text-foreground tracking-tight">{card.title}</h1>
        {card.subtitle && <p className="text-lg text-muted-foreground mt-1">{card.subtitle}</p>}
      </div>

      {/* About Section */}
      <div className="mb-8 bg-card rounded-xl border border-border/60 p-5">
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">About</h2>
        <p className="text-foreground leading-relaxed">
          {card.about_text || "No description added yet."}
        </p>
      </div>

      {/* Leadership Section */}
      <div className="mb-8">
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">Leadership</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <LeaderCard profile={leader} role="Leader" navigate={navigate} />
          <LeaderCard profile={coLeader} role="Co-Leader" navigate={navigate} />
        </div>
      </div>

      {/* External Link */}
      {card.link_url && card.link_url.startsWith("http") && (
        <a href={card.link_url} target="_blank" rel="noreferrer" className="inline-block text-primary hover:underline text-sm font-medium">
          Visit Link →
        </a>
      )}
    </motion.div>
  );
}

function LeaderCard({ profile, role, navigate }: { profile: LeaderProfile | null; role: string; navigate: (path: string) => void }) {
  const icon = role === "Leader" ? <Crown size={14} className="text-amber-500" /> : <Shield size={14} className="text-blue-500" />;

  if (!profile) {
    return (
      <div className="bg-card rounded-xl border border-dashed border-border/60 p-5 flex flex-col items-center justify-center text-center min-h-[140px]">
        <User size={28} className="text-muted-foreground/30 mb-2" />
        <p className="text-xs text-muted-foreground">{role} not assigned</p>
      </div>
    );
  }

  return (
    <div
      className="bg-card rounded-xl border border-border/60 p-5 flex items-center gap-4 cursor-pointer hover:bg-muted/30 transition-colors"
      onClick={() => navigate(`/profile/${profile.id}`)}
    >
      <div className="w-14 h-14 rounded-full bg-muted/50 overflow-hidden shrink-0">
        {profile.photo_url ? (
          <img src={profile.photo_url} alt={profile.full_name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center"><User size={24} className="text-muted-foreground/40" /></div>
        )}
      </div>
      <div className="min-w-0">
        <div className="flex items-center gap-1.5 mb-0.5">
          {icon}
          <span className="text-[10px] font-semibold text-muted-foreground uppercase">{role}</span>
        </div>
        <p className="text-sm font-semibold text-foreground truncate">{profile.full_name}</p>
        <p className="text-xs text-muted-foreground">{profile.branch} · Year {profile.year_of_study}</p>
      </div>
    </div>
  );
}
