import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import ProfilePhoto from "@/components/ProfilePhoto";
import type { Tables } from "@/integrations/supabase/types";
import { ArrowLeft, Search, Users, UserPlus, LogOut, Trash2 } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { mapErrorMessage } from "@/lib/errorMessages";

type Team = Tables<"hackathon_teams">;
type Hackathon = Tables<"hackathons">;
type Profile = Tables<"profiles">;
type JoinRequest = Tables<"team_join_requests">;

interface TeamWithDetails extends Team {
  hackathon?: Hackathon;
  creatorProfile?: Profile;
  memberCount: number;
  myRequest?: JoinRequest;
}

// Demo teams for empty state
const demoTeams: TeamWithDetails[] = [
  {
    id: "demo-1", hackathon_id: "demo-h1", creator_id: "demo-u1", name: "Code Crushers",
    roles_needed: "Frontend dev, UI/UX designer", team_size: 4, description: "Building a campus utility app", created_at: new Date().toISOString(),
    hackathon: { id: "demo-h1", name: "CodeStorm 2026", organizer: "Tech Club", mode: "Offline", status: "open", registration_deadline: new Date(Date.now() + 15 * 86400000).toISOString(), created_by: "", created_at: "", updated_at: "", description: "" } as Hackathon,
    creatorProfile: { full_name: "Rahul Sharma", branch: "Engineering & Technology", gender: "Male" } as Profile,
    memberCount: 2, myRequest: undefined,
  },
  {
    id: "demo-2", hackathon_id: "demo-h2", creator_id: "demo-u2", name: "Neural Ninjas",
    roles_needed: "ML engineer, Backend dev", team_size: 3, description: "AI-powered study assistant", created_at: new Date().toISOString(),
    hackathon: { id: "demo-h2", name: "HackTheVerse", organizer: "Google DSC", mode: "Hybrid", status: "open", registration_deadline: new Date(Date.now() + 30 * 86400000).toISOString(), created_by: "", created_at: "", updated_at: "", description: "" } as Hackathon,
    creatorProfile: { full_name: "Priya Patel", branch: "Science", gender: "Female" } as Profile,
    memberCount: 1, myRequest: undefined,
  },
];

export default function FindTeam() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [teams, setTeams] = useState<TeamWithDetails[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  const fetchTeams = async () => {
    setLoading(true);
    // Fetch all teams
    const { data: teamsData } = await supabase
      .from("hackathon_teams")
      .select("*")
      .order("created_at", { ascending: false });

    if (!teamsData || teamsData.length === 0) {
      setTeams([]);
      setLoading(false);
      return;
    }

    const hackathonIds = [...new Set(teamsData.map(t => t.hackathon_id))];
    const creatorIds = [...new Set(teamsData.map(t => t.creator_id))];
    const teamIds = teamsData.map(t => t.id);

    const [{ data: hackathons }, { data: profiles }, { data: joinRequests }] = await Promise.all([
      supabase.from("hackathons").select("*").in("id", hackathonIds),
      supabase.from("profiles").select("*").in("user_id", creatorIds),
      supabase.from("team_join_requests").select("*").in("team_id", teamIds),
    ]);

    const hackathonMap = new Map((hackathons || []).map(h => [h.id, h]));
    const profileMap = new Map((profiles || []).map(p => [p.user_id, p]));

    const enriched: TeamWithDetails[] = teamsData.map(team => {
      const teamRequests = (joinRequests || []).filter(jr => jr.team_id === team.id);
      const acceptedCount = teamRequests.filter(jr => jr.status === "accepted").length;
      const myReq = teamRequests.find(jr => jr.user_id === user?.id);

      return {
        ...team,
        hackathon: hackathonMap.get(team.hackathon_id),
        creatorProfile: profileMap.get(team.creator_id),
        memberCount: 1 + acceptedCount, // creator + accepted members
        myRequest: myReq,
      };
    });

    setTeams(enriched);
    setLoading(false);
  };

  useEffect(() => { fetchTeams(); }, []);

  const requestToJoin = async (teamId: string) => {
    if (!user) return;
    try {
      const { error } = await supabase.from("team_join_requests").insert({ team_id: teamId, user_id: user.id });
      if (error) throw error;
      toast.success("Join request sent!");
      fetchTeams();
    } catch (e: unknown) { toast.error(mapErrorMessage(e)); }
  };

  const leaveTeam = async (requestId: string) => {
    // We can't delete join requests per RLS, so we'll update status
    // Actually RLS doesn't allow update by user either. Let's check...
    // team_join_requests: Users can request (INSERT), creators can update, both can view
    // Users can't leave directly. Let's show a message.
    toast.error("Contact the team creator to be removed from the team.");
  };

  const deleteTeam = async (teamId: string) => {
    if (!confirm("Delete this team? This cannot be undone.")) return;
    try {
      const { error } = await supabase.from("hackathon_teams").delete().eq("id", teamId);
      if (error) throw error;
      toast.success("Team deleted!");
      fetchTeams();
    } catch (e: unknown) { toast.error(mapErrorMessage(e)); }
  };

  const allTeams = [...teams, ...(teams.length === 0 ? demoTeams : [])];

  const filtered = allTeams.filter(t => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      t.name.toLowerCase().includes(q) ||
      (t.hackathon?.name || "").toLowerCase().includes(q) ||
      (t.roles_needed || "").toLowerCase().includes(q) ||
      (t.creatorProfile?.full_name || "").toLowerCase().includes(q)
    );
  });

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <Button variant="ghost" onClick={() => navigate("/hackathons")} className="mb-4">
        <ArrowLeft size={16} className="mr-2" /> Back to Hackathons
      </Button>

      <div className="flex items-center gap-3 mb-1">
        <Users size={28} className="text-primary" />
        <h1 className="text-2xl font-bold text-foreground">Find a Team</h1>
      </div>
      <p className="text-muted-foreground text-sm mb-6">Browse open teams looking for members</p>

      {/* Search */}
      <div className="relative mb-6">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search teams, hackathons, roles..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map(i => <div key={i} className="h-32 bg-muted rounded-lg animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <p className="text-center py-12 text-muted-foreground">No teams found</p>
      ) : (
        <div className="space-y-4">
          {filtered.map((team, i) => {
            const isCreator = team.creator_id === user?.id;
            const isDemo = team.id.startsWith("demo-");
            const isMember = team.myRequest?.status === "accepted";
            const isPending = team.myRequest?.status === "pending";
            const isFull = (team.team_size || 4) <= team.memberCount;

            return (
              <motion.div key={team.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                <Card className="border-border/60 hover:shadow-lg transition-all">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <h3 className="text-lg font-bold text-foreground">{team.name}</h3>
                          {isCreator && <Badge variant="outline" className="text-xs">Your Team</Badge>}
                          {isMember && !isCreator && <Badge className="text-xs">Joined</Badge>}
                          {isPending && <Badge variant="secondary" className="text-xs">⏳ Pending</Badge>}
                          {isFull && <Badge variant="destructive" className="text-xs">Full</Badge>}
                          {isDemo && <Badge variant="secondary" className="text-xs">Demo</Badge>}
                        </div>

                        {team.hackathon && (
                          <p className="text-sm text-primary font-medium">{team.hackathon.name}</p>
                        )}

                        {team.creatorProfile && (
                          <p className="text-xs text-muted-foreground mt-1">
                            Created by {team.creatorProfile.full_name} · {team.creatorProfile.branch}
                          </p>
                        )}

                        {team.description && (
                          <p className="text-sm text-muted-foreground mt-2">{team.description}</p>
                        )}

                        {team.roles_needed && (
                          <p className="text-sm mt-2">
                            <span className="font-medium text-foreground">Looking for:</span>{" "}
                            <span className="text-muted-foreground">{team.roles_needed}</span>
                          </p>
                        )}

                        <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Users size={12} /> {team.memberCount}/{team.team_size || 4} members
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-col gap-2 shrink-0">
                        {!isDemo && !isCreator && !isMember && !isPending && !isFull && (
                          <Button size="sm" onClick={() => requestToJoin(team.id)}>
                            <UserPlus size={14} className="mr-1" /> Join
                          </Button>
                        )}
                        {isCreator && (
                          <Button size="sm" variant="destructive" onClick={() => deleteTeam(team.id)}>
                            <Trash2 size={14} className="mr-1" /> Delete
                          </Button>
                        )}
                        {isMember && !isCreator && (
                          <Button size="sm" variant="outline" onClick={() => leaveTeam(team.myRequest!.id)}>
                            <LogOut size={14} className="mr-1" /> Leave
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}
    </motion.div>
  );
}
