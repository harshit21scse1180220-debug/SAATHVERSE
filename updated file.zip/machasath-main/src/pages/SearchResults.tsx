import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Search as SearchIcon, ArrowLeft, Settings2, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import StudentCard from "@/components/StudentCard";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useFormOptions } from "@/hooks/useFormOptions";
import type { Tables } from "@/integrations/supabase/types";
import { motion } from "framer-motion";

type Profile = Tables<"profiles">;

export default function SearchResults() {
  const navigate = useNavigate();
  const { user, collegeId } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const query = searchParams.get("q") || "";
  const [localQuery, setLocalQuery] = useState(query);
  const [results, setResults] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);

  const { options: branchOptions } = useFormOptions("branch");

  // Filters
  const [filterBranch, setFilterBranch] = useState("all");
  const [filterYear, setFilterYear] = useState("all");
  const [filterGender, setFilterGender] = useState("all");
  const [showFilters, setShowFilters] = useState(false);

  const handleSearch = () => {
    if (localQuery.trim()) {
      setSearchParams({ q: localQuery.trim() });
    }
  };

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      setLoading(false);
      return;
    }
    const fetchResults = async () => {
      setLoading(true);
      const q = query.trim().toLowerCase();
      let dbQuery = supabase
        .from("profiles")
        .select("*")
        .neq("user_id", user?.id ?? "")
        .order("created_at", { ascending: false });
      if (collegeId) dbQuery = dbQuery.eq("college_id", collegeId);
      const { data } = await dbQuery;

      if (data) {
        let filtered = data.filter(
          (p) =>
            p.full_name?.toLowerCase().includes(q) ||
            p.branch?.toLowerCase().includes(q) ||
            p.skills?.some((s) => s.toLowerCase().includes(q))
        );

        // Apply filters
        if (filterBranch !== "all") {
          filtered = filtered.filter(p => p.branch === filterBranch);
        }
        if (filterYear !== "all") {
          filtered = filtered.filter(p => p.year_of_study === parseInt(filterYear));
        }
        if (filterGender !== "all") {
          filtered = filtered.filter(p => p.gender === filterGender);
        }

        setResults(filtered);
      }
      setLoading(false);
    };
    fetchResults();
  }, [query, user?.id, filterBranch, filterYear, filterGender]);

  useEffect(() => {
    setLocalQuery(query);
  }, [query]);

  const activeFilterCount = [filterBranch, filterYear, filterGender].filter(f => f !== "all").length;
  const clearFilters = () => { setFilterBranch("all"); setFilterYear("all"); setFilterGender("all"); };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <div className="flex items-center gap-3 mb-4">
        <button
          onClick={() => navigate("/search")}
          className="p-2 rounded-full hover:bg-muted transition-colors"
        >
          <ArrowLeft size={20} className="text-foreground" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Search Results</h1>
          <p className="text-muted-foreground text-sm">
            {loading ? "Searching..." : `${results.length} result${results.length !== 1 ? "s" : ""} for "${query}"`}
          </p>
        </div>
      </div>

      {/* Search bar */}
      <div className="flex items-center gap-2 mb-3">
        <div className="relative flex-1">
          <SearchIcon size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search by name, skill, or branch..."
            value={localQuery}
            onChange={(e) => setLocalQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            className="pl-9"
          />
        </div>
        <Button size="sm" onClick={handleSearch} className="shrink-0">Search</Button>
        <Button
          variant={showFilters ? "default" : "outline"}
          size="sm"
          onClick={() => setShowFilters(!showFilters)}
          className="gap-1.5 shrink-0"
        >
          <Settings2 size={14} />
          Filters
          {activeFilterCount > 0 && (
            <Badge variant="secondary" className="ml-1 h-5 w-5 p-0 flex items-center justify-center text-[10px]">
              {activeFilterCount}
            </Badge>
          )}
        </Button>
      </div>

      {/* Filter Panel */}
      {showFilters && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          className="bg-card border border-border/60 rounded-xl p-4 mb-4 space-y-3"
        >
          <div className="flex items-center justify-between">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Filter Results</p>
            {activeFilterCount > 0 && (
              <Button variant="ghost" size="sm" className="h-6 text-xs text-muted-foreground" onClick={clearFilters}>
                Clear all
              </Button>
            )}
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="space-y-1">
              <Label className="text-xs">Branch</Label>
              <Select value={filterBranch} onValueChange={setFilterBranch}>
                <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Branches</SelectItem>
                  {branchOptions.map(b => (
                    <SelectItem key={b} value={b}>{b}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Year</Label>
              <Select value={filterYear} onValueChange={setFilterYear}>
                <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Years</SelectItem>
                  <SelectItem value="1">Year 1</SelectItem>
                  <SelectItem value="2">Year 2</SelectItem>
                  <SelectItem value="3">Year 3</SelectItem>
                  <SelectItem value="4">Year 4</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Gender</Label>
              <Select value={filterGender} onValueChange={setFilterGender}>
                <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Female">Female</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </motion.div>
      )}

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-36 bg-muted/50 rounded-xl animate-pulse" />
          ))}
        </div>
      ) : results.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <SearchIcon size={48} className="mx-auto mb-4 opacity-20" />
          <p className="font-medium text-lg">No students found</p>
          <p className="text-sm mt-1">Try a different search term or adjust filters</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {results.map((profile, i) => (
            <motion.div
              key={profile.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
            >
              <StudentCard profile={profile} />
            </motion.div>
          ))}
        </div>
      )}
    </motion.div>
  );
}
