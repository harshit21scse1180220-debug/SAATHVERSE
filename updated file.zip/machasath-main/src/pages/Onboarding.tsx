import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent } from "@/components/ui/card";
import SkillsInput from "@/components/SkillsInput";
import { toast } from "sonner";
import { mapErrorMessage } from "@/lib/errorMessages";
import { logEvent } from "@/lib/eventLog";
import { motion } from "framer-motion";
import { GraduationCap, Sparkles, ArrowLeft, Pencil, Camera, X, AlertCircle } from "lucide-react";
import ImageCropper from "@/components/ImageCropper";
import { COLLEGES_BY_REGION, type Region } from "@/lib/collegeData";
import { useFormOptions, useMainBranches, useSubBranches } from "@/hooks/useFormOptions";
import { useMaxUploadSizeKB } from "@/hooks/useSiteSettings";

/** PhotoUpload with integrated cropper */
function PhotoUploadWithCrop({
  onFileSelect,
  maxSizeKB = 1024,
}: {
  onFileSelect: (file: File | null) => void;
  maxSizeKB?: number;
}) {
  const [preview, setPreview] = useState<string | null>(null);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    if (!file.type.startsWith("image/")) {
      setError("Please select an image file");
      return;
    }
    if (file.size > maxSizeKB * 1024) {
      setError(`File must be under ${maxSizeKB}KB`);
      return;
    }
    setPendingFile(file);
    if (inputRef.current) inputRef.current.value = "";
  };

  const handleCropped = (croppedFile: File) => {
    const url = URL.createObjectURL(croppedFile);
    setPreview(url);
    onFileSelect(croppedFile);
    setPendingFile(null);
  };

  const handleRemove = () => {
    setPreview(null);
    setError(null);
    onFileSelect(null);
  };

  return (
    <div className="space-y-2">
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        onChange={handleFile}
        className="hidden"
      />
      {preview ? (
        <div className="relative w-20 h-20 mx-auto">
          <img src={preview} alt="Preview" className="w-20 h-20 rounded-full object-cover ring-2 ring-border/30" />
          <button
            type="button"
            onClick={handleRemove}
            className="absolute -top-1 -right-1 w-6 h-6 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center shadow-md"
          >
            <X size={12} />
          </button>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="w-20 h-20 mx-auto rounded-full border-2 border-dashed border-border flex flex-col items-center justify-center gap-1 cursor-pointer hover:border-primary/50 hover:bg-muted/50 transition-colors"
        >
          <Camera size={20} className="text-muted-foreground" />
          <span className="text-[10px] text-muted-foreground">Photo</span>
        </button>
      )}
      {error && (
        <p className="text-xs text-destructive flex items-center justify-center gap-1">
          <AlertCircle size={12} /> {error}
        </p>
      )}
      <p className="text-[10px] text-muted-foreground text-center">JPG, PNG or WebP · Max {maxSizeKB}KB</p>
      {pendingFile && (
        <ImageCropper
          imageType="profile"
          file={pendingFile}
          onCropped={handleCropped}
          onCancel={() => setPendingFile(null)}
        />
      )}
    </div>
  );
}

export default function Onboarding() {
  const { user, refreshProfile, signOut } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const [fullName, setFullName] = useState("");
  const [gender, setGender] = useState("");
  const [region, setRegion] = useState("");
  const [collegeName, setCollegeName] = useState("");
  const [mainBranchId, setMainBranchId] = useState("");
  const [subBranch, setSubBranch] = useState("");
  const [yearOfStudy, setYearOfStudy] = useState("");
  const [bio, setBio] = useState("");
  const [skills, setSkills] = useState<string[]>([]);
  const [interestedInHackathons, setInterestedInHackathons] = useState(false);
  const [showPhoto, setShowPhoto] = useState(true);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [isAlumni, setIsAlumni] = useState(false);
  const [companyName, setCompanyName] = useState("");
  const [techOrNonTech, setTechOrNonTech] = useState("");
  const [yearOfPassout, setYearOfPassout] = useState<number>(2024);
  const [collegeAutoDetected, setCollegeAutoDetected] = useState(false);

  const { branches: mainBranches, loading: branchesLoading } = useMainBranches();
  const { subBranches, loading: subBranchesLoading } = useSubBranches(mainBranchId || null);
  const { options: genders } = useFormOptions("gender");
  const { options: years } = useFormOptions("year");
  const { options: regions } = useFormOptions("region");
  const { options: alumniDomains } = useFormOptions("alumni_domain");
  const maxUploadKB = useMaxUploadSizeKB();
  const availableColleges = region ? COLLEGES_BY_REGION[region as Region] : [];

  // Auto-detect college from email domain
  useEffect(() => {
    if (!user?.email) return;
    const domain = user.email.split("@")[1]?.toLowerCase();
    if (!domain) return;

    const detectCollege = async () => {
      const { data: college } = await supabase.from("colleges").select("id, name").eq("domain", domain).maybeSingle();

      if (college) {
        // Find which region this college belongs to
        for (const [reg, colleges] of Object.entries(COLLEGES_BY_REGION)) {
          if (colleges.includes(college.name)) {
            setRegion(reg);
            setCollegeName(college.name);
            setCollegeAutoDetected(true);
            return;
          }
        }
      }
    };
    detectCollege();
  }, [user?.email]);

  const selectedMainBranch = mainBranches.find((b) => b.id === mainBranchId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    if (!fullName.trim() || !gender || !mainBranchId || !region || !collegeName || !yearOfStudy) {
      toast.error("Please fill in all required fields");
      return;
    }

    if (!photoFile) {
      toast.error("Please upload a profile photo");
      return;
    }

    if (isAlumni && (!companyName.trim() || !techOrNonTech)) {
      toast.error("Please fill in all alumni details");
      return;
    }

    setLoading(true);
    try {
      let photoUrl: string | null = null;

      if (photoFile) {
        const ext = photoFile.name.split(".").pop();
        const path = `${user.id}/avatar.${ext}`;
        const { error: uploadError } = await supabase.storage
          .from("profile-photos")
          .upload(path, photoFile, { upsert: true });
        if (uploadError) throw uploadError;
        const { data: urlData } = supabase.storage.from("profile-photos").getPublicUrl(path);
        photoUrl = urlData.publicUrl;
      }

      const branchLabel = selectedMainBranch?.label || "";

      // Look up college_id from user's email domain
      let collegeId: string | null = null;
      if (user.email) {
        const domain = user.email.split("@")[1]?.toLowerCase();
        if (domain) {
          const { data: college } = await supabase.from("colleges").select("id").eq("domain", domain).maybeSingle();
          collegeId = college?.id ?? null;
        }
      }

      const { error } = await supabase.from("profiles").insert({
        user_id: user.id,
        full_name: fullName.trim(),
        gender,
        college_name: collegeName,
        branch: branchLabel,
        sub_branch: subBranch || null,
        year_of_study: yearOfStudy === "N/A" ? 0 : Number(yearOfStudy),
        bio: bio.trim(),
        skills,
        interested_in_hackathons: interestedInHackathons,
        show_photo: gender === "Male" ? true : showPhoto,
        photo_url: photoUrl,
        is_alumni: isAlumni,
        company_name: isAlumni ? companyName.trim() || null : null,
        tech_or_non_tech: isAlumni ? techOrNonTech || null : null,
        year_of_passout: isAlumni ? yearOfPassout : null,
        college_id: collegeId,
      });

      if (error) throw error;

      await logEvent(user.id, "profile_created", { branch: branchLabel, sub_branch: subBranch, skills });
      await refreshProfile();
      toast.success("Registration complete. Welcome to SaathVerse.");
      navigate("/search");
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-lg"
      >
        <div className="text-center mb-8">
          <Button
            variant="ghost"
            size="sm"
            className="mb-4 gap-1.5 text-muted-foreground hover:text-foreground"
            onClick={async () => {
              await signOut();
              navigate("/auth");
            }}
          >
            <ArrowLeft size={16} /> Back to Login
          </Button>
          <div className="w-14 h-14 rounded-2xl gradient-saffron mx-auto flex items-center justify-center mb-4 shadow-lg">
            <GraduationCap size={28} className="text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-extrabold text-foreground">Complete Your Profile</h1>
          <p className="text-muted-foreground mt-1">Tell us about yourself to get started</p>
        </div>

        <Card className="border-border/60 shadow-xl overflow-hidden">
          <div className="h-1.5 gradient-saffron" />
          <CardContent className="pt-6 pb-8 px-6">
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-1">
                <Label className="text-sm font-semibold">
                  Profile Photo <span className="text-destructive">*</span>
                </Label>
                <PhotoUploadWithCrop onFileSelect={setPhotoFile} maxSizeKB={maxUploadKB} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="fullName" className="text-sm font-semibold">
                  Full Name <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="fullName"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Your full name"
                  required
                  maxLength={100}
                />
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-semibold">
                  Region <span className="text-destructive">*</span>
                </Label>
                <Select
                  value={region}
                  onValueChange={(v) => {
                    setRegion(v);
                    setCollegeName("");
                  }}
                  disabled={collegeAutoDetected}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select region" />
                  </SelectTrigger>
                  <SelectContent>
                    {regions.map((r) => (
                      <SelectItem key={r} value={r}>
                        {r}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {collegeAutoDetected && (
                  <p className="text-[11px] text-muted-foreground mt-1 flex items-center gap-1">
                    Auto-detected from your email
                    <button
                      type="button"
                      onClick={() => setCollegeAutoDetected(false)}
                      className="text-primary hover:underline inline-flex items-center gap-0.5 ml-1"
                    >
                      <Pencil size={10} /> Edit
                    </button>
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-semibold">
                  College <span className="text-destructive">*</span>
                </Label>
                <Select value={collegeName} onValueChange={setCollegeName} disabled={!region || collegeAutoDetected}>
                  <SelectTrigger>
                    <SelectValue placeholder={region ? "Select your college" : "Select region first"} />
                  </SelectTrigger>
                  <SelectContent className="max-h-60">
                    {availableColleges.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {collegeAutoDetected && (
                  <p className="text-[11px] text-muted-foreground mt-1">Auto-detected from your email</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm font-semibold">
                    Gender <span className="text-destructive">*</span>
                  </Label>
                  <Select value={gender} onValueChange={setGender}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      {genders.map((g) => (
                        <SelectItem key={g} value={g}>
                          {g}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-semibold">
                    Year of Study <span className="text-destructive">*</span>
                  </Label>
                  <Select value={yearOfStudy} onValueChange={setYearOfStudy}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      {years.map((y) => (
                        <SelectItem key={y} value={y}>
                          {y === "N/A" ? "N/A" : `Year ${y}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Main Branch */}
              <div className="space-y-2">
                <Label className="text-sm font-semibold">
                  Branch <span className="text-destructive">*</span>
                </Label>
                <Select
                  value={mainBranchId}
                  onValueChange={(v) => {
                    setMainBranchId(v);
                    setSubBranch("");
                  }}
                  disabled={branchesLoading}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={branchesLoading ? "Loading..." : "Select your branch"} />
                  </SelectTrigger>
                  <SelectContent className="max-h-60">
                    {mainBranches.map((b) => (
                      <SelectItem key={b.id} value={b.id}>
                        {b.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Sub Branch - shown when main branch is selected and has sub-branches */}
              {mainBranchId && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="space-y-2"
                >
                  <Label className="text-sm font-semibold">Specialization</Label>
                  <Select value={subBranch} onValueChange={setSubBranch} disabled={subBranchesLoading}>
                    <SelectTrigger>
                      <SelectValue
                        placeholder={
                          subBranchesLoading
                            ? "Loading..."
                            : subBranches.length === 0
                              ? "No specializations available"
                              : "Select specialization (optional)"
                        }
                      />
                    </SelectTrigger>
                    <SelectContent className="max-h-60">
                      {subBranches.map((sb) => (
                        <SelectItem key={sb.id} value={sb.label}>
                          {sb.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </motion.div>
              )}

              <div className="space-y-2">
                <Label htmlFor="bio" className="text-sm font-semibold">
                  Short Bio
                </Label>
                <Textarea
                  id="bio"
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="Tell others about yourself, your interests..."
                  maxLength={500}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-semibold flex items-center gap-1.5">
                  <Sparkles size={14} className="text-accent" />
                  Skills (up to 3)
                </Label>
                <SkillsInput skills={skills} onChange={setSkills} maxSkills={3} />
              </div>

              {/* Alumni toggle */}
              <div className="flex items-center justify-between p-3 bg-muted/40 rounded-xl">
                <Label htmlFor="isAlumni" className="text-sm font-medium cursor-pointer">
                  🎓 Are you an Alumni?
                </Label>
                <Switch id="isAlumni" checked={isAlumni} onCheckedChange={setIsAlumni} />
              </div>

              {isAlumni && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="space-y-4 p-4 bg-muted/30 rounded-xl border border-border/50"
                >
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Alumni Details</p>
                  <div className="space-y-2">
                    <Label className="text-sm font-semibold">
                      Company Name <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      placeholder="e.g. Google, TCS, Infosys"
                      maxLength={100}
                      required={isAlumni}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm font-semibold">
                      Domain <span className="text-destructive">*</span>
                    </Label>
                    <Select value={techOrNonTech} onValueChange={setTechOrNonTech}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select domain" />
                      </SelectTrigger>
                      <SelectContent>
                        {alumniDomains.length > 0 ? (
                          alumniDomains.map((d) => (
                            <SelectItem key={d} value={d}>
                              {d}
                            </SelectItem>
                          ))
                        ) : (
                          <>
                            <SelectItem value="Tech">Tech</SelectItem>
                            <SelectItem value="Non-Tech">Non-Tech</SelectItem>
                          </>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm font-semibold">
                      Year of Passout <span className="text-destructive">*</span>
                    </Label>
                    <Select value={String(yearOfPassout)} onValueChange={(v) => setYearOfPassout(Number(v))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 20 }, (_, i) => 2010 + i).map((y) => (
                          <SelectItem key={y} value={String(y)}>
                            {y}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </motion.div>
              )}

              <div className="flex items-center justify-between p-3 bg-muted/40 rounded-xl">
                <Label htmlFor="hackathons" className="text-sm font-medium cursor-pointer">
                  🏆 Interested in hackathons?
                </Label>
                <Switch id="hackathons" checked={interestedInHackathons} onCheckedChange={setInterestedInHackathons} />
              </div>

              {gender === "Female" && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="flex items-center justify-between p-3 bg-muted/40 rounded-xl"
                >
                  <div>
                    <Label htmlFor="showPhoto" className="text-sm font-medium">
                      Show profile photo
                    </Label>
                    <p className="text-xs text-muted-foreground">When hidden, a neutral avatar will be shown</p>
                  </div>
                  <Switch id="showPhoto" checked={showPhoto} onCheckedChange={setShowPhoto} />
                </motion.div>
              )}

              <Button type="submit" className="w-full h-11 font-semibold text-sm" disabled={loading}>
                {loading ? "Creating Profile..." : "Create Profile →"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
