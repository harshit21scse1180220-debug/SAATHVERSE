import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, Plus, Trash2, GripVertical, Settings2, Eye, GraduationCap, Mail, Lock, Sparkles, ChevronRight, ChevronDown, FolderOpen, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { mapErrorMessage } from "@/lib/errorMessages";
import { useFormOptions, useMainBranches, useSubBranches } from "@/hooks/useFormOptions";
import { COLLEGES_BY_REGION, type Region } from "@/lib/collegeData";

type FormOption = {
  id: string;
  category: string;
  label: string;
  display_order: number;
  is_active: boolean;
  parent_id: string | null;
};

const CATEGORIES = [
  { value: "branch", label: "Branches", description: "Main branches and specializations shown in profile form" },
  { value: "gender", label: "Genders", description: "Gender options shown during onboarding" },
  { value: "year", label: "Years of Study", description: "Year options students can select" },
  { value: "region", label: "Regions", description: "Regions for college filtering" },
  { value: "alumni_domain", label: "Alumni Domains", description: "Professional domain options for alumni (e.g. Tech, Non-Tech)" },
];

/* ─────────── LIVE PREVIEW: Onboarding Form ─────────── */
function OnboardingPreview() {
  const { branches: mainBranches } = useMainBranches();
  const { options: genders } = useFormOptions("gender");
  const { options: years } = useFormOptions("year");
  const { options: regions } = useFormOptions("region");
  const [region, setRegion] = useState("");
  const [selectedBranchId, setSelectedBranchId] = useState("");
  const { subBranches } = useSubBranches(selectedBranchId || null);
  const availableColleges = region ? (COLLEGES_BY_REGION[region as Region] || []) : [];

  return (
    <div className="space-y-4">
      <div className="text-center mb-4">
        <div className="w-10 h-10 rounded-xl gradient-saffron mx-auto flex items-center justify-center mb-2 shadow-md">
          <GraduationCap size={20} className="text-primary-foreground" />
        </div>
        <h3 className="text-lg font-bold text-foreground">Complete Your Profile</h3>
        <p className="text-xs text-muted-foreground">This is what students see during onboarding</p>
      </div>

      <div className="space-y-3">
        <div className="space-y-1">
          <Label className="text-xs font-semibold">Full Name <span className="text-destructive">*</span></Label>
          <Input placeholder="Your full name" disabled className="h-9 text-sm" />
        </div>

        <div className="space-y-1">
          <Label className="text-xs font-semibold">Region <span className="text-destructive">*</span></Label>
          <Select value={region} onValueChange={(v) => { setRegion(v); }}>
            <SelectTrigger className="h-9 text-sm">
              <SelectValue placeholder="Select region" />
            </SelectTrigger>
            <SelectContent>
              {regions.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-1">
          <Label className="text-xs font-semibold">College <span className="text-destructive">*</span></Label>
          <Select disabled={!region}>
            <SelectTrigger className="h-9 text-sm">
              <SelectValue placeholder={region ? "Select your college" : "Select region first"} />
            </SelectTrigger>
            <SelectContent className="max-h-48">
              {availableColleges.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label className="text-xs font-semibold">Gender <span className="text-destructive">*</span></Label>
            <Select>
              <SelectTrigger className="h-9 text-sm">
                <SelectValue placeholder="Select" />
              </SelectTrigger>
              <SelectContent>
                {genders.map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label className="text-xs font-semibold">Year of Study <span className="text-destructive">*</span></Label>
            <Select>
              <SelectTrigger className="h-9 text-sm">
                <SelectValue placeholder="Select" />
              </SelectTrigger>
              <SelectContent>
                {years.map(y => <SelectItem key={y} value={y}>{y === "N/A" ? "N/A" : `Year ${y}`}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-1">
          <Label className="text-xs font-semibold">Branch <span className="text-destructive">*</span></Label>
          <Select value={selectedBranchId} onValueChange={setSelectedBranchId}>
            <SelectTrigger className="h-9 text-sm">
              <SelectValue placeholder="Select your branch" />
            </SelectTrigger>
            <SelectContent>
              {mainBranches.map(b => <SelectItem key={b.id} value={b.id}>{b.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        {selectedBranchId && subBranches.length > 0 && (
          <div className="space-y-1">
            <Label className="text-xs font-semibold">Specialization</Label>
            <Select>
              <SelectTrigger className="h-9 text-sm">
                <SelectValue placeholder="Select specialization (optional)" />
              </SelectTrigger>
              <SelectContent className="max-h-48">
                {subBranches.map(sb => <SelectItem key={sb.id} value={sb.label}>{sb.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        )}

        <div className="space-y-1">
          <Label className="text-xs font-semibold">Short Bio</Label>
          <Textarea placeholder="Tell others about yourself..." disabled rows={2} className="text-sm" />
        </div>

        <div className="space-y-1">
          <Label className="text-xs font-semibold flex items-center gap-1">
            <Sparkles size={12} className="text-accent" /> Skills (up to 3)
          </Label>
          <Input placeholder="Type a skill and press Enter" disabled className="h-9 text-sm" />
        </div>

        <div className="flex items-center justify-between p-2.5 bg-muted/40 rounded-lg">
          <Label className="text-xs font-medium">🏆 Interested in hackathons?</Label>
          <Switch disabled />
        </div>

        <Button className="w-full h-9 text-sm font-semibold" disabled>
          Create Profile →
        </Button>
      </div>
    </div>
  );
}

/* ─────────── LIVE PREVIEW: Auth Form ─────────── */
function AuthPreview() {
  return (
    <div className="space-y-4">
      <div className="text-center mb-4">
        <div className="w-10 h-10 rounded-xl gradient-saffron mx-auto flex items-center justify-center mb-2 shadow-md">
          <GraduationCap size={20} className="text-primary-foreground" />
        </div>
        <h3 className="text-lg font-bold text-foreground">Welcome Back</h3>
        <p className="text-xs text-muted-foreground">This is what the login/signup page looks like</p>
      </div>

      <div className="space-y-3">
        <div className="space-y-1">
          <Label className="text-xs font-semibold flex items-center gap-1.5">
            <Mail size={12} /> Email
          </Label>
          <Input placeholder="name.admno@galgotiasuniversity.edu.in" disabled className="h-9 text-sm" />
        </div>

        <div className="space-y-1">
          <Label className="text-xs font-semibold flex items-center gap-1.5">
            <Lock size={12} /> Password
          </Label>
          <Input type="password" placeholder="••••••••" disabled className="h-9 text-sm" />
        </div>

        <Button className="w-full h-9 text-sm font-semibold" disabled>
          Sign In
        </Button>

        <p className="text-center text-xs text-muted-foreground">
          Don't have an account? <span className="text-primary font-medium">Sign Up</span>
        </p>
      </div>
    </div>
  );
}

/* ─────────── BRANCH MANAGER WITH SUB-BRANCHES ─────────── */
function BranchManager() {
  const [mainBranches, setMainBranches] = useState<FormOption[]>([]);
  const [expandedBranch, setExpandedBranch] = useState<string | null>(null);
  const [subBranches, setSubBranches] = useState<FormOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [subLoading, setSubLoading] = useState(false);
  const [newMainLabel, setNewMainLabel] = useState("");
  const [newSubLabel, setNewSubLabel] = useState("");
  const [adding, setAdding] = useState(false);

  const fetchMainBranches = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("form_options")
      .select("*")
      .eq("category", "branch")
      .is("parent_id", null)
      .order("display_order", { ascending: true });
    setMainBranches((data as FormOption[]) || []);
    setLoading(false);
  };

  const fetchSubBranches = async (parentId: string) => {
    setSubLoading(true);
    const { data } = await supabase
      .from("form_options")
      .select("*")
      .eq("category", "branch")
      .eq("parent_id", parentId)
      .order("display_order", { ascending: true });
    setSubBranches((data as FormOption[]) || []);
    setSubLoading(false);
  };

  useEffect(() => { fetchMainBranches(); }, []);

  useEffect(() => {
    if (expandedBranch) fetchSubBranches(expandedBranch);
    else setSubBranches([]);
  }, [expandedBranch]);

  const handleAddMain = async () => {
    if (!newMainLabel.trim()) return;
    setAdding(true);
    const { error } = await supabase.from("form_options").insert({
      category: "branch",
      label: newMainLabel.trim(),
      display_order: mainBranches.length,
    });
    if (error) toast.error(mapErrorMessage(error));
    else {
      toast.success(`"${newMainLabel.trim()}" added as main branch`);
      setNewMainLabel("");
      fetchMainBranches();
    }
    setAdding(false);
  };

  const handleAddSub = async () => {
    if (!newSubLabel.trim() || !expandedBranch) return;
    setAdding(true);
    const { error } = await supabase.from("form_options").insert({
      category: "branch",
      label: newSubLabel.trim(),
      display_order: subBranches.length,
      parent_id: expandedBranch,
    });
    if (error) toast.error(mapErrorMessage(error));
    else {
      toast.success(`"${newSubLabel.trim()}" added as specialization`);
      setNewSubLabel("");
      fetchSubBranches(expandedBranch);
    }
    setAdding(false);
  };

  const toggleActive = async (opt: FormOption) => {
    const { error } = await supabase
      .from("form_options")
      .update({ is_active: !opt.is_active })
      .eq("id", opt.id);
    if (error) toast.error(mapErrorMessage(error));
    else {
      if (opt.parent_id) fetchSubBranches(opt.parent_id);
      else fetchMainBranches();
    }
  };

  const handleDelete = async (opt: FormOption) => {
    const label = opt.parent_id ? "specialization" : "branch (and all its specializations)";
    if (!confirm(`Delete "${opt.label}" ${label}?`)) return;
    const { error } = await supabase.from("form_options").delete().eq("id", opt.id);
    if (error) toast.error(mapErrorMessage(error));
    else {
      toast.success(`"${opt.label}" deleted`);
      if (opt.parent_id) fetchSubBranches(opt.parent_id);
      else {
        if (expandedBranch === opt.id) setExpandedBranch(null);
        fetchMainBranches();
      }
    }
  };

  const expandedBranchLabel = mainBranches.find(b => b.id === expandedBranch)?.label;

  return (
    <div>
      {/* Add main branch */}
      <div className="flex gap-2 mb-6">
        <Input
          placeholder="New main branch name..."
          value={newMainLabel}
          onChange={(e) => setNewMainLabel(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAddMain()}
          className="max-w-xs"
          maxLength={100}
        />
        <Button onClick={handleAddMain} disabled={adding || !newMainLabel.trim()} size="sm">
          <Plus size={14} className="mr-1" /> Add Branch
        </Button>
      </div>

      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3].map(i => <div key={i} className="h-12 bg-muted/50 rounded-xl animate-pulse" />)}
        </div>
      ) : (
        <div className="space-y-2">
          {mainBranches.map((opt, idx) => (
            <div key={opt.id}>
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.03 }}
                className={`flex items-center gap-3 p-3 rounded-xl border transition-colors cursor-pointer ${
                  opt.is_active
                    ? expandedBranch === opt.id ? "bg-primary/5 border-primary/30" : "bg-card border-border/60"
                    : "bg-muted/30 border-border/30 opacity-60"
                }`}
                onClick={() => setExpandedBranch(expandedBranch === opt.id ? null : opt.id)}
              >
                {expandedBranch === opt.id ? (
                  <ChevronDown size={14} className="text-primary shrink-0" />
                ) : (
                  <ChevronRight size={14} className="text-muted-foreground shrink-0" />
                )}
                <FolderOpen size={14} className="text-muted-foreground shrink-0" />
                <span className="flex-1 text-sm font-medium text-foreground">{opt.label}</span>
                <Badge variant={opt.is_active ? "default" : "secondary"} className="text-xs pointer-events-none">
                  {opt.is_active ? "Active" : "Hidden"}
                </Badge>
                <Switch
                  checked={opt.is_active}
                  onCheckedChange={(e) => { e; toggleActive(opt); }}
                  onClick={(e) => e.stopPropagation()}
                />
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-destructive hover:text-destructive"
                  onClick={(e) => { e.stopPropagation(); handleDelete(opt); }}
                >
                  <Trash2 size={14} />
                </Button>
              </motion.div>

              {/* Sub-branches */}
              {expandedBranch === opt.id && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="ml-8 mt-2 mb-4 space-y-2"
                >
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                    Specializations under {expandedBranchLabel}
                  </p>

                  {/* Add sub-branch */}
                  <div className="flex gap-2 mb-3">
                    <Input
                      placeholder="New specialization name..."
                      value={newSubLabel}
                      onChange={(e) => setNewSubLabel(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleAddSub()}
                      className="max-w-xs"
                      maxLength={100}
                    />
                    <Button onClick={handleAddSub} disabled={adding || !newSubLabel.trim()} size="sm" variant="outline">
                      <Plus size={14} className="mr-1" /> Add
                    </Button>
                  </div>

                  {subLoading ? (
                    <div className="space-y-2">
                      {[1, 2].map(i => <div key={i} className="h-10 bg-muted/50 rounded-lg animate-pulse" />)}
                    </div>
                  ) : subBranches.length === 0 ? (
                    <p className="text-sm text-muted-foreground py-4 text-center">No specializations yet. Add one above.</p>
                  ) : (
                    subBranches.map((sub, subIdx) => (
                      <motion.div
                        key={sub.id}
                        initial={{ opacity: 0, x: -8 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: subIdx * 0.02 }}
                        className={`flex items-center gap-3 p-2.5 rounded-lg border transition-colors ${
                          sub.is_active
                            ? "bg-card border-border/40"
                            : "bg-muted/20 border-border/20 opacity-60"
                        }`}
                      >
                        <GripVertical size={12} className="text-muted-foreground shrink-0" />
                        <span className="flex-1 text-sm text-foreground">{sub.label}</span>
                        <Badge variant={sub.is_active ? "default" : "secondary"} className="text-[10px] pointer-events-none">
                          {sub.is_active ? "Active" : "Hidden"}
                        </Badge>
                        <Switch
                          checked={sub.is_active}
                          onCheckedChange={() => toggleActive(sub)}
                        />
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive hover:text-destructive"
                          onClick={() => handleDelete(sub)}
                        >
                          <Trash2 size={12} />
                        </Button>
                      </motion.div>
                    ))
                  )}
                </motion.div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ─────────── GENERIC OPTIONS MANAGER (non-branch categories) ─────────── */
function GenericOptionsManager({ category }: { category: string }) {
  const [options, setOptions] = useState<FormOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [newLabel, setNewLabel] = useState("");
  const [adding, setAdding] = useState(false);

  const fetchOptions = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("form_options")
      .select("*")
      .eq("category", category)
      .is("parent_id", null)
      .order("display_order", { ascending: true });
    setOptions((data as FormOption[]) || []);
    setLoading(false);
  };

  useEffect(() => { fetchOptions(); }, [category]);

  const handleAdd = async () => {
    if (!newLabel.trim()) return;
    setAdding(true);
    const { error } = await supabase.from("form_options").insert({
      category,
      label: newLabel.trim(),
      display_order: options.length,
    });
    if (error) toast.error(mapErrorMessage(error));
    else {
      toast.success(`"${newLabel.trim()}" added`);
      setNewLabel("");
      fetchOptions();
    }
    setAdding(false);
  };

  const toggleActive = async (opt: FormOption) => {
    const { error } = await supabase
      .from("form_options")
      .update({ is_active: !opt.is_active })
      .eq("id", opt.id);
    if (error) toast.error(mapErrorMessage(error));
    else fetchOptions();
  };

  const handleDelete = async (opt: FormOption) => {
    if (!confirm(`Delete "${opt.label}"?`)) return;
    const { error } = await supabase.from("form_options").delete().eq("id", opt.id);
    if (error) toast.error(mapErrorMessage(error));
    else {
      toast.success(`"${opt.label}" deleted`);
      fetchOptions();
    }
  };

  return (
    <div>
      <div className="flex gap-2 mb-6">
        <Input
          placeholder={`New ${category} name...`}
          value={newLabel}
          onChange={(e) => setNewLabel(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAdd()}
          className="max-w-xs"
          maxLength={100}
        />
        <Button onClick={handleAdd} disabled={adding || !newLabel.trim()} size="sm">
          <Plus size={14} className="mr-1" /> Add
        </Button>
      </div>

      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3].map(i => <div key={i} className="h-12 bg-muted/50 rounded-xl animate-pulse" />)}
        </div>
      ) : options.length === 0 ? (
        <p className="text-center py-12 text-muted-foreground">No options yet. Add one above.</p>
      ) : (
        <div className="space-y-2">
          {options.map((opt, idx) => (
            <motion.div
              key={opt.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.03 }}
              className={`flex items-center gap-3 p-3 rounded-xl border transition-colors ${
                opt.is_active
                  ? "bg-card border-border/60"
                  : "bg-muted/30 border-border/30 opacity-60"
              }`}
            >
              <GripVertical size={14} className="text-muted-foreground shrink-0" />
              <span className="flex-1 text-sm font-medium text-foreground">{opt.label}</span>
              <Badge variant={opt.is_active ? "default" : "secondary"} className="text-xs pointer-events-none">
                {opt.is_active ? "Active" : "Hidden"}
              </Badge>
              <Switch
                checked={opt.is_active}
                onCheckedChange={() => toggleActive(opt)}
              />
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-destructive hover:text-destructive"
                onClick={() => handleDelete(opt)}
              >
                <Trash2 size={14} />
              </Button>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ─────────── MAIN ADMIN PAGE ─────────── */
export default function AdminFormOptions() {
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState("branch");

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-muted-foreground">
        <Shield size={48} className="mb-4 opacity-20" />
        <p className="text-lg font-semibold">Access Denied</p>
      </div>
    );
  }

  const catMeta = CATEGORIES.find(c => c.value === activeCategory);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-1">
          <button onClick={() => navigate("/admin/dashboard")} className="p-2 rounded-full hover:bg-muted transition-colors">
            <ArrowLeft size={20} className="text-foreground" />
          </button>
          <div className="w-10 h-10 rounded-xl gradient-navy flex items-center justify-center shadow-md">
            <Settings2 size={20} className="text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-foreground tracking-tight">Profile Form Options</h1>
            <p className="text-sm text-muted-foreground">Add or remove options students see during onboarding</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Left: Options Manager */}
        <div className="lg:col-span-3">
          {/* Category tabs */}
          <div className="flex gap-2 mb-4 flex-wrap">
            {CATEGORIES.map(cat => (
              <Button
                key={cat.value}
                variant={activeCategory === cat.value ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveCategory(cat.value)}
              >
                {cat.label}
              </Button>
            ))}
          </div>

          {catMeta && (
            <p className="text-sm text-muted-foreground mb-4">{catMeta.description}</p>
          )}

          {activeCategory === "branch" ? (
            <BranchManager />
          ) : (
            <GenericOptionsManager category={activeCategory} />
          )}
        </div>

        {/* Right: Live Preview */}
        <div className="lg:col-span-2">
          <div className="sticky top-4">
            <div className="flex items-center gap-2 mb-3">
              <Eye size={16} className="text-primary" />
              <h2 className="text-sm font-bold text-foreground">Live Preview</h2>
            </div>

            <Tabs defaultValue="onboarding">
              <TabsList className="w-full mb-3">
                <TabsTrigger value="onboarding" className="flex-1 text-xs">Onboarding Form</TabsTrigger>
                <TabsTrigger value="auth" className="flex-1 text-xs">Login / Signup</TabsTrigger>
              </TabsList>

              <Card className="border-border/60 shadow-lg overflow-hidden">
                <div className="h-1 gradient-saffron" />
                <CardContent className="p-4">
                  <TabsContent value="onboarding" className="mt-0">
                    <OnboardingPreview />
                  </TabsContent>
                  <TabsContent value="auth" className="mt-0">
                    <AuthPreview />
                  </TabsContent>
                </CardContent>
              </Card>

              <p className="text-xs text-muted-foreground mt-2 text-center">
                Changes reflect in real-time when you add/remove options
              </p>
            </Tabs>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
