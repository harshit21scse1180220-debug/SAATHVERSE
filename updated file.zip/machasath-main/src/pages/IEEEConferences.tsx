import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, MapPin, ArrowLeft, ArrowRight, ExternalLink, Filter } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { CATEGORIES } from "@/lib/categories";

interface Conference {
  id: string;
  title: string;
  organizer: string;
  description: string | null;
  category: string;
  mode: string;
  deadline_date: string;
  link_url: string | null;
  status: string;
  created_at: string;
}

export default function IEEEConferences() {
  const navigate = useNavigate();
  const { collegeId } = useAuth();
  const [conferences, setConferences] = useState<Conference[]>([]);
  const [loading, setLoading] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState("all");

  useEffect(() => {
    if (!collegeId) return;
    const fetch = async () => {
      const { data } = await supabase
        .from("conferences")
        .select("*")
        .or(`college_id.eq.${collegeId},college_id.is.null`)
        .order("deadline_date", { ascending: true });
      setConferences(data || []);
      setLoading(false);
    };
    fetch();
  }, [collegeId]);

  const now = new Date();
  const cutoff = new Date(now.getTime() - 24 * 60 * 60 * 1000);

  const filtered = conferences.filter(
    (c) => categoryFilter === "all" || c.category === categoryFilter
  );

  const upcoming = filtered.filter(
    (c) => new Date(c.deadline_date) >= now
  );
  const recent = filtered.filter(
    (c) => {
      const d = new Date(c.deadline_date);
      return d < now && d >= cutoff;
    }
  );
  const past = filtered.filter(
    (c) => new Date(c.deadline_date) < cutoff
  );

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <Button variant="ghost" onClick={() => navigate(-1)} className="mb-4">
        <ArrowLeft size={16} className="mr-2" /> Back
      </Button>

      <div className="flex items-center gap-3 mb-1">
        <Calendar size={28} className="text-primary" />
        <h1 className="text-2xl font-bold text-foreground">IEEE Conferences</h1>
      </div>
      <p className="text-muted-foreground text-sm mb-6">
        Upcoming and recent IEEE conferences
      </p>

      {/* Filter */}
      <div className="flex items-center gap-2 mb-6">
        <Filter size={16} className="text-muted-foreground" />
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {CATEGORIES.map((c) => (
              <SelectItem key={c} value={c}>{c}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-32 bg-muted rounded-lg animate-pulse" />
          ))}
        </div>
      ) : (
        <>
          {/* Upcoming */}
          {upcoming.length > 0 && (
            <>
              <h2 className="text-lg font-bold text-foreground mb-3 flex items-center gap-2">
                <Calendar size={18} className="text-muted-foreground" />
                Upcoming
              </h2>
              <div className="space-y-4 mb-8">
                {upcoming.map((c, i) => (
                  <ConferenceCard key={c.id} conference={c} index={i} />
                ))}
              </div>
            </>
          )}

          {/* Recent (within 24h of deadline) */}
          {recent.length > 0 && (
            <>
              <h2 className="text-lg font-bold text-foreground mb-3 flex items-center gap-2">
                <Calendar size={18} className="text-muted-foreground" />
                Recently Closed
              </h2>
              <div className="space-y-4 mb-8">
                {recent.map((c, i) => (
                  <ConferenceCard key={c.id} conference={c} index={i} closed />
                ))}
              </div>
            </>
          )}

          {/* Past */}
          {past.length > 0 && (
            <>
              <h2 className="text-lg font-bold text-foreground mb-3 flex items-center gap-2">
                <Calendar size={18} className="text-muted-foreground" />
                Past Conferences
              </h2>
              <div className="space-y-4">
                {past.map((c, i) => (
                  <ConferenceCard key={c.id} conference={c} index={i} closed />
                ))}
              </div>
            </>
          )}

          {filtered.length === 0 && (
            <p className="text-center py-10 text-muted-foreground">No conferences found.</p>
          )}
        </>
      )}
    </motion.div>
  );
}

function ConferenceCard({ conference: c, index, closed }: { conference: any; index: number; closed?: boolean }) {
  const isPast = new Date(c.deadline_date) < new Date();

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
    >
      <Card className="border-border/60 hover:shadow-lg transition-all duration-200">
        <CardContent className="p-5">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <h3 className="text-lg font-bold text-foreground">{c.title}</h3>
                <Badge variant={isPast ? "outline" : "default"} className="text-xs">
                  {isPast ? "Closed" : "Open"}
                </Badge>
                <Badge variant="secondary" className="text-xs">{c.category}</Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-2">By {c.organizer}</p>
              {c.description && (
                <p className="text-sm text-muted-foreground line-clamp-2">{c.description}</p>
              )}
              <div className="flex items-center justify-between mt-3">
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <MapPin size={12} /> {c.mode}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar size={12} /> {format(new Date(c.deadline_date), "MMM d, yyyy")}
                  </span>
                </div>
                {c.link_url && (
                  <a
                    href={c.link_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="flex items-center gap-1 text-xs font-medium text-primary hover:underline"
                  >
                    View <ExternalLink size={12} />
                  </a>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
