import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { toast } from "sonner";
import { mapErrorMessage } from "@/lib/errorMessages";
import { motion, AnimatePresence } from "framer-motion";
import { Mail, Lock, RefreshCw, ArrowLeft, Eye, EyeOff, GraduationCap } from "lucide-react";

const ADMIN_EMAILS = ["harshit02425@gmail.com", "tharunkumarm2405@gmail.com"];

type AuthView = "login" | "signup";

export default function Auth() {
  const [view, setView] = useState<AuthView>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotLoading, setForgotLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const validateEmail = async (email: string): Promise<boolean> => {
    if (ADMIN_EMAILS.includes(email.toLowerCase())) return true;
    const domain = email.split("@")[1]?.toLowerCase();
    if (!domain) {
      toast.error("Invalid email format");
      return false;
    }
    const { data } = await supabase.from("colleges").select("id").eq("domain", domain).maybeSingle();
    if (!data) {
      toast.error("Your college is not registered on this platform.", {
        description: "Contact your institution to get added.",
      });
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!(await validateEmail(email))) return;
    if (password.length < 6) {
      toast.error("Password must be at least 6 characters");
      return;
    }

    setLoading(true);
    try {
      if (view === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("Welcome back!");
      } else {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        toast.success("Account created! Redirecting...");
      }
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const { user, loading: authLoading } = useAuth();
  if (authLoading || user) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: 'hsl(220 30% 6%)' }}>
        <div className="w-8 h-8 border-2 border-[hsl(38,92%,50%)] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden" style={{ background: 'hsl(220 30% 6%)' }}>
      {/* Constellation / network background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Gradient overlays */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full opacity-15"
          style={{ background: 'radial-gradient(circle, hsl(38 92% 50% / 0.3), transparent 70%)' }} />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] rounded-full opacity-10"
          style={{ background: 'radial-gradient(circle, hsl(200 80% 50% / 0.3), transparent 70%)' }} />
        <div className="absolute bottom-0 right-0 w-[400px] h-[400px] rounded-full opacity-10"
          style={{ background: 'radial-gradient(circle, hsl(38 92% 50% / 0.2), transparent 70%)' }} />
        {/* Dot grid pattern */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.06]" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="dots" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
              <circle cx="1" cy="1" r="1" fill="hsl(38 92% 50%)" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#dots)" />
        </svg>
        {/* Network lines */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.04]" xmlns="http://www.w3.org/2000/svg">
          <line x1="10%" y1="20%" x2="40%" y2="10%" stroke="hsl(38 92% 50%)" strokeWidth="0.5" />
          <line x1="40%" y1="10%" x2="70%" y2="25%" stroke="hsl(38 92% 50%)" strokeWidth="0.5" />
          <line x1="70%" y1="25%" x2="90%" y2="15%" stroke="hsl(38 92% 50%)" strokeWidth="0.5" />
          <line x1="5%" y1="80%" x2="30%" y2="90%" stroke="hsl(200 80% 50%)" strokeWidth="0.5" />
          <line x1="30%" y1="90%" x2="60%" y2="85%" stroke="hsl(200 80% 50%)" strokeWidth="0.5" />
          <line x1="60%" y1="85%" x2="95%" y2="75%" stroke="hsl(38 92% 50%)" strokeWidth="0.5" />
          <line x1="20%" y1="50%" x2="50%" y2="45%" stroke="hsl(38 92% 50%)" strokeWidth="0.3" />
          <line x1="50%" y1="45%" x2="80%" y2="55%" stroke="hsl(200 80% 50%)" strokeWidth="0.3" />
        </svg>
      </div>

      <div className="w-full max-w-md px-5 py-8 relative z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={view}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.35 }}
          >
            {/* Logo */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 mb-4">
                <GraduationCap size={48} className="text-[hsl(38,92%,50%)]" />
              </div>
              <h1 className="text-3xl font-extrabold text-white tracking-tight">
                Saath<span className="text-[hsl(38,92%,50%)]">Verse</span>
              </h1>
              <p className="text-[hsl(220,15%,55%)] mt-1 text-xs font-semibold tracking-[0.2em] uppercase">
                Campus Collaboration Platform
              </p>
            </div>

            {/* Glass card */}
            <div className="relative rounded-2xl overflow-hidden"
              style={{
                background: 'hsl(220 30% 10% / 0.7)',
                backdropFilter: 'blur(20px)',
                border: '1px solid hsl(220 30% 20% / 0.6)',
                boxShadow: '0 0 40px hsl(38 92% 50% / 0.05), inset 0 1px 0 hsl(220 30% 30% / 0.3)',
              }}>
              {/* Top accent glow */}
              <div className="h-[2px] gradient-saffron opacity-80" />

              <div className="p-6 pb-3">
                <h2 className="text-xl font-bold text-white text-center">
                  {view === "login" ? "Welcome Back" : "Create Account"}
                </h2>
                <p className="text-sm text-[hsl(220,15%,55%)] text-center mt-1">
                  {view === "login" ? "Sign in with your college email" : "Register with your college email"}
                </p>
              </div>

              <form onSubmit={handleSubmit} className="p-6 pt-4 space-y-5">
                {/* Email */}
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-semibold text-[hsl(220,15%,75%)] flex items-center gap-2">
                    <Mail size={14} className="text-[hsl(38,92%,50%)]" /> College Email
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@college.edu.in"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="h-12 bg-[hsl(220,30%,8%)] border-[hsl(38,92%,50%,0.4)] text-white placeholder:text-[hsl(220,15%,40%)] focus-visible:ring-[hsl(38,92%,50%)] focus-visible:border-[hsl(38,92%,50%)]"
                  />
                </div>

                {/* Password */}
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-semibold text-[hsl(220,15%,75%)] flex items-center gap-2">
                    <Lock size={14} className="text-[hsl(38,92%,50%)]" /> Password
                  </Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="At least 6 characters"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      minLength={6}
                      className="h-12 pr-11 bg-[hsl(220,30%,8%)] border-[hsl(38,92%,50%,0.4)] text-white placeholder:text-[hsl(220,15%,40%)] focus-visible:ring-[hsl(38,92%,50%)] focus-visible:border-[hsl(38,92%,50%)]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[hsl(220,15%,45%)] hover:text-white transition-colors"
                      tabIndex={-1}
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>

                {/* Forgot password */}
                {view === "login" && (
                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={() => { setForgotEmail(email); setForgotOpen(true); }}
                      className="text-sm text-[hsl(38,92%,50%)] hover:underline font-semibold"
                    >
                      Forgot password?
                    </button>
                  </div>
                )}

                {/* Submit */}
                <Button
                  type="submit"
                  className="w-full h-12 font-bold text-base rounded-lg text-white border-0"
                  style={{
                    background: 'linear-gradient(135deg, hsl(38 92% 50%), hsl(25 95% 55%))',
                  }}
                  disabled={loading}
                >
                  {loading ? "Please wait..." : view === "login" ? "Sign In" : "Create Account"}
                </Button>

                {/* Toggle */}
                <p className="text-center text-sm text-[hsl(220,15%,55%)] pt-1">
                  {view === "login" ? "Don't have an account?" : "Already have an account?"}{" "}
                  <button
                    type="button"
                    onClick={() => setView(view === "login" ? "signup" : "login")}
                    className="text-white font-bold hover:underline"
                  >
                    {view === "login" ? "Register" : "Sign In"}
                  </button>
                </p>
              </form>
            </div>

            <p className="text-xs text-center text-[hsl(220,15%,35%)] mt-5">
              Only registered college emails are accepted.
            </p>
          </motion.div>
        </AnimatePresence>

        {/* Forgot Password Dialog */}
        <ForgotPasswordDialog
          open={forgotOpen}
          onOpenChange={setForgotOpen}
          forgotEmail={forgotEmail}
          onForgotEmailChange={setForgotEmail}
          forgotLoading={forgotLoading}
          setForgotLoading={setForgotLoading}
        />
      </div>
    </div>
  );
}

/* ─── Forgot Password Dialog ─── */
function ForgotPasswordDialog({
  open,
  onOpenChange,
  forgotEmail,
  onForgotEmailChange,
  forgotLoading,
  setForgotLoading,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  forgotEmail: string;
  onForgotEmailChange: (v: string) => void;
  forgotLoading: boolean;
  setForgotLoading: (v: boolean) => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm rounded-2xl bg-[hsl(220,30%,10%)] border-[hsl(220,30%,20%)] text-white">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold text-white">Reset Password</DialogTitle>
          <DialogDescription className="text-sm text-[hsl(220,15%,55%)]">
            Enter your registered email and we'll send you a password reset link.
          </DialogDescription>
        </DialogHeader>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            if (!forgotEmail.trim()) return;
            setForgotLoading(true);
            try {
              const { error } = await supabase.auth.resetPasswordForEmail(forgotEmail.trim(), {
                redirectTo: `${window.location.origin}/reset-password`,
              });
              if (error) throw error;
              toast.success("Reset link sent!", {
                description: "Check your email for the password reset link.",
              });
              onOpenChange(false);
            } catch (error: unknown) {
              toast.error(mapErrorMessage(error));
            } finally {
              setForgotLoading(false);
            }
          }}
          className="space-y-4"
        >
          <div className="space-y-2">
            <Label htmlFor="forgotEmail" className="text-sm font-semibold text-[hsl(220,15%,75%)] flex items-center gap-2">
              <Mail size={14} className="text-[hsl(38,92%,50%)]" /> Email Address
            </Label>
            <Input
              id="forgotEmail"
              type="email"
              placeholder="your.email@college.edu.in"
              value={forgotEmail}
              onChange={(e) => onForgotEmailChange(e.target.value)}
              required
              className="h-12 bg-[hsl(220,30%,8%)] border-[hsl(38,92%,50%,0.4)] text-white placeholder:text-[hsl(220,15%,40%)] focus-visible:ring-[hsl(38,92%,50%)]"
            />
          </div>
          <Button
            type="submit"
            className="w-full h-11 font-bold text-white border-0"
            style={{ background: 'linear-gradient(135deg, hsl(38 92% 50%), hsl(25 95% 55%))' }}
            disabled={forgotLoading}
          >
            {forgotLoading ? "Sending..." : "Send Reset Link"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
