import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ProfilePhoto from "@/components/ProfilePhoto";
import { toast } from "sonner";
import { mapErrorMessage } from "@/lib/errorMessages";
import { logEvent } from "@/lib/eventLog";
import type { Tables } from "@/integrations/supabase/types";
import { Check, X, Send, Inbox } from "lucide-react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";

type CollabRequest = Tables<"collaboration_requests">;
type Profile = Tables<"profiles">;

interface RequestWithProfile extends CollabRequest {
  profile?: Profile;
}

export default function Requests() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [incoming, setIncoming] = useState<RequestWithProfile[]>([]);
  const [outgoing, setOutgoing] = useState<RequestWithProfile[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchRequests = async () => {
    if (!user) return;
    setLoading(true);

    // Incoming requests
    const { data: inData } = await supabase
      .from("collaboration_requests")
      .select("*")
      .eq("receiver_id", user.id)
      .order("created_at", { ascending: false });

    // Outgoing requests
    const { data: outData } = await supabase
      .from("collaboration_requests")
      .select("*")
      .eq("sender_id", user.id)
      .order("created_at", { ascending: false });

    // Fetch profiles for all related users
    const userIds = new Set<string>();
    inData?.forEach((r) => userIds.add(r.sender_id));
    outData?.forEach((r) => userIds.add(r.receiver_id));

    const { data: profiles } = await supabase
      .from("profiles")
      .select("*")
      .in("user_id", Array.from(userIds));

    const profileMap = new Map<string, Profile>();
    profiles?.forEach((p) => profileMap.set(p.user_id, p));

    setIncoming(
      (inData || []).map((r) => ({ ...r, profile: profileMap.get(r.sender_id) }))
    );
    setOutgoing(
      (outData || []).map((r) => ({ ...r, profile: profileMap.get(r.receiver_id) }))
    );
    setLoading(false);
  };

  useEffect(() => {
    fetchRequests();
  }, [user]);

  const handleAction = async (requestId: string, status: "accepted" | "rejected") => {
    if (!user) return;
    try {
      const { error } = await supabase
        .from("collaboration_requests")
        .update({ status })
        .eq("id", requestId);
      if (error) throw error;

      if (status === "accepted") {
        await logEvent(user.id, "collaboration_request_accepted", { request_id: requestId });
      }

      toast.success(status === "accepted" ? "Request accepted!" : "Request declined");
      fetchRequests();
    } catch (error: unknown) {
      toast.error(mapErrorMessage(error));
    }
  };

  const RequestCard = ({ request, type }: { request: RequestWithProfile; type: "incoming" | "outgoing" }) => {
    const profile = request.profile;
    if (!profile) return null;

    return (
      <Card className="border-border/60">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div
              className="cursor-pointer"
              onClick={() => navigate(`/profile/${profile.user_id}`)}
            >
              <ProfilePhoto
                fullName={profile.full_name}
                gender={profile.gender}
                photoUrl={profile.photo_url}
                showPhoto={profile.show_photo}
                size="sm"
              />
            </div>
            <div className="flex-1 min-w-0">
              <p
                className="font-semibold text-foreground cursor-pointer hover:underline"
                onClick={() => navigate(`/profile/${profile.user_id}`)}
              >
                {profile.full_name}
              </p>
              <p className="text-xs text-muted-foreground">
                {profile.branch} · {profile.year_of_study === 0 ? "N/A" : `Year ${profile.year_of_study}`}
              </p>
              {request.message && (
                <p className="text-sm text-muted-foreground mt-1 italic">
                  "{request.message}"
                </p>
              )}
              <div className="mt-2 flex items-center gap-2">
                {request.status === "pending" && type === "incoming" && (
                  <>
                    <Button
                      size="sm"
                      onClick={() => handleAction(request.id, "accepted")}
                    >
                      <Check size={14} className="mr-1" /> Accept
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleAction(request.id, "rejected")}
                    >
                      <X size={14} className="mr-1" /> Decline
                    </Button>
                  </>
                )}
                {request.status !== "pending" && (
                  <Badge
                    variant={
                      request.status === "accepted" ? "default" : "destructive"
                    }
                  >
                    {request.status === "accepted" ? "✅ Connected" : "❌ Declined"}
                  </Badge>
                )}
                {request.status === "pending" && type === "outgoing" && (
                  <Badge variant="outline">⏳ Pending</Badge>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <h1 className="text-2xl font-bold text-foreground mb-1">Collaboration Requests</h1>
      <p className="text-muted-foreground text-sm mb-6">Manage your connection requests</p>

      <Tabs defaultValue="incoming">
        <TabsList>
          <TabsTrigger value="incoming" className="gap-2">
            <Inbox size={14} /> Incoming
          </TabsTrigger>
          <TabsTrigger value="outgoing" className="gap-2">
            <Send size={14} /> Sent
          </TabsTrigger>
        </TabsList>

        <TabsContent value="incoming" className="mt-4">
          {loading ? (
            <div className="space-y-3">
              {[1, 2].map((i) => (
                <div key={i} className="h-20 bg-muted rounded-lg animate-pulse" />
              ))}
            </div>
          ) : incoming.length === 0 ? (
            <p className="text-center py-8 text-muted-foreground">No incoming requests</p>
          ) : (
            <div className="space-y-3">
              {incoming.map((r) => (
                <RequestCard key={r.id} request={r} type="incoming" />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="outgoing" className="mt-4">
          {loading ? (
            <div className="space-y-3">
              {[1, 2].map((i) => (
                <div key={i} className="h-20 bg-muted rounded-lg animate-pulse" />
              ))}
            </div>
          ) : outgoing.length === 0 ? (
            <p className="text-center py-8 text-muted-foreground">No sent requests</p>
          ) : (
            <div className="space-y-3">
              {outgoing.map((r) => (
                <RequestCard key={r.id} request={r} type="outgoing" />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </motion.div>
  );
}
