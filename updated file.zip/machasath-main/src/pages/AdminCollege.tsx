import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Building2, Users, ImageIcon, Trophy, Layers, BarChart3, Globe, Palette } from "lucide-react";
import type { Tables } from "@/integrations/supabase/types";
import { motion } from "framer-motion";

type College = Tables<"colleges">;
type Profile = Tables<"profiles">;

export default function AdminCollege() {
  const { collegeId } = useParams<{ collegeId: string }>();
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [college, setCollege] = useState<College | null>(null);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [stats, setStats] = useState({ hackathons: 0, carousels: 0, sections: 0, featured: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!collegeId) return;
    const fetchAll = async () => {
      setLoading(true);
      const [collegeRes, profilesRes, hackRes, carouselRes, sectionsRes, featuredRes] = await Promise.all([
        supabase.from("colleges").select("*").eq("id", collegeId).maybeSingle(),
        supabase.from("profiles").select("*").eq("college_id", collegeId).order("created_at", { ascending: false }),
        supabase.from("hackathons").select("id", { count: "exact", head: true }).eq("college_id", collegeId),
        supabase.from("carousel_slides").select("id", { count: "exact", head: true }).eq("college_id", collegeId),
        supabase.from("content_sections").select("id", { count: "exact", head: true }).eq("college_id", collegeId),
        supabase.from("branch_featured_students").select("id", { count: "exact", head: true }).eq("college_id", collegeId),
      ]);
      setCollege(collegeRes.data);
      setProfiles(profilesRes.data || []);
      setStats({
        hackathons: hackRes.count || 0,
        carousels: carouselRes.count || 0,
        sections: sectionsRes.count || 0,
        featured: featuredRes.count || 0,
      });
      setLoading(false);
    };
    fetchAll();
  }, [collegeId]);

  if (!isAdmin) {
    return <p className="text-center py-12 text-muted-foreground">Access denied.</p>;
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!college) {
    return <p className="text-center py-12 text-muted-foreground">College not found.</p>;
  }

  const branchCounts: Record<string, number> = {};
  profiles.forEach((p) => {
    branchCounts[p.branch] = (branchCounts[p.branch] || 0) + 1;
  });

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <Button variant="ghost" size="sm" onClick={() => navigate("/admin/dashboard")} className="mb-4 gap-1.5">
        <ArrowLeft size={14} /> Back to Dashboard
      </Button>

      {/* College Header */}
      <div className="flex items-center gap-4 mb-6">
        {college.logo_url ? (
          <img src={college.logo_url} alt={college.name} className="w-14 h-14 rounded-xl object-cover shadow-sm" />
        ) : (
          <div className="w-14 h-14 rounded-xl bg-muted flex items-center justify-center shadow-sm">
            <Building2 size={24} className="text-muted-foreground" />
          </div>
        )}
        <div>
          <h1 className="text-2xl font-extrabold text-foreground tracking-tight">{college.name}</h1>
          <div className="flex items-center gap-3 text-sm text-muted-foreground mt-0.5">
            <span className="flex items-center gap-1"><Globe size={14} /> {college.domain}</span>
            {college.primary_color && (
              <span className="flex items-center gap-1">
                <Palette size={14} />
                <span className="w-4 h-4 rounded-full border border-border" style={{ backgroundColor: `hsl(${college.primary_color})` }} />
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-8">
        {[
          { label: "Users", value: profiles.length, icon: Users },
          { label: "Hackathons", value: stats.hackathons, icon: Trophy },
          { label: "Carousel Slides", value: stats.carousels, icon: ImageIcon },
          { label: "Content Sections", value: stats.sections, icon: Layers },
          { label: "Featured Students", value: stats.featured, icon: BarChart3 },
        ].map((s) => (
          <div key={s.label} className="bg-card border border-border/60 rounded-xl p-4 text-center">
            <s.icon size={18} className="mx-auto text-muted-foreground mb-1" />
            <p className="text-2xl font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="mb-8">
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Quick Actions</h2>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={() => navigate("/admin/hackathons")} className="gap-1.5">
            <Trophy size={14} /> Manage Hackathons
          </Button>
          <Button variant="outline" size="sm" onClick={() => navigate("/admin/carousel")} className="gap-1.5">
            <ImageIcon size={14} /> Manage Carousel
          </Button>
          <Button variant="outline" size="sm" onClick={() => navigate("/admin/content-carousel")} className="gap-1.5">
            <Layers size={14} /> Content Sections
          </Button>
          <Button variant="outline" size="sm" onClick={() => navigate("/admin/featured-students")} className="gap-1.5">
            <BarChart3 size={14} /> Featured Students
          </Button>
          <Button variant="outline" size="sm" onClick={() => navigate("/admin/ieee")} className="gap-1.5">
            <Layers size={14} /> IEEE / Conferences
          </Button>
        </div>
      </div>

      {/* Branch Breakdown */}
      <div className="mb-8">
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Users by Branch</h2>
        {Object.keys(branchCounts).length === 0 ? (
          <p className="text-sm text-muted-foreground">No users registered yet.</p>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
            {Object.entries(branchCounts)
              .sort((a, b) => b[1] - a[1])
              .map(([branch, count]) => (
                <div key={branch} className="bg-card border border-border/60 rounded-xl p-3 flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground truncate">{branch}</span>
                  <Badge variant="secondary" className="text-xs shrink-0 ml-2">{count}</Badge>
                </div>
              ))}
          </div>
        )}
      </div>

      {/* Recent Users */}
      <div>
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
          Recent Users <Badge variant="secondary" className="ml-2 text-xs">{profiles.length}</Badge>
        </h2>
        {profiles.length === 0 ? (
          <p className="text-sm text-muted-foreground">No users registered yet.</p>
        ) : (
          <div className="space-y-2">
            {profiles.slice(0, 20).map((p) => (
              <div key={p.id} className="flex items-center gap-3 p-3 bg-card border border-border/60 rounded-xl">
                {p.photo_url ? (
                  <img src={p.photo_url} alt={p.full_name} className="w-9 h-9 rounded-full object-cover" />
                ) : (
                  <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center text-xs font-bold text-muted-foreground">
                    {p.full_name.charAt(0)}
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <Link to={`/profile/${p.user_id}`} className="text-sm font-semibold text-foreground hover:underline truncate block">
                    {p.full_name}
                  </Link>
                  <p className="text-xs text-muted-foreground">{p.branch} · Year {p.year_of_study}</p>
                </div>
                {p.is_alumni && <Badge variant="outline" className="text-xs shrink-0">Alumni</Badge>}
              </div>
            ))}
            {profiles.length > 20 && (
              <p className="text-xs text-muted-foreground text-center pt-2">
                Showing 20 of {profiles.length} users
              </p>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}
