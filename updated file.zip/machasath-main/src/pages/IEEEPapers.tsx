import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, FileText, ExternalLink, Filter, Calendar } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { CATEGORIES } from "@/lib/categories";

interface Paper {
  id: string;
  title: string;
  author_name: string;
  category: string;
  abstract: string | null;
  link_url: string | null;
  published_date: string;
  created_at: string;
}

export default function IEEEPapers() {
  const navigate = useNavigate();
  const { collegeId } = useAuth();
  const [papers, setPapers] = useState<Paper[]>([]);
  const [loading, setLoading] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState("all");

  useEffect(() => {
    if (!collegeId) return;
    const fetch = async () => {
      const { data } = await supabase
        .from("published_papers")
        .select("*")
        .or(`college_id.eq.${collegeId},college_id.is.null`)
        .order("published_date", { ascending: false });
      setPapers(data || []);
      setLoading(false);
    };
    fetch();
  }, [collegeId]);

  const filtered = papers.filter(
    (p) => categoryFilter === "all" || p.category === categoryFilter
  );

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <Button variant="ghost" onClick={() => navigate(-1)} className="mb-4">
        <ArrowLeft size={16} className="mr-2" /> Back
      </Button>

      <div className="flex items-center gap-3 mb-1">
        <FileText size={28} className="text-primary" />
        <h1 className="text-2xl font-bold text-foreground">Published Papers</h1>
      </div>
      <p className="text-muted-foreground text-sm mb-6">
        Research papers published by IEEE members
      </p>

      {/* Filter */}
      <div className="flex items-center gap-2 mb-6">
        <Filter size={16} className="text-muted-foreground" />
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {CATEGORIES.map((c) => (
              <SelectItem key={c} value={c}>{c}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-28 bg-muted rounded-lg animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <p className="text-center py-10 text-muted-foreground">No papers found.</p>
      ) : (
        <div className="space-y-4">
          {filtered.map((p, i) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <Card className="border-border/60 hover:shadow-lg transition-all duration-200">
                <CardContent className="p-5">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <h3 className="text-lg font-bold text-foreground">{p.title}</h3>
                    <Badge variant="secondary" className="text-xs">{p.category}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-1">By {p.author_name}</p>
                  {p.abstract && (
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{p.abstract}</p>
                  )}
                  <div className="flex items-center justify-between mt-2">
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Calendar size={12} /> {format(new Date(p.published_date), "MMM d, yyyy")}
                    </span>
                    {p.link_url && (
                      <a
                        href={p.link_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-xs font-medium text-primary hover:underline"
                      >
                        View Paper <ExternalLink size={12} />
                      </a>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </motion.div>
  );
}
