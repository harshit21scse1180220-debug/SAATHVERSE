import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useFormOptions } from "@/hooks/useFormOptions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { mapErrorMessage } from "@/lib/errorMessages";
import { cn } from "@/lib/utils";
import type { Tables } from "@/integrations/supabase/types";
import {
  Shield, Users, Image as ImageIcon, LayoutDashboard, Trophy,
  Trash2, Edit2, Plus, Search, Eye, EyeOff,
  GripVertical, ExternalLink, X, Mail, Settings2, BarChart3, Layers, Upload, Palette, ArrowLeft, Activity, Server, Building2
} from "lucide-react";
import AdminSystemHealth from "@/components/AdminSystemHealth";
import AdminServerStatus from "@/components/AdminServerStatus";
import AdminCollegesManager from "@/components/AdminCollegesManager";
import CollegeSwitcher from "@/components/CollegeSwitcher";
import { useContentSections } from "@/hooks/useContentSections";
import { useImageUpload } from "@/components/ImageCropper";
import { motion } from "framer-motion";

type Profile = Tables<"profiles">;
type Slide = {
  id: string;
  title: string;
  description: string | null;
  hyperlink: string | null;
  hyperlink_text: string | null;
  media_url: string | null;
  category: string;
  is_active: boolean;
  display_order: number;
  created_by: string;
  branch: string | null;
};

const CATEGORIES = [
  { value: "hackathon", label: "Hackathon" },
  { value: "result", label: "Results" },
  { value: "event", label: "Event" },
  { value: "update", label: "Update" },
  { value: "banner", label: "Banner (Full Image)" },
];

// SECTION_TARGETS is now loaded dynamically via useContentSections hook

const COLOR_THEMES = [
  { value: "default", label: "Default (Navy)", primary: "222.2 47.4% 11.2%", accent: "210 40% 96.1%" },
  { value: "dark", label: "Dark & Grey", primary: "0 0% 9%", accent: "0 0% 14.9%" },
  { value: "ocean", label: "Ocean Blue", primary: "221 83% 53%", accent: "214 95% 93%" },
  { value: "emerald", label: "Emerald Green", primary: "142 76% 36%", accent: "138 76% 94%" },
  { value: "sunset", label: "Sunset Orange", primary: "25 95% 53%", accent: "33 100% 96%" },
  { value: "royal", label: "Royal Purple", primary: "262 83% 58%", accent: "270 95% 95%" },
  { value: "rose", label: "Rose Pink", primary: "346 77% 50%", accent: "350 100% 96%" },
];

export default function AdminDashboard() {
  const { user, isAdmin, isSuperAdmin } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-muted-foreground">
        <Shield size={48} className="mb-4 opacity-20" />
        <p className="text-lg font-semibold">Access Denied</p>
        <p className="text-sm mt-1">You need admin privileges to access this page.</p>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <div className="mb-8">
        <div className="flex items-center justify-between flex-wrap gap-3 mb-1">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl gradient-navy flex items-center justify-center shadow-md">
              <Shield size={20} className="text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-extrabold text-foreground tracking-tight">Admin Dashboard</h1>
              <p className="text-sm text-muted-foreground">Manage profiles, carousel & more</p>
            </div>
          </div>
          <CollegeSwitcher />
        </div>
      </div>

      <div className="flex items-center gap-2 mb-6 flex-wrap">
        <Button variant="outline" size="sm" onClick={() => navigate("/admin/form-options")} className="gap-1.5">
          <Settings2 size={14} /> Manage Form Options
        </Button>
        <Button variant="outline" size="sm" onClick={() => navigate("/admin/analytics")} className="gap-1.5">
          <BarChart3 size={14} /> Analytics & Export
        </Button>
        <Button variant="outline" size="sm" onClick={() => navigate("/admin/hackathons")} className="gap-1.5">
          <Trophy size={14} /> Manage Hackathons
        </Button>
        <Button variant="outline" size="sm" onClick={() => navigate("/admin/ieee")} className="gap-1.5">
          <Layers size={14} /> Manage Conferences
        </Button>
        <Button variant="outline" size="sm" onClick={() => navigate("/admin/content-carousel")} className="gap-1.5">
          <Layers size={14} /> Content Carousel
        </Button>
      </div>

      <Tabs defaultValue="profiles" className="space-y-6">
        <TabsList className="bg-card border border-border/60 p-1 h-auto flex-wrap">
          <TabsTrigger value="profiles" className="gap-2 data-[state=active]:shadow-sm">
            <Users size={14} /> Profiles
          </TabsTrigger>
          <TabsTrigger value="carousel" className="gap-2 data-[state=active]:shadow-sm">
            <ImageIcon size={14} /> Carousel
          </TabsTrigger>
          <TabsTrigger value="settings" className="gap-2 data-[state=active]:shadow-sm">
            <Settings2 size={14} /> Settings
          </TabsTrigger>
          <TabsTrigger value="overview" className="gap-2 data-[state=active]:shadow-sm">
            <LayoutDashboard size={14} /> Overview
          </TabsTrigger>
          <TabsTrigger value="health" className="gap-2 data-[state=active]:shadow-sm">
            <Activity size={14} /> System Health
          </TabsTrigger>
          <TabsTrigger value="server" className="gap-2 data-[state=active]:shadow-sm">
            <Server size={14} /> Server Status
          </TabsTrigger>
          {isSuperAdmin && (
            <TabsTrigger value="colleges" className="gap-2 data-[state=active]:shadow-sm">
              <Building2 size={14} /> Colleges
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="profiles">
          <ProfilesManager />
        </TabsContent>
        <TabsContent value="carousel">
          <CarouselManager />
        </TabsContent>
        <TabsContent value="settings">
          <SiteSettingsPanel />
        </TabsContent>
        <TabsContent value="overview">
          <OverviewPanel />
        </TabsContent>
        <TabsContent value="health">
          <AdminSystemHealth />
        </TabsContent>
        <TabsContent value="server">
          <AdminServerStatus />
        </TabsContent>
        <TabsContent value="colleges">
          <AdminCollegesManager />
        </TabsContent>
      </Tabs>
    </motion.div>
  );
}

/* ─────────── PROFILES MANAGER ─────────── */
function ProfilesManager() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const { activeCollegeId: collegeId } = useAuth();
  const { options: branchOptions } = useFormOptions("branch");
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [emailMap, setEmailMap] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<Profile | null>(null);
  const [editForm, setEditForm] = useState({
    bio: "", skills: "", full_name: "", branch: "", year_of_study: "",
    gender: "", is_alumni: false, company_name: "", tech_or_non_tech: "",
    year_of_passout: "", sub_branch: "",
  });
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);

  // Filters
  const [filterBranch, setFilterBranch] = useState("all");
  const [filterYear, setFilterYear] = useState("all");
  const [filterGender, setFilterGender] = useState("all");
  const [filterAlumni, setFilterAlumni] = useState("all");
  const [showFilters, setShowFilters] = useState(false);

  // Branch CTA view
  const [selectedBranch, setSelectedBranch] = useState<string | null>(null);

  const fetchEmails = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;
      const res = await supabase.functions.invoke("admin-users", {
        headers: { Authorization: `Bearer ${session.access_token}` },
      });
      if (res.data?.emailMap) setEmailMap(res.data.emailMap);
    } catch {}
  };

  const fetchProfiles = async () => {
    setLoading(true);
    let query = supabase.from("profiles").select("*").order("created_at", { ascending: false });
    if (collegeId) {
      query = query.eq("college_id", collegeId);
    }
    if (search.trim()) {
      query = query.ilike("full_name", `%${search.trim()}%`);
    }
    const activeBranch = selectedBranch || (filterBranch !== "all" ? filterBranch : null);
    if (activeBranch) {
      query = query.eq("branch", activeBranch);
    }
    if (filterYear !== "all") {
      query = query.eq("year_of_study", parseInt(filterYear));
    }
    if (filterGender !== "all") {
      query = query.eq("gender", filterGender);
    }
    if (filterAlumni === "yes") {
      query = query.eq("is_alumni", true);
    } else if (filterAlumni === "no") {
      query = query.eq("is_alumni", false);
    }
    const { data } = await query;
    setProfiles(data || []);
    setLoading(false);
  };

  useEffect(() => { fetchEmails(); }, []);

  useEffect(() => {
    const timer = setTimeout(fetchProfiles, 300);
    return () => clearTimeout(timer);
  }, [search, filterBranch, filterYear, filterGender, filterAlumni, selectedBranch, collegeId]);

  const activeFilterCount = [filterBranch, filterYear, filterGender, filterAlumni].filter(f => f !== "all").length;

  const clearFilters = () => {
    setFilterBranch("all");
    setFilterYear("all");
    setFilterGender("all");
    setFilterAlumni("all");
  };

  const startEdit = (p: Profile) => {
    setEditing(p);
    setEditForm({
      bio: p.bio || "",
      skills: (p.skills || []).join(", "),
      full_name: p.full_name,
      branch: p.branch,
      year_of_study: String(p.year_of_study),
      gender: p.gender,
      is_alumni: p.is_alumni,
      company_name: p.company_name || "",
      tech_or_non_tech: p.tech_or_non_tech || "",
      year_of_passout: p.year_of_passout ? String(p.year_of_passout) : "",
      sub_branch: p.sub_branch || "",
    });
  };

  const saveEdit = async () => {
    if (!editing) return;
    const { error } = await supabase
      .from("profiles")
      .update({
        full_name: editForm.full_name.trim(),
        branch: editForm.branch,
        year_of_study: parseInt(editForm.year_of_study) || 0,
        gender: editForm.gender,
        is_alumni: editForm.is_alumni,
        company_name: editForm.company_name.trim() || null,
        tech_or_non_tech: editForm.tech_or_non_tech.trim() || null,
        year_of_passout: editForm.year_of_passout ? parseInt(editForm.year_of_passout) : null,
        sub_branch: editForm.sub_branch.trim() || null,
        bio: editForm.bio.trim() || null,
        skills: editForm.skills.split(",").map(s => s.trim()).filter(Boolean),
      })
      .eq("id", editing.id);

    if (error) {
      toast({ title: "Error", description: mapErrorMessage(error), variant: "destructive" });
    } else {
      toast({ title: "Profile updated" });
      setEditing(null);
      fetchProfiles();
    }
  };

  const deleteProfile = async (id: string, name: string) => {
    if (!confirm(`Delete profile for "${name}"? This cannot be undone.`)) return;

    // Find the user_id for this profile to clean up related data
    const targetProfile = profiles.find((p) => p.id === id);
    if (!targetProfile) return;
    const userId = targetProfile.user_id;

    try {
      // Clean up related data before deleting the profile
      await Promise.all([
        supabase.from("messages").delete().or(`sender_id.eq.${userId},receiver_id.eq.${userId}`),
        supabase.from("collaboration_requests").delete().or(`sender_id.eq.${userId},receiver_id.eq.${userId}`),
        supabase.from("student_affiliations").delete().eq("profile_id", id),
        supabase.from("branch_featured_students").delete().eq("profile_id", id),
        supabase.from("team_invites").delete().or(`invited_by.eq.${userId},invited_user_id.eq.${userId}`),
        supabase.from("team_join_requests").delete().eq("user_id", userId),
        supabase.from("startup_join_requests").delete().eq("user_id", userId),
        supabase.from("event_logs").delete().eq("user_id", userId),
      ]);

      // Delete hackathon teams created by this user
      await supabase.from("hackathon_teams").delete().eq("creator_id", userId);

      // Delete startup ideas created by this user
      await supabase.from("startup_ideas").delete().eq("creator_id", userId);

      // Finally delete the profile
      const { error } = await supabase.from("profiles").delete().eq("id", id);
      if (error) throw error;

      toast({ title: "Profile deleted" });
      fetchProfiles();
    } catch (error: any) {
      toast({ title: "Error", description: mapErrorMessage(error), variant: "destructive" });
    }
  };

  return (
    <div>
      {/* Branch CTAs */}
      {!selectedBranch && (
        <div className="mb-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-4">
            <button
              onClick={() => setSelectedBranch(null)}
              className="p-3 bg-primary text-primary-foreground rounded-xl text-sm font-semibold text-center shadow-sm"
            >
              All Profiles
            </button>
            {branchOptions.map(b => (
              <button
                key={b}
                onClick={() => navigate(`/branch/${encodeURIComponent(b)}`)}
                className="p-3 bg-card border border-border/60 rounded-xl text-sm font-medium text-foreground hover:border-primary/40 transition-colors text-center truncate"
              >
                {b}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Back button when viewing a branch */}
      {selectedBranch && (
        <Button variant="ghost" size="sm" onClick={() => setSelectedBranch(null)} className="mb-3 gap-1.5">
          <ArrowLeft size={14} /> Back to all branches
        </Button>
      )}

      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-foreground">{selectedBranch || "All Profiles"}</h2>
        <Badge variant="secondary" className="text-xs">{profiles.length} total</Badge>
      </div>

      {/* Search + Filter Toggle */}
      <div className="flex items-center gap-2 mb-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search by name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Button
          variant={showFilters ? "default" : "outline"}
          size="sm"
          onClick={() => setShowFilters(!showFilters)}
          className="gap-1.5 shrink-0"
        >
          <Settings2 size={14} />
          Filters
          {activeFilterCount > 0 && (
            <Badge variant="secondary" className="ml-1 h-5 w-5 p-0 flex items-center justify-center text-[10px]">
              {activeFilterCount}
            </Badge>
          )}
        </Button>
      </div>

      {/* Filter Panel */}
      {showFilters && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          className="bg-card border border-border/60 rounded-xl p-4 mb-4 space-y-3"
        >
          <div className="flex items-center justify-between">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Filter Profiles</p>
            {activeFilterCount > 0 && (
              <Button variant="ghost" size="sm" className="h-6 text-xs text-muted-foreground" onClick={clearFilters}>
                Clear all
              </Button>
            )}
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {!selectedBranch && (
              <div className="space-y-1">
                <Label className="text-xs">Branch</Label>
                <Select value={filterBranch} onValueChange={setFilterBranch}>
                  <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent side="bottom">
                    <SelectItem value="all">All Branches</SelectItem>
                    {branchOptions.map(b => (
                      <SelectItem key={b} value={b}>{b}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="space-y-1">
              <Label className="text-xs">Year</Label>
              <Select value={filterYear} onValueChange={setFilterYear}>
                <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent side="bottom">
                  <SelectItem value="all">All Years</SelectItem>
                  <SelectItem value="1">Year 1</SelectItem>
                  <SelectItem value="2">Year 2</SelectItem>
                  <SelectItem value="3">Year 3</SelectItem>
                  <SelectItem value="4">Year 4</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Gender</Label>
              <Select value={filterGender} onValueChange={setFilterGender}>
                <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent side="bottom">
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Female">Female</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Alumni</Label>
              <Select value={filterAlumni} onValueChange={setFilterAlumni}>
                <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent side="bottom">
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="yes">Alumni Only</SelectItem>
                  <SelectItem value="no">Students Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </motion.div>
      )}

      {/* Photo preview modal */}
      {photoPreview && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={() => setPhotoPreview(null)}>
          <img src={photoPreview} alt="Profile" className="max-w-[90vw] max-h-[80vh] rounded-2xl object-contain shadow-2xl" />
        </div>
      )}

      {/* Edit modal */}
      {editing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-lg p-6 space-y-4 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-foreground">Edit: {editing.full_name}</h3>
              <button onClick={() => setEditing(null)} className="text-muted-foreground hover:text-foreground">
                <X size={18} />
              </button>
            </div>

            {/* Photo preview */}
            {editing.photo_url && (
              <div className="flex justify-center">
                <img
                  src={editing.photo_url}
                  alt={editing.full_name}
                  className="w-20 h-20 rounded-full object-cover cursor-pointer border-2 border-border hover:border-primary transition-colors"
                  onClick={() => setPhotoPreview(editing.photo_url)}
                />
              </div>
            )}

            <p className="text-xs text-muted-foreground"><span className="font-medium text-foreground">Email:</span> {emailMap[editing.user_id] || "N/A"}</p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Full Name</Label>
                <Input value={editForm.full_name} onChange={(e) => setEditForm(f => ({ ...f, full_name: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Branch</Label>
                <Select value={editForm.branch} onValueChange={(v) => setEditForm(f => ({ ...f, branch: v }))}>
                  <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent side="bottom">
                    {branchOptions.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Year</Label>
                <Select value={editForm.year_of_study} onValueChange={(v) => setEditForm(f => ({ ...f, year_of_study: v }))}>
                  <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent side="bottom">
                    {["1","2","3","4","5"].map(y => <SelectItem key={y} value={y}>Year {y}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Gender</Label>
                <Select value={editForm.gender} onValueChange={(v) => setEditForm(f => ({ ...f, gender: v }))}>
                  <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent side="bottom">
                    <SelectItem value="Male">Male</SelectItem>
                    <SelectItem value="Female">Female</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Label className="text-xs">Alumni</Label>
              <Switch checked={editForm.is_alumni} onCheckedChange={(v) => setEditForm(f => ({ ...f, is_alumni: v }))} />
            </div>

            {editForm.is_alumni && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs">Company</Label>
                  <Input value={editForm.company_name} onChange={(e) => setEditForm(f => ({ ...f, company_name: e.target.value }))} />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Domain</Label>
                  <Select value={editForm.tech_or_non_tech || "Tech"} onValueChange={(v) => setEditForm(f => ({ ...f, tech_or_non_tech: v }))}>
                    <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent side="bottom">
                      <SelectItem value="Tech">Tech</SelectItem>
                      <SelectItem value="Non-Tech">Non-Tech</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Year of Passout</Label>
                  <Input value={editForm.year_of_passout} onChange={(e) => setEditForm(f => ({ ...f, year_of_passout: e.target.value }))} type="number" />
                </div>
              </div>
            )}

            <div className="space-y-1.5">
              <Label className="text-xs">Bio</Label>
              <Textarea
                value={editForm.bio}
                onChange={(e) => setEditForm(f => ({ ...f, bio: e.target.value }))}
                rows={3}
                maxLength={500}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Skills (comma separated)</Label>
              <Input
                value={editForm.skills}
                onChange={(e) => setEditForm(f => ({ ...f, skills: e.target.value }))}
                maxLength={300}
              />
            </div>
            <div className="flex gap-2 pt-2">
              <Button onClick={saveEdit} size="sm">Save Changes</Button>
              <Button variant="outline" size="sm" onClick={() => setEditing(null)}>Cancel</Button>
            </div>
          </motion.div>
        </div>
      )}

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => <div key={i} className="h-16 bg-muted/50 rounded-xl animate-pulse" />)}
        </div>
      ) : profiles.length === 0 ? (
        <p className="text-center py-12 text-muted-foreground">No profiles found</p>
      ) : (
        <div className="space-y-2">
          {profiles.map((p) => (
            <div key={p.id} className="flex items-center gap-3 p-3 bg-card rounded-xl border border-border/60 hover:border-border transition-colors">
              <div
                className="w-10 h-10 rounded-full bg-muted flex items-center justify-center shrink-0 overflow-hidden cursor-pointer"
                onClick={() => p.photo_url ? setPhotoPreview(p.photo_url) : null}
              >
                {p.photo_url && p.show_photo ? (
                  <img src={p.photo_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-sm font-bold text-muted-foreground">{p.full_name[0]}</span>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">{p.full_name}</p>
                {emailMap[p.user_id] && (
                  <p className="text-xs text-primary/80 truncate flex items-center gap-1">
                    <Mail size={10} /> {emailMap[p.user_id]}
                  </p>
                )}
                <p className="text-xs text-muted-foreground truncate">
                  {p.branch} · {p.year_of_study === 0 ? "N/A" : `Year ${p.year_of_study}`} · {p.gender}
                  {p.is_alumni && <Badge variant="outline" className="ml-2 text-[10px]">Alumni</Badge>}
                </p>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => startEdit(p)}>
                  <Edit2 size={14} />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-destructive hover:text-destructive"
                  onClick={() => deleteProfile(p.id, p.full_name)}
                >
                  <Trash2 size={14} />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ─────────── CAROUSEL MANAGER ─────────── */
function CarouselManager() {
  const { user, activeCollegeId: collegeId } = useAuth();
  const { toast } = useToast();
  const { options: BRANCHES } = useFormOptions("branch");
  const { sectionTargets } = useContentSections();
  const [slides, setSlides] = useState<Slide[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [branchFilter, setBranchFilter] = useState<string>("all");
  const [sortOrder, setSortOrder] = useState<string>("newest");

  // New / Edit form
  const [showForm, setShowForm] = useState(false);
  const [editingSlide, setEditingSlide] = useState<Slide | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [hyperlink, setHyperlink] = useState("");
  const [hyperlinkText, setHyperlinkText] = useState("");
  const [category, setCategory] = useState("update");
  const [slideBranch, setSlideBranch] = useState<string>("none");
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const carouselCrop = useImageUpload(category === "banner" ? "banner" : "carousel", (f) => setMediaFile(f));

  const fetchSlides = async () => {
    let query = supabase
      .from("carousel_slides")
      .select("*");

    if (collegeId) {
      query = query.eq("college_id", collegeId);
    }

    if (sortOrder === "newest") {
      query = query.order("created_at", { ascending: false });
    } else if (sortOrder === "oldest") {
      query = query.order("created_at", { ascending: true });
    } else {
      query = query.order("display_order", { ascending: true });
    }

    if (branchFilter === "main") {
      query = query.is("branch", null);
    } else if (branchFilter !== "all") {
      query = query.eq("branch", branchFilter);
    }
    const { data } = await query;
    if (data) setSlides(data as Slide[]);
    setLoading(false);
  };

  useEffect(() => { fetchSlides(); }, [branchFilter, sortOrder, collegeId]);

  const resetForm = () => {
    setTitle(""); setDescription(""); setHyperlink(""); setHyperlinkText(""); setCategory("update");
    setSlideBranch("none"); setMediaFile(null); setEditingSlide(null); setShowForm(false);
  };

  const startEditSlide = (s: Slide) => {
    setTitle(s.title);
    setDescription(s.description || "");
    setHyperlink(s.hyperlink || "");
    setHyperlinkText(s.hyperlink_text || "");
    setCategory(s.category);
    setSlideBranch(s.branch || "none");
    setEditingSlide(s);
    setShowForm(true);
  };

  const uploadMedia = async (file: File): Promise<string | null> => {
    const ext = file.name.split(".").pop();
    const path = `${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from("carousel-media").upload(path, file);
    if (error) {
      toast({ title: "Upload failed", description: mapErrorMessage(error), variant: "destructive" });
      return null;
    }
    const { data } = supabase.storage.from("carousel-media").getPublicUrl(path);
    return data.publicUrl;
  };

  const handleSave = async () => {
    if (!title.trim() || !user) return;
    setSubmitting(true);

    let media_url: string | null = editingSlide?.media_url ?? null;
    if (mediaFile) {
      media_url = await uploadMedia(mediaFile);
      if (!media_url) { setSubmitting(false); return; }
    }

    const branchValue = slideBranch === "none" ? null : slideBranch;

    if (editingSlide) {
      const { error } = await supabase.from("carousel_slides").update({
        title: title.trim(),
        description: description.trim() || null,
        hyperlink: hyperlink.trim() || null,
        hyperlink_text: hyperlinkText.trim() || null,
        media_url,
        category,
        branch: branchValue,
      }).eq("id", editingSlide.id);

      if (error) {
        toast({ title: "Error", description: mapErrorMessage(error), variant: "destructive" });
      } else {
        toast({ title: "Slide updated" });
        resetForm();
        fetchSlides();
      }
    } else {
      const { error } = await supabase.from("carousel_slides").insert({
        title: title.trim(),
        description: description.trim() || null,
        hyperlink: hyperlink.trim() || null,
        hyperlink_text: hyperlinkText.trim() || null,
        media_url,
        category,
        branch: branchValue,
        display_order: slides.length,
        created_by: user.id,
        college_id: collegeId,
      });

      if (error) {
        toast({ title: "Error", description: mapErrorMessage(error), variant: "destructive" });
      } else {
        toast({ title: "Slide added" });
        resetForm();
        fetchSlides();
      }
    }
    setSubmitting(false);
  };

  const toggleActive = async (slide: Slide) => {
    await supabase.from("carousel_slides").update({ is_active: !slide.is_active }).eq("id", slide.id);
    fetchSlides();
  };

  const deleteSlide = async (id: string, media_url: string | null) => {
    if (!confirm("Delete this slide?")) return;
    if (media_url) {
      const path = media_url.split("/carousel-media/")[1];
      if (path) await supabase.storage.from("carousel-media").remove([path]);
    }
    await supabase.from("carousel_slides").delete().eq("id", id);
    fetchSlides();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-foreground">Carousel Slides</h2>
        <Button size="sm" onClick={() => { resetForm(); setShowForm(true); }}>
          <Plus size={14} className="mr-1" /> Add Slide
        </Button>
      </div>

      {/* Filters row */}
      <div className="flex flex-wrap gap-3 mb-4">
        <div className="max-w-xs">
          <Select value={sortOrder} onValueChange={setSortOrder}>
            <SelectTrigger className="h-9 text-sm">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent side="bottom">
              <SelectItem value="newest">Newest First</SelectItem>
              <SelectItem value="oldest">Oldest First</SelectItem>
              <SelectItem value="order">By Display Order</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="max-w-xs">
          <Select value={branchFilter} onValueChange={setBranchFilter}>
            <SelectTrigger className="h-9 text-sm">
              <SelectValue placeholder="Filter by target" />
            </SelectTrigger>
            <SelectContent side="bottom">
              <SelectItem value="all">All Slides</SelectItem>
              <SelectItem value="main">Main Page Only</SelectItem>
              {sectionTargets.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
              {BRANCHES.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Form modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-lg p-6 space-y-4 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-foreground">
                {editingSlide ? "Edit Slide" : "New Slide"}
              </h3>
              <button onClick={resetForm} className="text-muted-foreground hover:text-foreground">
                <X size={18} />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Title *</Label>
                <Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} />
              </div>
              <div className="space-y-1.5">
                <Label>Category</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent side="bottom">
                    {CATEGORIES.map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Target</Label>
              <Select value={slideBranch} onValueChange={setSlideBranch}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent side="bottom">
                  <SelectItem value="none">Main Page</SelectItem>
                  {sectionTargets.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                  {BRANCHES.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label>Description</Label>
              <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} maxLength={500} />
            </div>

            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5">
                <ExternalLink size={12} /> Hyperlink
              </Label>
              <Input value={hyperlink} onChange={(e) => setHyperlink(e.target.value)} placeholder="https://..." maxLength={500} />
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs">Link Text</Label>
              <Input value={hyperlinkText} onChange={(e) => setHyperlinkText(e.target.value)} placeholder="e.g. Click here, Register now (default: Learn more)" maxLength={100} />
            </div>

            <div className="space-y-1.5">
              <Label>Media</Label>
              <p className="text-[11px] text-muted-foreground">
                {category === "banner"
                  ? "Recommended: 1600×600 px · Cropped to 16:6"
                  : "Recommended: 800×600 px · Cropped to 4:3"}
              </p>
              {editingSlide?.media_url && !mediaFile && (
                <img src={editingSlide.media_url} alt="" className={cn("w-full rounded-xl object-cover mb-2", category === "banner" ? "aspect-[16/6]" : "aspect-[4/3]")} />
              )}
              <button type="button" onClick={carouselCrop.triggerUpload} className="flex items-center gap-2 cursor-pointer text-sm text-muted-foreground border border-dashed border-border rounded-xl px-4 py-3 hover:bg-muted/50 transition-colors w-full">
                <ImageIcon size={16} />
                {mediaFile ? mediaFile.name : "Upload & crop image"}
              </button>
              <carouselCrop.CropperModal />
            </div>

            <div className="flex gap-2 pt-2">
              <Button onClick={handleSave} disabled={submitting || !title.trim()} size="sm">
                {submitting ? "Saving..." : editingSlide ? "Update Slide" : "Add Slide"}
              </Button>
              <Button variant="outline" size="sm" onClick={resetForm}>Cancel</Button>
            </div>
          </motion.div>
        </div>
      )}

      {loading ? (
        <div className="space-y-3">
          {[1, 2].map(i => <div key={i} className="h-20 bg-muted/50 rounded-xl animate-pulse" />)}
        </div>
      ) : slides.length === 0 ? (
        <p className="text-center text-muted-foreground py-12">No slides yet. Add your first one!</p>
      ) : (
        <div className="space-y-2">
          {slides.map((slide) => (
            <div key={slide.id} className="flex items-center gap-3 p-3 bg-card rounded-xl border border-border/60 hover:border-border transition-colors">
              <GripVertical size={16} className="text-muted-foreground/40 shrink-0" />
              {slide.media_url ? (
                <img src={slide.media_url} alt="" className="w-16 h-12 rounded-lg object-cover shrink-0" />
              ) : (
                <div className="w-16 h-12 rounded-lg bg-muted/50 flex items-center justify-center shrink-0">
                  <ImageIcon size={16} className="text-muted-foreground/40" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">{slide.title}</p>
                <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                  <Badge variant="outline" className="text-[10px] capitalize">{slide.category}</Badge>
                  <Badge variant="secondary" className="text-[10px]">{slide.branch || "Main Page"}</Badge>
                  {slide.hyperlink && (
                    <a href={slide.hyperlink} target="_blank" rel="noreferrer" className="text-[10px] text-primary hover:underline flex items-center gap-0.5">
                      <ExternalLink size={8} /> Link
                    </a>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button onClick={() => toggleActive(slide)} className="text-muted-foreground hover:text-foreground" title={slide.is_active ? "Active" : "Inactive"}>
                  {slide.is_active ? <Eye size={16} /> : <EyeOff size={16} className="opacity-50" />}
                </button>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => startEditSlide(slide)}>
                  <Edit2 size={14} />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => deleteSlide(slide.id, slide.media_url)}>
                  <Trash2 size={14} />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ─────────── SITE SETTINGS PANEL ─────────── */
function SiteSettingsPanel() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [currentLogoUrl, setCurrentLogoUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const logoCrop = useImageUpload("profile", (f) => setLogoFile(f));

  // Secondary carousel config
  const [scEnabled, setScEnabled] = useState(false);
  const [scPosition, setScPosition] = useState("middle");
  const [scSaving, setScSaving] = useState(false);
  const [scShowAddSlide, setScShowAddSlide] = useState(false);
  const [scSlides, setScSlides] = useState<Slide[]>([]);

  // Color theme
  const [colorTheme, setColorTheme] = useState("default");
  const [savingTheme, setSavingTheme] = useState(false);

  // Image upload limit
  const [maxUploadSizeKB, setMaxUploadSizeKB] = useState(200);
  const [savingUploadLimit, setSavingUploadLimit] = useState(false);

  // Slide form for secondary carousel
  const [scTitle, setScTitle] = useState("");
  const [scDesc, setScDesc] = useState("");
  const [scHyperlink, setScHyperlink] = useState("");
  const [scCategory, setScCategory] = useState("update");
  const [scMediaFile, setScMediaFile] = useState<File | null>(null);
  const [scSubmitting, setScSubmitting] = useState(false);
  const scCrop = useImageUpload(scCategory === "banner" ? "banner" : "carousel", (f) => setScMediaFile(f));

  const fetchSecondarySlides = async () => {
    const { data } = await supabase.from("carousel_slides").select("*").eq("branch", "secondary").order("display_order");
    if (data) setScSlides(data as Slide[]);
  };

  useEffect(() => {
    Promise.all([
      supabase.from("site_settings").select("value").eq("key", "logo_url").maybeSingle(),
      supabase.from("site_settings").select("value").eq("key", "secondary_carousel").maybeSingle(),
      supabase.from("site_settings").select("value").eq("key", "color_theme").maybeSingle(),
      supabase.from("site_settings").select("value").eq("key", "max_upload_size_kb").maybeSingle(),
    ]).then(([logoRes, scRes, themeRes, uploadRes]) => {
      if (logoRes.data?.value) setCurrentLogoUrl(logoRes.data.value);
      if (scRes.data?.value) {
        try {
          const cfg = JSON.parse(scRes.data.value);
          setScEnabled(!!cfg.enabled);
          setScPosition(cfg.position || "middle");
        } catch {}
      }
      if (themeRes.data?.value) setColorTheme(themeRes.data.value);
      if (uploadRes.data?.value) setMaxUploadSizeKB(parseInt(uploadRes.data.value, 10) || 200);
    });
    fetchSecondarySlides();
  }, []);

  const uploadLogo = async () => {
    if (!logoFile || !user) return;
    setUploading(true);
    try {
      const ext = logoFile.name.split(".").pop();
      const path = `logo/site-logo.${ext}`;
      await supabase.storage.from("carousel-media").remove([path]).catch(() => {});
      const { error: uploadError } = await supabase.storage.from("carousel-media").upload(path, logoFile, { upsert: true });
      if (uploadError) throw uploadError;
      const { data: urlData } = supabase.storage.from("carousel-media").getPublicUrl(path);
      const logoUrl = urlData.publicUrl + "?t=" + Date.now();

      const { error } = await supabase
        .from("site_settings")
        .upsert({ key: "logo_url", value: logoUrl, updated_at: new Date().toISOString() }, { onConflict: "key" });
      if (error) throw error;

      setCurrentLogoUrl(logoUrl);
      setLogoFile(null);
      toast({ title: "Logo updated!" });
    } catch (e: any) {
      toast({ title: "Upload failed", description: e?.message || "Error", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const saveSecondaryCarousel = async () => {
    setScSaving(true);
    try {
      const value = JSON.stringify({ enabled: scEnabled, position: scPosition });
      const { error } = await supabase
        .from("site_settings")
        .upsert({ key: "secondary_carousel", value, updated_at: new Date().toISOString() }, { onConflict: "key" });
      if (error) throw error;
      toast({ title: "Secondary carousel settings saved!" });
    } catch (e: any) {
      toast({ title: "Error", description: e?.message || "Error", variant: "destructive" });
    } finally {
      setScSaving(false);
    }
  };

  const saveColorTheme = async () => {
    setSavingTheme(true);
    try {
      const { error } = await supabase
        .from("site_settings")
        .upsert({ key: "color_theme", value: colorTheme, updated_at: new Date().toISOString() }, { onConflict: "key" });
      if (error) throw error;
      // Apply theme immediately
      applyTheme(colorTheme);
      toast({ title: "Color theme saved! Refresh for full effect." });
    } catch (e: any) {
      toast({ title: "Error", description: e?.message || "Error", variant: "destructive" });
    } finally {
      setSavingTheme(false);
    }
  };

  const applyTheme = (themeValue: string) => {
    const theme = COLOR_THEMES.find(t => t.value === themeValue);
    if (!theme) return;
    document.documentElement.style.setProperty("--primary", theme.primary);
    document.documentElement.style.setProperty("--accent", theme.accent);
  };

  const addSecondarySlide = async () => {
    if (!scTitle.trim() || !user) return;
    setScSubmitting(true);
    let media_url: string | null = null;
    if (scMediaFile) {
      const ext = scMediaFile.name.split(".").pop();
      const path = `${crypto.randomUUID()}.${ext}`;
      const { error } = await supabase.storage.from("carousel-media").upload(path, scMediaFile);
      if (error) { toast({ title: "Upload failed", variant: "destructive" }); setScSubmitting(false); return; }
      media_url = supabase.storage.from("carousel-media").getPublicUrl(path).data.publicUrl;
    }
    const { error } = await supabase.from("carousel_slides").insert({
      title: scTitle.trim(), description: scDesc.trim() || null, hyperlink: scHyperlink.trim() || null,
      media_url, category: scCategory, branch: "secondary", display_order: 0, created_by: user.id,
    });
    if (error) toast({ title: "Error", description: mapErrorMessage(error), variant: "destructive" });
    else { toast({ title: "Slide added!" }); setScTitle(""); setScDesc(""); setScHyperlink(""); setScCategory("update"); setScMediaFile(null); setScShowAddSlide(false); fetchSecondarySlides(); }
    setScSubmitting(false);
  };

  return (
    <div className="space-y-6">
      <h2 className="text-lg font-bold text-foreground">Site Settings</h2>

      {/* Logo Upload */}
      <div className="p-4 bg-card rounded-xl border border-border/60 space-y-4 max-w-md">
        <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <Upload size={14} /> App Logo
        </h3>
        <p className="text-[11px] text-muted-foreground">Recommended: 200×200 px (square, PNG with transparent background)</p>
        {currentLogoUrl && (
          <div className="flex items-center gap-3">
            <img src={currentLogoUrl} alt="Current logo" className="w-12 h-12 rounded-xl object-cover border border-border" />
            <span className="text-xs text-muted-foreground">Current logo</span>
          </div>
        )}
        <div>
          <button type="button" onClick={logoCrop.triggerUpload} className="flex items-center gap-2 cursor-pointer text-sm text-muted-foreground border border-dashed border-border rounded-lg px-4 py-3 hover:bg-muted/50 transition-colors w-full">
            <ImageIcon size={14} />
            {logoFile ? logoFile.name : "Choose & crop logo image..."}
          </button>
          <logoCrop.CropperModal />
        </div>
        <Button size="sm" onClick={uploadLogo} disabled={!logoFile || uploading}>
          {uploading ? "Uploading..." : "Upload Logo"}
        </Button>
      </div>

      {/* Image Upload Limit */}
      <div className="p-4 bg-card rounded-xl border border-border/60 space-y-4 max-w-md">
        <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <Upload size={14} /> Profile Image Upload Limit
        </h3>
        <p className="text-[11px] text-muted-foreground">
          Set the maximum file size for profile photo uploads (100 KB – 2048 KB). Default: 200 KB.
        </p>
        <div className="flex items-center gap-3">
          <Input
            type="number"
            min={100}
            max={2048}
            step={50}
            value={maxUploadSizeKB}
            onChange={(e) => setMaxUploadSizeKB(Math.min(2048, Math.max(100, Number(e.target.value))))}
            className="w-28 h-9 text-sm"
          />
          <span className="text-sm text-muted-foreground">KB</span>
          <span className="text-xs text-muted-foreground">({(maxUploadSizeKB / 1024).toFixed(1)} MB)</span>
        </div>
        <Button
          size="sm"
          disabled={savingUploadLimit}
          onClick={async () => {
            setSavingUploadLimit(true);
            try {
              const { error } = await supabase
                .from("site_settings")
                .upsert({ key: "max_upload_size_kb", value: String(maxUploadSizeKB), updated_at: new Date().toISOString() }, { onConflict: "key" });
              if (error) throw error;
              toast({ title: `Upload limit set to ${maxUploadSizeKB} KB` });
            } catch (e: any) {
              toast({ title: "Error", description: e?.message || "Error", variant: "destructive" });
            } finally {
              setSavingUploadLimit(false);
            }
          }}
        >
          {savingUploadLimit ? "Saving..." : "Save Limit"}
        </Button>
      </div>

      {/* Color Theme */}
      <div className="p-4 bg-card rounded-xl border border-border/60 space-y-4 max-w-md">
        <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <Palette size={14} /> Site Color Theme
        </h3>
        <p className="text-[11px] text-muted-foreground">Choose a color scheme for the entire site. Changes apply with smooth transitions.</p>
        <div className="grid grid-cols-2 gap-2">
          {COLOR_THEMES.map(t => (
            <button
              key={t.value}
              onClick={() => setColorTheme(t.value)}
              className={`p-3 rounded-lg border-2 transition-all text-left ${
                colorTheme === t.value
                  ? "border-primary bg-primary/5"
                  : "border-border/60 hover:border-border"
              }`}
            >
              <div className="flex items-center gap-2 mb-1">
                <div className="w-4 h-4 rounded-full" style={{ background: `hsl(${t.primary})` }} />
                <div className="w-4 h-4 rounded-full" style={{ background: `hsl(${t.accent})` }} />
              </div>
              <p className="text-xs font-medium text-foreground">{t.label}</p>
            </button>
          ))}
        </div>
        <Button size="sm" onClick={saveColorTheme} disabled={savingTheme}>
          {savingTheme ? "Saving..." : "Apply Theme"}
        </Button>
      </div>

      {/* Secondary Carousel Config */}
      <div className="p-4 bg-card rounded-xl border border-border/60 space-y-4 max-w-md">
        <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <ImageIcon size={14} /> Secondary Carousel
        </h3>
        <p className="text-xs text-muted-foreground">
          An additional carousel on the main page. It always appears below the default main carousel.
        </p>
        <div className="flex items-center gap-3">
          <Switch checked={scEnabled} onCheckedChange={setScEnabled} />
          <Label className="text-sm">{scEnabled ? "Enabled" : "Disabled"}</Label>
          <Button size="sm" variant="outline" className="ml-auto gap-1" onClick={() => setScShowAddSlide(!scShowAddSlide)}>
            <Plus size={12} /> Add Slide
          </Button>
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs">Position on page</Label>
          <Select value={scPosition} onValueChange={setScPosition}>
            <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent side="bottom">
              <SelectItem value="top">Top (below main carousel)</SelectItem>
              <SelectItem value="middle">Middle (after hero section)</SelectItem>
              <SelectItem value="bottom">Bottom (above footer)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button size="sm" onClick={saveSecondaryCarousel} disabled={scSaving}>
          {scSaving ? "Saving..." : "Save Settings"}
        </Button>
      </div>

      {/* Secondary Carousel Slides List */}
      {scSlides.length > 0 && (
        <div className="p-4 bg-card rounded-xl border border-border/60 space-y-3 max-w-md">
          <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Secondary Carousel Slides ({scSlides.length})</h4>
          <div className="space-y-2">
            {scSlides.map(slide => (
              <div key={slide.id} className="flex items-center gap-3 p-2.5 bg-background rounded-lg border border-border/40">
                {slide.media_url ? (
                  <img src={slide.media_url} alt="" className="w-14 h-10 rounded-lg object-cover shrink-0" />
                ) : (
                  <div className="w-14 h-10 rounded-lg bg-muted/50 flex items-center justify-center shrink-0">
                    <ImageIcon size={14} className="text-muted-foreground/40" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground truncate">{slide.title}</p>
                  <Badge variant="outline" className="text-[10px] capitalize">{slide.category}</Badge>
                </div>
                <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={async () => {
                  if (!confirm("Delete this slide?")) return;
                  await supabase.from("carousel_slides").delete().eq("id", slide.id);
                  fetchSecondarySlides();
                }}><Trash2 size={13} /></Button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add Slide for Secondary Carousel */}
      {scShowAddSlide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-lg p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-foreground">Add Slide (Secondary Carousel)</h3>
              <button onClick={() => setScShowAddSlide(false)} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
            </div>
            <div className="space-y-1.5">
              <Label>Title *</Label>
              <Input value={scTitle} onChange={e => setScTitle(e.target.value)} maxLength={200} />
            </div>
            <div className="space-y-1.5">
              <Label>Category</Label>
              <Select value={scCategory} onValueChange={setScCategory}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent side="bottom">
                  {CATEGORIES.map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-1.5">
              <Label>Description</Label>
              <Textarea value={scDesc} onChange={e => setScDesc(e.target.value)} rows={2} maxLength={500} />
            </div>
            <div className="space-y-1.5">
              <Label>Hyperlink</Label>
              <Input value={scHyperlink} onChange={e => setScHyperlink(e.target.value)} placeholder="https://..." />
            </div>
            <div className="space-y-1.5">
              <Label>Media</Label>
              <p className="text-[11px] text-muted-foreground">
                {scCategory === "banner" ? "Recommended: 1600×600 px · Cropped to 16:6" : "Recommended: 800×600 px · Cropped to 4:3"}
              </p>
              <button type="button" onClick={scCrop.triggerUpload} className="flex items-center gap-2 cursor-pointer text-sm text-muted-foreground border border-dashed border-border rounded-xl px-4 py-3 hover:bg-muted/50 transition-colors w-full">
                <ImageIcon size={16} />
                {scMediaFile ? scMediaFile.name : "Upload & crop image"}
              </button>
              <scCrop.CropperModal />
            </div>
            <div className="flex gap-2 pt-2">
              <Button onClick={addSecondarySlide} disabled={scSubmitting || !scTitle.trim()} size="sm">
                {scSubmitting ? "Saving..." : "Add Slide"}
              </Button>
              <Button variant="outline" size="sm" onClick={() => setScShowAddSlide(false)}>Cancel</Button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}

/* ─────────── OVERVIEW PANEL ─────────── */
function OverviewPanel() {
  const [stats, setStats] = useState({ profiles: 0, slides: 0, hackathons: 0 });
  const { activeCollegeId: collegeId } = useAuth();

  useEffect(() => {
    const pq = collegeId
      ? supabase.from("profiles").select("id", { count: "exact", head: true }).eq("college_id", collegeId)
      : supabase.from("profiles").select("id", { count: "exact", head: true });
    const sq = collegeId
      ? supabase.from("carousel_slides").select("id", { count: "exact", head: true }).eq("college_id", collegeId)
      : supabase.from("carousel_slides").select("id", { count: "exact", head: true });
    const hq = collegeId
      ? supabase.from("hackathons").select("id", { count: "exact", head: true }).eq("college_id", collegeId)
      : supabase.from("hackathons").select("id", { count: "exact", head: true });

    Promise.all([pq, sq, hq]).then(([p, s, h]) => {
      setStats({
        profiles: p.count || 0,
        slides: s.count || 0,
        hackathons: h.count || 0,
      });
    });
  }, [collegeId]);

  const cards = [
    { label: "Total Profiles", value: stats.profiles, icon: Users, color: "gradient-navy" },
    { label: "Carousel Slides", value: stats.slides, icon: ImageIcon, color: "gradient-saffron" },
    { label: "Hackathons", value: stats.hackathons, icon: Shield, color: "gradient-navy" },
  ];

  const nav = useNavigate();

  return (
    <div>
      <h2 className="text-lg font-bold text-foreground mb-4">Platform Overview</h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        {cards.map((c) => (
          <div key={c.label} className="p-5 bg-card rounded-xl border border-border/60 shadow-sm">
            <div className="flex items-center gap-3 mb-3">
              <div className={`w-9 h-9 rounded-lg ${c.color} flex items-center justify-center`}>
                <c.icon size={16} className="text-primary-foreground" />
              </div>
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{c.label}</span>
            </div>
            <p className="text-3xl font-extrabold text-foreground">{c.value}</p>
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <h3 className="text-sm font-bold text-foreground mb-3">Quick Actions</h3>
      <button
        onClick={() => nav("/admin/featured-students")}
        className="flex items-center gap-3 p-4 bg-card rounded-xl border border-border/60 hover:border-primary/40 transition-colors w-full text-left"
      >
        <div className="w-9 h-9 rounded-lg gradient-saffron flex items-center justify-center">
          <Trophy size={16} className="text-primary-foreground" />
        </div>
        <div>
          <p className="text-sm font-semibold text-foreground">Manage Featured Students</p>
          <p className="text-xs text-muted-foreground">Showcase top students per branch in carousels</p>
        </div>
      </button>
    </div>
  );
}
