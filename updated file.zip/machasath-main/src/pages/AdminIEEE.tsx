import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { mapErrorMessage } from "@/lib/errorMessages";
import { Plus, Edit2, Trash2, Loader2, Download, ArrowLeft } from "lucide-react";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { CATEGORIES } from "@/lib/categories";

interface Conference {
  id: string;
  title: string;
  organizer: string;
  description: string | null;
  category: string;
  mode: string;
  deadline_date: string;
  link_url: string | null;
  status: string;
  created_by: string;
  created_at: string;
}

interface Paper {
  id: string;
  title: string;
  author_name: string;
  category: string;
  abstract: string | null;
  link_url: string | null;
  published_date: string;
  created_by: string;
  created_at: string;
}

export default function AdminIEEE() {
  const { user, isAdmin, activeCollegeId: collegeId } = useAuth();

  if (!isAdmin) {
    return (
      <div className="text-center py-20 text-muted-foreground">
        <p className="font-medium">Access Denied</p>
      </div>
    );
  }

  const navigate = useNavigate();

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <div className="flex items-center gap-3 mb-1">
        <button onClick={() => navigate("/admin/dashboard")} className="p-2 rounded-full hover:bg-muted transition-colors">
          <ArrowLeft size={20} className="text-foreground" />
        </button>
        <h1 className="text-2xl font-bold text-foreground">IEEE Management</h1>
      </div>

      <Tabs defaultValue="conferences">
        <TabsList className="mb-4">
          <TabsTrigger value="conferences">Conferences</TabsTrigger>
          <TabsTrigger value="papers">Published Papers</TabsTrigger>
        </TabsList>
        <TabsContent value="conferences">
          <ConferencesTab userId={user!.id} collegeId={collegeId} />
        </TabsContent>
        <TabsContent value="papers">
          <PapersTab userId={user!.id} collegeId={collegeId} />
        </TabsContent>
      </Tabs>
    </motion.div>
  );
}

/* ─── Conferences Tab ─── */
function ConferencesTab({ userId, collegeId }: { userId: string; collegeId: string | null }) {
  const [items, setItems] = useState<Conference[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Conference | null>(null);
  const [saving, setSaving] = useState(false);
  const [fetching, setFetching] = useState(false);

  const [title, setTitle] = useState("");
  const [organizer, setOrganizer] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("Engineering");
  const [mode, setMode] = useState("Online");
  const [deadline, setDeadline] = useState("");
  const [linkUrl, setLinkUrl] = useState("");

  const fetchAll = async () => {
    let query = supabase
      .from("conferences")
      .select("*")
      .order("created_at", { ascending: false });
    if (collegeId) query = query.eq("college_id", collegeId);
    const { data } = await query;
    setItems(data || []);
    setLoading(false);
  };

  useEffect(() => { fetchAll(); }, []);

  const resetForm = () => {
    setTitle(""); setOrganizer(""); setDescription(""); setCategory("Engineering");
    setMode("Online"); setDeadline(""); setLinkUrl(""); setEditing(null); setShowForm(false);
  };

  const startEdit = (c: Conference) => {
    setTitle(c.title); setOrganizer(c.organizer); setDescription(c.description || "");
    setCategory(c.category); setMode(c.mode);
    setDeadline(c.deadline_date.split("T")[0]); setLinkUrl(c.link_url || "");
    setEditing(c); setShowForm(true);
  };

  const handleFetchDetails = async () => {
    if (!linkUrl.trim()) { toast.error("Paste a conference link first"); return; }
    setFetching(true);
    try {
      const { data, error } = await supabase.functions.invoke("fetch-conference-details", {
        body: { url: linkUrl.trim() },
      });
      if (error) throw error;
      if (data?.title) setTitle(data.title);
      if (data?.description) setDescription(data.description);
      if (data?.organizer) setOrganizer(data.organizer);
      if (data?.mode) setMode(data.mode);
      if (data?.deadline) setDeadline(data.deadline);
      toast.success("Details fetched! Review and save.");
    } catch {
      toast.error("Unable to fetch details. Please fill manually.");
    } finally {
      setFetching(false);
    }
  };

  const handleSave = async () => {
    if (!title.trim() || !organizer.trim() || !deadline) {
      toast.error("Please fill required fields"); return;
    }
    setSaving(true);
    try {
      const payload = {
        title: title.trim(), organizer: organizer.trim(), description: description.trim(),
        category, mode, deadline_date: new Date(deadline).toISOString(), link_url: linkUrl.trim() || null,
      };
      if (editing) {
        const { error } = await supabase.from("conferences").update(payload).eq("id", editing.id);
        if (error) throw error;
        toast.success("Conference updated!");
      } else {
        const { error } = await supabase.from("conferences").insert({ ...payload, created_by: userId, college_id: collegeId });
        if (error) throw error;
        toast.success("Conference created!");
      }
      resetForm(); fetchAll();
    } catch (e: unknown) { toast.error(mapErrorMessage(e)); }
    finally { setSaving(false); }
  };

  const handleDelete = async (c: Conference) => {
    if (!confirm(`Delete "${c.title}"?`)) return;
    try {
      const { error } = await supabase.from("conferences").delete().eq("id", c.id);
      if (error) throw error;
      toast.success("Deleted"); fetchAll();
    } catch (e: unknown) { toast.error(mapErrorMessage(e)); }
  };

  return (
    <>
      <div className="flex justify-end mb-4">
        <Button onClick={() => { resetForm(); setShowForm(true); }}>
          <Plus size={16} className="mr-1" /> New Conference
        </Button>
      </div>

      {showForm && (
        <Card className="border-border/60 mb-6">
          <CardHeader><CardTitle className="text-lg">{editing ? "Edit" : "Add"} Conference</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {/* Link + fetch */}
            <div className="space-y-2">
              <Label>Conference Link (URL)</Label>
              <div className="flex gap-2">
                <Input value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} placeholder="https://..." className="flex-1" />
                <Button variant="outline" onClick={handleFetchDetails} disabled={fetching}>
                  {fetching ? <Loader2 size={16} className="animate-spin mr-1" /> : <Download size={16} className="mr-1" />}
                  Fetch details
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Title *</Label>
                <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Conference title" maxLength={300} />
              </div>
              <div className="space-y-2">
                <Label>Organizer *</Label>
                <Input value={organizer} onChange={(e) => setOrganizer(e.target.value)} placeholder="Organizing body" maxLength={200} />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Category *</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Mode *</Label>
                <Select value={mode} onValueChange={setMode}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Online">Online</SelectItem>
                    <SelectItem value="Offline">Offline</SelectItem>
                    <SelectItem value="Hybrid">Hybrid</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Registration Deadline *</Label>
                <Input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Conference description..." maxLength={1000} rows={3} />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={saving}>{saving ? "Saving..." : editing ? "Update" : "Create"}</Button>
              <Button variant="outline" onClick={resetForm}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {loading ? (
        <div className="space-y-3">{[1, 2].map((i) => <div key={i} className="h-20 bg-muted rounded-lg animate-pulse" />)}</div>
      ) : items.length === 0 ? (
        <p className="text-center py-8 text-muted-foreground">No conferences yet</p>
      ) : (
        <div className="space-y-3">
          {items.map((c) => (
            <Card key={c.id} className="border-border/60">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold text-foreground">{c.title}</h3>
                      <Badge variant="secondary" className="text-xs">{c.category}</Badge>
                      <Badge variant={new Date(c.deadline_date) >= new Date() ? "default" : "outline"} className="text-xs">
                        {new Date(c.deadline_date) >= new Date() ? "Upcoming" : "Closed"}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {c.organizer} · {c.mode} · Deadline: {format(new Date(c.deadline_date), "MMM d, yyyy")}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" onClick={() => startEdit(c)}><Edit2 size={14} /></Button>
                    <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => handleDelete(c)}><Trash2 size={14} /></Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </>
  );
}

/* ─── Papers Tab ─── */
function PapersTab({ userId, collegeId }: { userId: string; collegeId: string | null }) {
  const [items, setItems] = useState<Paper[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Paper | null>(null);
  const [saving, setSaving] = useState(false);

  const [title, setTitle] = useState("");
  const [authorName, setAuthorName] = useState("");
  const [category, setCategory] = useState("Engineering");
  const [abstract_, setAbstract] = useState("");
  const [linkUrl, setLinkUrl] = useState("");
  const [publishedDate, setPublishedDate] = useState("");

  const fetchAll = async () => {
    let query = supabase
      .from("published_papers")
      .select("*")
      .order("created_at", { ascending: false });
    if (collegeId) query = query.eq("college_id", collegeId);
    const { data } = await query;
    setItems(data || []);
    setLoading(false);
  };

  useEffect(() => { fetchAll(); }, []);

  const resetForm = () => {
    setTitle(""); setAuthorName(""); setCategory("Engineering");
    setAbstract(""); setLinkUrl(""); setPublishedDate(""); setEditing(null); setShowForm(false);
  };

  const startEdit = (p: Paper) => {
    setTitle(p.title); setAuthorName(p.author_name); setCategory(p.category);
    setAbstract(p.abstract || ""); setLinkUrl(p.link_url || "");
    setPublishedDate(p.published_date); setEditing(p); setShowForm(true);
  };

  const handleSave = async () => {
    if (!title.trim() || !authorName.trim() || !publishedDate) {
      toast.error("Please fill required fields"); return;
    }
    setSaving(true);
    try {
      const payload = {
        title: title.trim(), author_name: authorName.trim(), category,
        abstract: abstract_.trim() || null, link_url: linkUrl.trim() || null,
        published_date: publishedDate,
      };
      if (editing) {
        const { error } = await supabase.from("published_papers").update(payload).eq("id", editing.id);
        if (error) throw error;
        toast.success("Paper updated!");
      } else {
        const { error } = await supabase.from("published_papers").insert({ ...payload, created_by: userId, college_id: collegeId });
        if (error) throw error;
        toast.success("Paper added!");
      }
      resetForm(); fetchAll();
    } catch (e: unknown) { toast.error(mapErrorMessage(e)); }
    finally { setSaving(false); }
  };

  const handleDelete = async (p: Paper) => {
    if (!confirm(`Delete "${p.title}"?`)) return;
    try {
      const { error } = await supabase.from("published_papers").delete().eq("id", p.id);
      if (error) throw error;
      toast.success("Deleted"); fetchAll();
    } catch (e: unknown) { toast.error(mapErrorMessage(e)); }
  };

  return (
    <>
      <div className="flex justify-end mb-4">
        <Button onClick={() => { resetForm(); setShowForm(true); }}>
          <Plus size={16} className="mr-1" /> New Paper
        </Button>
      </div>

      {showForm && (
        <Card className="border-border/60 mb-6">
          <CardHeader><CardTitle className="text-lg">{editing ? "Edit" : "Add"} Paper</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Paper Title *</Label>
                <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Paper title" maxLength={300} />
              </div>
              <div className="space-y-2">
                <Label>Author Name *</Label>
                <Input value={authorName} onChange={(e) => setAuthorName(e.target.value)} placeholder="Author name" maxLength={200} />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Category *</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Published Date *</Label>
                <Input type="date" value={publishedDate} onChange={(e) => setPublishedDate(e.target.value)} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Paper Link (URL)</Label>
              <Input value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} placeholder="https://..." />
            </div>
            <div className="space-y-2">
              <Label>Abstract</Label>
              <Textarea value={abstract_} onChange={(e) => setAbstract(e.target.value)} placeholder="Short abstract..." maxLength={1000} rows={3} />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={saving}>{saving ? "Saving..." : editing ? "Update" : "Create"}</Button>
              <Button variant="outline" onClick={resetForm}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {loading ? (
        <div className="space-y-3">{[1, 2].map((i) => <div key={i} className="h-20 bg-muted rounded-lg animate-pulse" />)}</div>
      ) : items.length === 0 ? (
        <p className="text-center py-8 text-muted-foreground">No papers yet</p>
      ) : (
        <div className="space-y-3">
          {items.map((p) => (
            <Card key={p.id} className="border-border/60">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold text-foreground">{p.title}</h3>
                      <Badge variant="secondary" className="text-xs">{p.category}</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {p.author_name} · {format(new Date(p.published_date), "MMM d, yyyy")}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" onClick={() => startEdit(p)}><Edit2 size={14} /></Button>
                    <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => handleDelete(p)}><Trash2 size={14} /></Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </>
  );
}
