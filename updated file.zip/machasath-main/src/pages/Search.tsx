import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search as SearchIcon, Trophy, GraduationCap, BarChart3, ShieldCheck, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";
import AnnouncementCarousel from "@/components/AnnouncementCarousel";
import SecondaryCarousel from "@/components/SecondaryCarousel";
import ContentSections from "@/components/ContentSections";
import { useFormOptions } from "@/hooks/useFormOptions";
import { useIsMobile } from "@/hooks/use-mobile";

export default function Search() {
  const navigate = useNavigate();
  const { options: branches } = useFormOptions("branch");
  const [searchQuery, setSearchQuery] = useState("");
  const [showAllBranches, setShowAllBranches] = useState(false);
  const isMobile = useIsMobile();

  const handleSearch = () => {
    if (searchQuery.trim()) {
      navigate(`/search/results?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleSearch();
  };

  const MOBILE_VISIBLE_COUNT = 6;
  const visibleBranches = isMobile && !showAllBranches ? branches.slice(0, MOBILE_VISIBLE_COUNT) : branches;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <AnnouncementCarousel />

      {/* Secondary carousel — top position */}
      <SecondaryCarousel position="top" />

      {/* Hero Section */}
      <div className="bg-muted/40 rounded-2xl py-12 px-4 text-center mb-8">
        <h1 className="text-3xl sm:text-4xl font-bold text-foreground tracking-tight">Find Your Collaborators</h1>
        <p className="text-muted-foreground mt-2 text-sm sm:text-base">
          Search for students by name, skills, or browse by branch.
        </p>

        {/* Functional Search Bar */}
        <div className="max-w-xl mx-auto mt-6 relative">
          <SearchIcon size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search by name, skill, or branch..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            className="pl-11 h-12 rounded-full text-sm shadow-sm border-border/60 bg-background"
          />
          {searchQuery.trim() && (
            <button
              onClick={handleSearch}
              className="absolute right-3 top-1/2 -translate-y-1/2 px-4 py-1.5 rounded-full bg-primary text-primary-foreground text-xs font-medium hover:bg-primary/90 transition-colors"
            >
              Search
            </button>
          )}
        </div>

        {/* Branch Pills */}
        <div className="flex flex-wrap justify-center gap-2.5 mt-6">
          {visibleBranches.map((branch) => (
            <button
              key={branch}
              onClick={() => navigate(`/branch/${encodeURIComponent(branch)}`)}
              className="px-5 py-2 rounded-full text-sm font-medium transition-all border bg-background text-muted-foreground border-border/60 hover:border-primary/40 hover:text-foreground hover:shadow-sm"
            >
              {branch}
            </button>
          ))}
        </div>

        {/* View More / Less button on mobile */}
        {isMobile && branches.length > MOBILE_VISIBLE_COUNT && (
          <button
            onClick={() => setShowAllBranches(!showAllBranches)}
            className="mt-3 text-sm font-semibold text-primary hover:underline"
          >
            {showAllBranches ? "View Less" : "View More"}
          </button>
        )}
      </div>

      {/* Secondary carousel — middle position */}
      <SecondaryCarousel position="middle" />

      {/* Hackathon CTA Section */}
      <div className="relative mt-10 rounded-2xl bg-gradient-to-br from-primary/90 to-accent/80 p-8 sm:p-12 text-center overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,hsl(var(--accent)/0.3),transparent_60%)]" />
        <div className="relative z-10">
          <Trophy size={40} className="mx-auto mb-3 text-primary-foreground drop-shadow-lg" />
          <h2 className="text-2xl sm:text-3xl font-extrabold text-primary-foreground tracking-tight">
            Are You Ready for the Challenge?
          </h2>
          <p className="mt-2 text-primary-foreground/80 text-sm sm:text-base max-w-md mx-auto leading-relaxed">
            Build, compete, and innovate. Find your dream team, crush deadlines, and turn bold ideas into winning
            projects.
          </p>
          <Button
            size="lg"
            onClick={() => navigate("/hackathons")}
            className="mt-6 rounded-full px-10 py-6 gap-2 text-lg font-bold shadow-xl bg-background text-foreground hover:bg-background/90 transition-transform hover:scale-105"
          >
            <Trophy size={20} />
            Explore Hackathons
          </Button>
        </div>
      </div>

      {/* Alumni CTA Section — distinct card style */}
      <div className="relative mt-6 rounded-2xl border border-border/60 bg-card p-8 sm:p-12 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-500" />
        <div className="flex flex-col sm:flex-row items-center gap-6 sm:gap-10">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center shrink-0 shadow-lg">
            <GraduationCap size={36} className="text-white" />
          </div>
          <div className="flex-1 text-center sm:text-left">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
              Your Seniors, Your Mentors
            </h2>
            <p className="mt-2 text-muted-foreground text-sm sm:text-base max-w-lg leading-relaxed">
              Get career guidance, referrals, and insider tips from alumni who've walked the same path. One conversation
              can change your career.
            </p>
          </div>
          <Button
            size="lg"
            onClick={() => navigate("/alumni")}
            className="rounded-full px-8 py-6 gap-2 text-base font-bold shadow-lg bg-gradient-to-r from-emerald-500 to-teal-500 text-white hover:from-emerald-600 hover:to-teal-600 transition-all hover:scale-105 shrink-0"
          >
            <GraduationCap size={18} />
            Meet Alumni
          </Button>
        </div>
      </div>

      {/* Dynamic Content Sections */}
      <ContentSections />

      {/* Info Section */}
      <div className="mt-12 text-center">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
          Transition from Chaos to Official Governance
        </h2>
        <p className="mt-2 text-muted-foreground text-sm sm:text-base max-w-2xl mx-auto leading-relaxed">
          Give your students a secure, data-driven platform that enhances career outcomes and fosters real-world teamwork.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-8 max-w-4xl mx-auto">
          {[
            { icon: BarChart3, title: "Data Insights", desc: "Understand collaboration patterns and engagement across branches and year groups." },
            { icon: ShieldCheck, title: "Risk Management", desc: "Eliminate the liability of unmonitored WhatsApp/Telegram groups for institutional communication." },
            { icon: TrendingUp, title: "Improved Outcomes", desc: "Accelerate career outcomes through structured alumni mentorship and verified skill-based networking." },
          ].map((item) => (
            <div key={item.title} className="flex flex-col items-center sm:items-start text-center sm:text-left p-6 rounded-2xl bg-card border border-border/60">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <item.icon size={22} className="text-primary" />
              </div>
              <h3 className="text-base font-bold text-foreground">{item.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Secondary carousel — bottom position */}
      <SecondaryCarousel position="bottom" />

      {/* Footer */}
      <footer className="mt-12 border-t border-border/60 pt-6 pb-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
        <p>© 2026 SaathVerse. All rights reserved.</p>
        <div className="flex items-center gap-4">
          <span className="hover:text-foreground cursor-pointer transition-colors">Terms of Service</span>
          <span className="hover:text-foreground cursor-pointer transition-colors">Privacy</span>
        </div>
      </footer>
    </motion.div>
  );
}
