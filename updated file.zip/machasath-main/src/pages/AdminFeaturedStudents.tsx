import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { mapErrorMessage } from "@/lib/errorMessages";
import { Plus, Trash2, Trophy, Search, ArrowLeft, Image as ImageIcon } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import type { Tables } from "@/integrations/supabase/types";
import { useFormOptions } from "@/hooks/useFormOptions";
import { useImageUpload } from "@/components/ImageCropper";

/** Hook to load content section titles (IEEE, Clubs, Startups, etc.) */
function useContentSectionLabels() {
  const [labels, setLabels] = useState<string[]>([]);
  useEffect(() => {
    supabase
      .from("content_sections")
      .select("title")
      .eq("is_active", true)
      .order("display_order")
      .then(({ data }) => {
        if (data) setLabels(data.map((d) => d.title));
      });
  }, []);
  return labels;
}

type Profile = Tables<"profiles">;

type FeaturedRow = {
  id: string;
  profile_id: string;
  branch: string;
  achievement: string | null;
  description: string | null;
  media_url: string | null;
  display_order: number;
  is_active: boolean;
  created_by: string;
  profile?: Profile;
};

// Branches are now loaded dynamically

export default function AdminFeaturedStudents() {
  const { user, isAdmin, activeCollegeId: collegeId } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const { options: branchOptions } = useFormOptions("branch");
  const sectionLabels = useContentSectionLabels();
  const BRANCHES = [...branchOptions, ...sectionLabels.filter((s) => !branchOptions.includes(s))];

  const [branch, setBranch] = useState("");
  const [featuredTitle, setFeaturedTitle] = useState("Top Students");
  const [savingTitle, setSavingTitle] = useState(false);

  // Load featured title from site_settings
  useEffect(() => {
    supabase
      .from("site_settings")
      .select("value")
      .eq("key", "featured_title")
      .maybeSingle()
      .then(({ data }) => {
        if (data?.value) setFeaturedTitle(data.value);
      });
  }, []);

  // Set initial branch when loaded
  useEffect(() => {
    if (BRANCHES.length > 0 && !branch) {
      setBranch(BRANCHES[0]);
    }
  }, [BRANCHES]);

  const saveFeaturedTitle = async () => {
    setSavingTitle(true);
    const { error } = await supabase
      .from("site_settings")
      .upsert({ key: "featured_title", value: featuredTitle.trim(), updated_at: new Date().toISOString() }, { onConflict: "key" });
    if (error) {
      toast({ title: "Error saving title", variant: "destructive" });
    } else {
      toast({ title: "Title updated!" });
    }
    setSavingTitle(false);
  };
  const [featured, setFeatured] = useState<FeaturedRow[]>([]);
  const [loading, setLoading] = useState(true);

  // Add form
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Profile[]>([]);
  const [selectedProfile, setSelectedProfile] = useState<Profile | null>(null);
  const [achievement, setAchievement] = useState("");
  const [description, setDescription] = useState("");
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const featuredCrop = useImageUpload("carousel", (f) => setMediaFile(f));

  const fetchFeatured = async () => {
    setLoading(true);
    let query = supabase
      .from("branch_featured_students")
      .select("*")
      .eq("branch", branch)
      .order("display_order", { ascending: true });
    if (collegeId) query = query.eq("college_id", collegeId);
    const { data } = await query;

    if (data && data.length > 0) {
      // Fetch profile info for each
      const profileIds = data.map((d) => d.profile_id);
      const { data: profiles } = await supabase
        .from("profiles")
        .select("*")
        .in("id", profileIds);

      const profileMap = new Map((profiles || []).map((p) => [p.id, p]));
      setFeatured(data.map((d) => ({ ...d, profile: profileMap.get(d.profile_id) })));
    } else {
      setFeatured([]);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchFeatured();
  }, [branch]);

  const isContentSection = sectionLabels.includes(branch);

  // Search students — content sections can search ANY branch
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }
    const timer = setTimeout(async () => {
      let query = supabase
        .from("profiles")
        .select("*")
        .ilike("full_name", `%${searchQuery.trim()}%`)
        .limit(5);
      if (!isContentSection) {
        query = query.eq("branch", branch);
      }
      const { data } = await query;
      setSearchResults(data || []);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery, branch, isContentSection]);

  const uploadMedia = async (file: File): Promise<string | null> => {
    const ext = file.name.split(".").pop();
    const path = `featured/${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from("carousel-media").upload(path, file);
    if (error) {
      toast({ title: "Upload failed", description: mapErrorMessage(error), variant: "destructive" });
      return null;
    }
    const { data } = supabase.storage.from("carousel-media").getPublicUrl(path);
    return data.publicUrl;
  };

  const handleAdd = async () => {
    if (!selectedProfile || !user) return;
    setSubmitting(true);

    let media_url: string | null = null;
    if (mediaFile) {
      media_url = await uploadMedia(mediaFile);
      if (!media_url) { setSubmitting(false); return; }
    }

    const { error } = await supabase.from("branch_featured_students").insert({
      profile_id: selectedProfile.id,
      branch,
      achievement: achievement.trim() || null,
      description: description.trim() || null,
      media_url,
      display_order: featured.length,
      created_by: user.id,
      college_id: collegeId,
    });

    if (error) {
      toast({ title: "Error", description: mapErrorMessage(error), variant: "destructive" });
    } else {
      toast({ title: "Student featured!" });
      setSelectedProfile(null);
      setAchievement("");
      setDescription("");
      setMediaFile(null);
      setSearchQuery("");
      setSearchResults([]);
      fetchFeatured();
    }
    setSubmitting(false);
  };

  const toggleActive = async (row: FeaturedRow) => {
    await supabase.from("branch_featured_students").update({ is_active: !row.is_active }).eq("id", row.id);
    fetchFeatured();
  };

  const deleteRow = async (id: string, media_url: string | null) => {
    if (!confirm("Remove this featured student?")) return;
    if (media_url) {
      const path = media_url.split("/carousel-media/")[1];
      if (path) await supabase.storage.from("carousel-media").remove([path]);
    }
    await supabase.from("branch_featured_students").delete().eq("id", id);
    fetchFeatured();
  };

  if (!isAdmin) {
    return (
      <div className="text-center py-16 text-muted-foreground">
        <p className="text-lg font-medium">Admin access required</p>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate("/admin/dashboard")} className="p-2 rounded-full hover:bg-muted transition-colors">
          <ArrowLeft size={20} className="text-foreground" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Trophy size={22} className="text-primary" /> Featured Students
          </h1>
          <p className="text-muted-foreground text-sm">Showcase top students per branch</p>
        </div>
      </div>

      {/* Featured title customization */}
      <div className="mb-6 p-4 bg-card rounded-xl border border-border/60 space-y-3">
        <Label className="text-xs font-semibold text-muted-foreground">Carousel Title (shown to students)</Label>
        <div className="flex gap-2">
          <Input
            value={featuredTitle}
            onChange={(e) => setFeaturedTitle(e.target.value)}
            maxLength={50}
            placeholder="e.g. Top Students, Star Performers..."
            className="max-w-xs"
          />
          <Button size="sm" onClick={saveFeaturedTitle} disabled={savingTitle}>
            {savingTitle ? "Saving..." : "Save Title"}
          </Button>
        </div>
      </div>

      {/* Branch selector */}
      <div className="mb-6 max-w-xs">
        <Label className="text-xs font-semibold text-muted-foreground mb-1 block">Branch</Label>
        <Select value={branch} onValueChange={setBranch}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {BRANCHES.map((b) => (
              <SelectItem key={b} value={b}>{b}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Add form */}
      <div className="p-4 bg-card rounded-xl border border-border/60 shadow-sm mb-6 space-y-3">
        <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <Plus size={14} /> Add Featured Student
        </h2>

        {!selectedProfile ? (
          <div className="space-y-2">
            <div className="relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder={isContentSection ? `Search all students for ${branch}...` : `Search ${branch} students...`}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            {searchResults.length > 0 && (
              <div className="border border-border/60 rounded-lg divide-y divide-border/40 max-h-48 overflow-y-auto">
                {searchResults.map((p) => (
                  <button
                    key={p.id}
                    className="w-full flex items-center gap-3 p-3 hover:bg-muted/50 transition-colors text-left"
                    onClick={() => {
                      setSelectedProfile(p);
                      setSearchResults([]);
                      setSearchQuery("");
                    }}
                  >
                    <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0 overflow-hidden">
                      {p.photo_url && p.show_photo ? (
                        <img src={p.photo_url} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-xs font-bold text-muted-foreground">{p.full_name[0]}</span>
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">{p.full_name}</p>
                      <p className="text-xs text-muted-foreground">{p.year_of_study === 0 ? "N/A" : `Year ${p.year_of_study}`} · ID: {p.id.slice(0, 8)}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0 overflow-hidden">
              {selectedProfile.photo_url && selectedProfile.show_photo ? (
                <img src={selectedProfile.photo_url} alt="" className="w-full h-full object-cover" />
              ) : (
                <span className="text-xs font-bold text-muted-foreground">{selectedProfile.full_name[0]}</span>
              )}
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">{selectedProfile.full_name}</p>
              <p className="text-xs text-muted-foreground">ID: {selectedProfile.id.slice(0, 8)}</p>
            </div>
            <button onClick={() => setSelectedProfile(null)} className="text-xs text-destructive hover:underline">
              Change
            </button>
          </div>
        )}

        <Input
          placeholder="Achievement (e.g., Won SIH 2025, Top Coder)"
          value={achievement}
          onChange={(e) => setAchievement(e.target.value)}
          maxLength={200}
        />

        <Textarea
          placeholder="Description (optional — additional details about the student)"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={2}
          maxLength={500}
        />

        <div>
          <button type="button" onClick={featuredCrop.triggerUpload} className="flex items-center gap-2 cursor-pointer text-sm text-muted-foreground border border-dashed border-border rounded-lg px-4 py-2 hover:bg-muted/50 transition-colors w-full">
            <ImageIcon size={14} />
            {mediaFile ? mediaFile.name : "Upload & crop image (optional)"}
          </button>
          <featuredCrop.CropperModal />
        </div>

        <Button onClick={handleAdd} disabled={submitting || !selectedProfile} size="sm">
          {submitting ? "Adding..." : "Feature Student"}
        </Button>
      </div>

      {/* Current featured */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2].map((i) => <div key={i} className="h-16 bg-muted/50 rounded-xl animate-pulse" />)}
        </div>
      ) : featured.length === 0 ? (
        <p className="text-center text-muted-foreground py-8">No featured students for {branch} yet</p>
      ) : (
        <div className="space-y-2">
          {featured.map((row) => (
            <div key={row.id} className="flex items-center gap-3 p-3 bg-card rounded-xl border border-border/60">
              <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center shrink-0 overflow-hidden">
                {row.profile?.photo_url && row.profile?.show_photo ? (
                  <img src={row.profile.photo_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-sm font-bold text-muted-foreground">
                    {row.profile?.full_name?.[0] || "?"}
                  </span>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">
                  {row.profile?.full_name || "Unknown"}
                </p>
                {row.achievement && (
                  <p className="text-xs text-primary truncate">🏆 {row.achievement}</p>
                )}
                <p className="text-[10px] text-muted-foreground">ID: {row.profile_id.slice(0, 8)}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Switch checked={row.is_active} onCheckedChange={() => toggleActive(row)} />
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-destructive hover:text-destructive"
                  onClick={() => deleteRow(row.id, row.media_url)}
                >
                  <Trash2 size={14} />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
}
