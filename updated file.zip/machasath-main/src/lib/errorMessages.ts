/**
 * Maps raw database/API error messages to user-friendly messages.
 * Prevents leaking internal database structure (table names, constraints, columns).
 */
export function mapErrorMessage(error: unknown): string {
  const msg =
    typeof error === "object" && error !== null && "message" in error
      ? String((error as { message: string }).message).toLowerCase()
      : "";

  if (msg.includes("duplicate key") || msg.includes("unique constraint")) {
    return "This action has already been performed.";
  }
  if (msg.includes("foreign key")) {
    return "The referenced item no longer exists.";
  }
  if (msg.includes("check constraint") || msg.includes("violates")) {
    return "Invalid data provided. Please check your input.";
  }
  if (msg.includes("permission denied") || msg.includes("row-level security")) {
    return "You do not have permission to perform this action.";
  }
  if (msg.includes("invalid login") || msg.includes("invalid email or password")) {
    return "Invalid email or password.";
  }
  if (msg.includes("email not confirmed")) {
    return "Please verify your email before signing in.";
  }
  if (msg.includes("user already registered")) {
    return "An account with this email already exists.";
  }
  if (msg.includes("rate limit") || msg.includes("too many requests")) {
    return "Too many attempts. Please try again later.";
  }

  // Log full error for debugging (only in dev)
  if (import.meta.env.DEV) {
    console.error("Unhandled error:", error);
  }

  return "Something went wrong. Please try again.";
}
