/** Format year_of_study for display. 0 = "N/A", otherwise "Year X" */
export function formatYearOfStudy(year: number): string {
  return year === 0 ? "N/A" : `Year ${year}`;
}
