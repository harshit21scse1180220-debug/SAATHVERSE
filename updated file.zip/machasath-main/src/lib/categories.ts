export const CATEGORIES = [
  "Engineering",
  "Computer Science",
  "AI & ML",
  "Electronics",
  "Mechanical",
  "Civil",
  "Management",
  "Commerce",
  "Law",
  "Design",
  "Medical",
  "Arts",
] as const;

export type Category = (typeof CATEGORIES)[number];
