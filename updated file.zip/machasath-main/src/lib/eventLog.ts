import { supabase } from "@/integrations/supabase/client";

type EventType =
  | "profile_created"
  | "search_performed"
  | "collaboration_request_sent"
  | "collaboration_request_accepted"
  | "hackathon_team_created"
  | "page_view"
  | "feature_click"
  | "mutation_failed"
  | "admin_action"
  | "onboarding_started"
  | "onboarding_completed";

export async function logEvent(
  userId: string,
  eventType: EventType,
  metadata: Record<string, unknown> = {}
) {
  try {
    await supabase.from("event_logs").insert([{
      user_id: userId,
      event_type: eventType,
      metadata: metadata as any,
    }]);
  } catch (error) {
    console.error("Failed to log event:", error);
  }
}
