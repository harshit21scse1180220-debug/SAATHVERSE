
-- Drop the unique constraint on category+label since sub-branches under different parents may share names
ALTER TABLE public.form_options DROP CONSTRAINT IF EXISTS form_options_category_label_key;

-- Add a unique constraint that accounts for parent_id
CREATE UNIQUE INDEX form_options_unique_label_per_parent ON public.form_options (category, label, COALESCE(parent_id, '00000000-0000-0000-0000-000000000000'));
