-- Add category column to startup_ideas
ALTER TABLE public.startup_ideas ADD COLUMN category text DEFAULT 'Other';
