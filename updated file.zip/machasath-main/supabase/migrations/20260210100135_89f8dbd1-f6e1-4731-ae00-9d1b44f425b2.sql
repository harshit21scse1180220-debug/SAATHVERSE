-- Enable realtime for collaboration_requests
ALTER PUBLICATION supabase_realtime ADD TABLE public.collaboration_requests;

-- Add team_size and description columns to hackathon_teams
ALTER TABLE public.hackathon_teams ADD COLUMN IF NOT EXISTS team_size integer DEFAULT 4;
ALTER TABLE public.hackathon_teams ADD COLUMN IF NOT EXISTS description text;