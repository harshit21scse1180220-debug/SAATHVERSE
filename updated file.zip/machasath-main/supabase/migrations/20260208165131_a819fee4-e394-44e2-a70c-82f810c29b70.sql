-- Drop the hardcoded CHECK constraints that conflict with the dynamic form_options system
-- Branches, genders, and years are now managed via the form_options table

ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_branch_check;
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_gender_check;
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_year_of_study_check;

-- Add a more permissive year_of_study check that allows 0 (N/A)
ALTER TABLE public.profiles ADD CONSTRAINT profiles_year_of_study_check CHECK (year_of_study >= 0 AND year_of_study <= 10);