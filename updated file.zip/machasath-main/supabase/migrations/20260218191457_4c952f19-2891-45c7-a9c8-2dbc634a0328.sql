-- Allow admins to delete messages (for profile cleanup)
CREATE POLICY "Admins can delete messages"
ON public.messages FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Allow admins to delete event logs (for profile cleanup)
CREATE POLICY "Admins can delete event logs"
ON public.event_logs FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Allow admins to delete team invites (for profile cleanup)
CREATE POLICY "Admins can delete team invites"
ON public.team_invites FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Allow admins to delete team join requests (for profile cleanup)
CREATE POLICY "Admins can delete team join requests"
ON public.team_join_requests FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Allow admins to delete startup join requests (for profile cleanup)
CREATE POLICY "Admins can delete startup join requests"
ON public.startup_join_requests FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Allow admins to delete startup messages (for profile cleanup)
CREATE POLICY "Admins can delete startup messages"
ON public.startup_messages FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));