
-- Create a function to validate the authenticated user's email domain
CREATE OR REPLACE FUNCTION public.is_valid_university_email()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM auth.users
    WHERE id = auth.uid()
    AND (
      email = 'harshit02425@gmail.com'
      OR email ~ '^[a-zA-Z]+\.[a-zA-Z0-9]+@galgotiasuniversity\.edu\.in$'
    )
  )
$$;

-- Add RLS policy: only users with valid university emails can create profiles
CREATE POLICY "Only university emails can create profiles"
ON public.profiles
FOR INSERT
WITH CHECK (
  auth.uid() = user_id
  AND public.is_valid_university_email()
);
