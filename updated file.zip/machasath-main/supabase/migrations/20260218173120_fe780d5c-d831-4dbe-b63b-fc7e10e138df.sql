
-- Update is_valid_university_email to check against colleges table
CREATE OR REPLACE FUNCTION public.is_valid_university_email()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $$
  SELECT EXISTS (
    SELECT 1 FROM auth.users u
    WHERE u.id = auth.uid()
    AND (
      u.email = 'harshit02425@gmail.com'
      OR EXISTS (
        SELECT 1 FROM public.colleges c
        WHERE u.email LIKE '%@' || c.domain
      )
    )
  )
$$;
