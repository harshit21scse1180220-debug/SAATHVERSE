
-- Add CTA detail fields to content_cards
ALTER TABLE public.content_cards
  ADD COLUMN IF NOT EXISTS about_text text,
  ADD COLUMN IF NOT EXISTS banner_image_url text,
  ADD COLUMN IF NOT EXISTS leader_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS co_leader_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL;
