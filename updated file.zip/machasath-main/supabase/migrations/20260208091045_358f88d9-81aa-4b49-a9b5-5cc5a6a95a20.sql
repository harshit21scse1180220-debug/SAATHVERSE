
-- Add optional branch column to carousel_slides
-- NULL = main page carousel, specific value = branch-specific carousel
ALTER TABLE public.carousel_slides ADD COLUMN branch TEXT DEFAULT NULL;

-- Index for efficient branch queries
CREATE INDEX idx_carousel_slides_branch ON public.carousel_slides(branch);
