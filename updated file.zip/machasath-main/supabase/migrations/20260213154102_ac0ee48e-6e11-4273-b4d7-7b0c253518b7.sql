-- Add DELETE policy so participants can delete their collaboration requests (unfriend)
CREATE POLICY "Participants can delete requests"
ON public.collaboration_requests
FOR DELETE
USING ((auth.uid() = sender_id) OR (auth.uid() = receiver_id));