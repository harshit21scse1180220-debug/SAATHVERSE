
-- Create carousel_slides table
CREATE TABLE public.carousel_slides (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  hyperlink TEXT,
  media_url TEXT,
  category TEXT NOT NULL DEFAULT 'update',
  is_active BOOLEAN NOT NULL DEFAULT true,
  display_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID NOT NULL
);

-- Enable RLS
ALTER TABLE public.carousel_slides ENABLE ROW LEVEL SECURITY;

-- Public read for active slides
CREATE POLICY "Anyone can view active slides"
ON public.carousel_slides
FOR SELECT
USING (is_active = true);

-- Admin insert
CREATE POLICY "Admins can create slides"
ON public.carousel_slides
FOR INSERT
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Admin update
CREATE POLICY "Admins can update slides"
ON public.carousel_slides
FOR UPDATE
USING (public.has_role(auth.uid(), 'admin'));

-- Admin delete
CREATE POLICY "Admins can delete slides"
ON public.carousel_slides
FOR DELETE
USING (public.has_role(auth.uid(), 'admin'));

-- Timestamp trigger
CREATE TRIGGER update_carousel_slides_updated_at
BEFORE UPDATE ON public.carousel_slides
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Storage bucket for carousel media
INSERT INTO storage.buckets (id, name, public) VALUES ('carousel-media', 'carousel-media', true);

-- Storage policies
CREATE POLICY "Anyone can view carousel media"
ON storage.objects FOR SELECT
USING (bucket_id = 'carousel-media');

CREATE POLICY "Admins can upload carousel media"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'carousel-media' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update carousel media"
ON storage.objects FOR UPDATE
USING (bucket_id = 'carousel-media' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete carousel media"
ON storage.objects FOR DELETE
USING (bucket_id = 'carousel-media' AND public.has_role(auth.uid(), 'admin'));
