
-- Add AI evaluation columns to startup_ideas
ALTER TABLE public.startup_ideas
  ADD COLUMN IF NOT EXISTS ai_overall_score numeric,
  ADD COLUMN IF NOT EXISTS ai_clarity_score numeric,
  ADD COLUMN IF NOT EXISTS ai_market_score numeric,
  ADD COLUMN IF NOT EXISTS ai_feasibility_score numeric,
  ADD COLUMN IF NOT EXISTS ai_innovation text,
  ADD COLUMN IF NOT EXISTS ai_difficulty text,
  ADD COLUMN IF NOT EXISTS ai_strengths text,
  ADD COLUMN IF NOT EXISTS ai_risks text,
  ADD COLUMN IF NOT EXISTS ai_suggestions text,
  ADD COLUMN IF NOT EXISTS ai_summary text,
  ADD COLUMN IF NOT EXISTS ai_evaluated_at timestamp with time zone;

-- Index for sorting by AI score
CREATE INDEX IF NOT EXISTS idx_startup_ideas_ai_overall_score ON public.startup_ideas (ai_overall_score DESC NULLS LAST);
