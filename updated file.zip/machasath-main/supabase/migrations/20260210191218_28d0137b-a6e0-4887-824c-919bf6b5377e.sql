
-- ============================================
-- 1. STARTUP IDEAS
-- ============================================
CREATE TABLE public.startup_ideas (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  creator_id UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.startup_ideas ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone authenticated can view active startup ideas"
ON public.startup_ideas FOR SELECT
USING (status = 'active' OR creator_id = auth.uid());

CREATE POLICY "Users can create their own startup ideas"
ON public.startup_ideas FOR INSERT
WITH CHECK (auth.uid() = creator_id);

CREATE POLICY "Users can update their own startup ideas"
ON public.startup_ideas FOR UPDATE
USING (auth.uid() = creator_id);

CREATE POLICY "Users can delete their own startup ideas"
ON public.startup_ideas FOR DELETE
USING (auth.uid() = creator_id);

CREATE TRIGGER update_startup_ideas_updated_at
BEFORE UPDATE ON public.startup_ideas
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================
-- 2. STARTUP JOIN REQUESTS
-- ============================================
CREATE TABLE public.startup_join_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  startup_id UUID NOT NULL REFERENCES public.startup_ideas(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  message TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.startup_join_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Startup creators and requesters can view join requests"
ON public.startup_join_requests FOR SELECT
USING (
  auth.uid() = user_id OR
  EXISTS (SELECT 1 FROM public.startup_ideas WHERE id = startup_join_requests.startup_id AND creator_id = auth.uid())
);

CREATE POLICY "Users can request to join startups"
ON public.startup_join_requests FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Startup creators can update join requests"
ON public.startup_join_requests FOR UPDATE
USING (
  EXISTS (SELECT 1 FROM public.startup_ideas WHERE id = startup_join_requests.startup_id AND creator_id = auth.uid())
);

-- ============================================
-- 3. STARTUP GROUP MESSAGES
-- ============================================
CREATE TABLE public.startup_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  startup_id UUID NOT NULL REFERENCES public.startup_ideas(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.startup_messages ENABLE ROW LEVEL SECURITY;

-- Only members (creator + accepted joiners) can view and send messages
CREATE POLICY "Startup members can view messages"
ON public.startup_messages FOR SELECT
USING (
  EXISTS (SELECT 1 FROM public.startup_ideas WHERE id = startup_messages.startup_id AND creator_id = auth.uid())
  OR EXISTS (SELECT 1 FROM public.startup_join_requests WHERE startup_id = startup_messages.startup_id AND user_id = auth.uid() AND status = 'accepted')
);

CREATE POLICY "Startup members can send messages"
ON public.startup_messages FOR INSERT
WITH CHECK (
  auth.uid() = sender_id AND (
    EXISTS (SELECT 1 FROM public.startup_ideas WHERE id = startup_messages.startup_id AND creator_id = auth.uid())
    OR EXISTS (SELECT 1 FROM public.startup_join_requests WHERE startup_id = startup_messages.startup_id AND user_id = auth.uid() AND status = 'accepted')
  )
);

-- Enable realtime for group chat
ALTER PUBLICATION supabase_realtime ADD TABLE public.startup_messages;

-- ============================================
-- 4. TEAM INVITES (for hackathon teams)
-- ============================================
CREATE TABLE public.team_invites (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  team_id UUID NOT NULL REFERENCES public.hackathon_teams(id) ON DELETE CASCADE,
  invited_user_id UUID NOT NULL,
  invited_by UUID NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.team_invites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Team creators and invitees can view invites"
ON public.team_invites FOR SELECT
USING (
  auth.uid() = invited_user_id OR
  EXISTS (SELECT 1 FROM public.hackathon_teams WHERE id = team_invites.team_id AND creator_id = auth.uid())
);

CREATE POLICY "Team creators can send invites"
ON public.team_invites FOR INSERT
WITH CHECK (
  auth.uid() = invited_by AND
  EXISTS (SELECT 1 FROM public.hackathon_teams WHERE id = team_invites.team_id AND creator_id = auth.uid())
);

CREATE POLICY "Invitees can update their invite status"
ON public.team_invites FOR UPDATE
USING (auth.uid() = invited_user_id);
