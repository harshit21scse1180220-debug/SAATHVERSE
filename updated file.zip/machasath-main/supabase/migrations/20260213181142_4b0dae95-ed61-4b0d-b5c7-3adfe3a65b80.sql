-- Fix 1: Update profile-photos bucket file size limit to 1MB (1048576 bytes)
UPDATE storage.buckets 
SET file_size_limit = 1048576 
WHERE id = 'profile-photos';

-- Fix 2: Drop old check constraint and add updated one with all event types
ALTER TABLE public.event_logs DROP CONSTRAINT IF EXISTS event_logs_event_type_check;

ALTER TABLE public.event_logs ADD CONSTRAINT event_logs_event_type_check 
CHECK (event_type = ANY (ARRAY[
  'profile_created'::text, 
  'search_performed'::text, 
  'collaboration_request_sent'::text, 
  'collaboration_request_accepted'::text, 
  'hackathon_team_created'::text,
  'page_view'::text,
  'feature_click'::text
]));

-- Fix 3: Update site_settings to 1024 KB for consistency
UPDATE public.site_settings SET value = '1024' WHERE key = 'max_upload_size_kb';