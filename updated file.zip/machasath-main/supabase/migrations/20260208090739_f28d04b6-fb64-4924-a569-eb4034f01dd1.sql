
-- Add media_url and description to branch_featured_students
ALTER TABLE public.branch_featured_students ADD COLUMN media_url TEXT;
ALTER TABLE public.branch_featured_students ADD COLUMN description TEXT;
