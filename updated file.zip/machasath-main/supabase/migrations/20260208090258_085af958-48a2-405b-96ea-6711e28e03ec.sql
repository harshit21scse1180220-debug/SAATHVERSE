
-- Table for admin-curated featured students per branch
CREATE TABLE public.branch_featured_students (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  branch TEXT NOT NULL,
  achievement TEXT,
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Unique constraint: a profile can only be featured once per branch
ALTER TABLE public.branch_featured_students ADD CONSTRAINT unique_profile_branch UNIQUE (profile_id, branch);

-- Enable RLS
ALTER TABLE public.branch_featured_students ENABLE ROW LEVEL SECURITY;

-- Anyone authenticated can view active featured students
CREATE POLICY "Anyone can view active featured students"
ON public.branch_featured_students
FOR SELECT
USING (is_active = true);

-- Admins can view all
CREATE POLICY "Admins can view all featured students"
ON public.branch_featured_students
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Admins can insert
CREATE POLICY "Admins can insert featured students"
ON public.branch_featured_students
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Admins can update
CREATE POLICY "Admins can update featured students"
ON public.branch_featured_students
FOR UPDATE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Admins can delete
CREATE POLICY "Admins can delete featured students"
ON public.branch_featured_students
FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Auto-update timestamp
CREATE TRIGGER update_branch_featured_students_updated_at
BEFORE UPDATE ON public.branch_featured_students
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();
