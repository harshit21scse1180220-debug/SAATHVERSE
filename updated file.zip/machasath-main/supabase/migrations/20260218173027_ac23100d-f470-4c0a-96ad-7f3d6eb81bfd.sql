
-- 1. Create colleges table
CREATE TABLE public.colleges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  domain text NOT NULL UNIQUE,
  logo_url text,
  primary_color text DEFAULT '#FF6B00',
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.colleges ENABLE ROW LEVEL SECURITY;

-- Anyone authenticated can view colleges (needed for signup domain check)
CREATE POLICY "Anyone can view colleges"
  ON public.colleges FOR SELECT
  USING (true);

-- Only super_admins can manage colleges
CREATE POLICY "Super admins can insert colleges"
  ON public.colleges FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Super admins can update colleges"
  ON public.colleges FOR UPDATE
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Super admins can delete colleges"
  ON public.colleges FOR DELETE
  USING (has_role(auth.uid(), 'admin'::app_role));

-- 2. Add college_id to profiles
ALTER TABLE public.profiles
  ADD COLUMN college_id uuid REFERENCES public.colleges(id);

-- 3. Seed current college
INSERT INTO public.colleges (name, domain, logo_url)
VALUES ('Galgotias University', 'galgotiasuniversity.edu.in', NULL);

-- 4. Backfill existing profiles with Galgotias college_id
UPDATE public.profiles
SET college_id = (SELECT id FROM public.colleges WHERE domain = 'galgotiasuniversity.edu.in')
WHERE college_id IS NULL;
