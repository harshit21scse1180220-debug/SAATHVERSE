
-- Table for dynamic form options (branches, etc.)
CREATE TABLE public.form_options (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  category TEXT NOT NULL,  -- e.g. 'branch', 'gender', 'year'
  label TEXT NOT NULL,
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(category, label)
);

-- Enable RLS
ALTER TABLE public.form_options ENABLE ROW LEVEL SECURITY;

-- Anyone authenticated can read active options
CREATE POLICY "Anyone can view active form options"
ON public.form_options FOR SELECT
USING (is_active = true);

-- Admins can view all
CREATE POLICY "Admins can view all form options"
ON public.form_options FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Admins can insert
CREATE POLICY "Admins can insert form options"
ON public.form_options FOR INSERT
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Admins can update
CREATE POLICY "Admins can update form options"
ON public.form_options FOR UPDATE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Admins can delete
CREATE POLICY "Admins can delete form options"
ON public.form_options FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Trigger for updated_at
CREATE TRIGGER update_form_options_updated_at
BEFORE UPDATE ON public.form_options
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Seed with existing branches
INSERT INTO public.form_options (category, label, display_order) VALUES
('branch', 'Computer Science', 0),
('branch', 'Law', 1),
('branch', 'Medical', 2),
('branch', 'Agriculture', 3),
('branch', 'Sports', 4),
('branch', 'Mechanics', 5);
