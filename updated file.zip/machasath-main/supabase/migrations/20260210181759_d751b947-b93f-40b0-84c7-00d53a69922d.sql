
-- Content sections (General, Professional Org, College Club, Entrepreneurship)
CREATE TABLE public.content_sections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  section_type TEXT NOT NULL DEFAULT 'general' CHECK (section_type IN ('general', 'professional_org', 'college_club', 'entrepreneurship')),
  cover_image_url TEXT,
  description TEXT,
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_by UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.content_sections ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active sections" ON public.content_sections FOR SELECT USING (is_active = true);
CREATE POLICY "Admins can view all sections" ON public.content_sections FOR SELECT USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can insert sections" ON public.content_sections FOR INSERT WITH CHECK (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update sections" ON public.content_sections FOR UPDATE USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete sections" ON public.content_sections FOR DELETE USING (has_role(auth.uid(), 'admin'));

CREATE TRIGGER update_content_sections_updated_at BEFORE UPDATE ON public.content_sections
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Content rows inside sections
CREATE TABLE public.content_rows (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  section_id UUID NOT NULL REFERENCES public.content_sections(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.content_rows ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active rows" ON public.content_rows FOR SELECT USING (is_active = true);
CREATE POLICY "Admins can view all rows" ON public.content_rows FOR SELECT USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can insert rows" ON public.content_rows FOR INSERT WITH CHECK (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update rows" ON public.content_rows FOR UPDATE USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete rows" ON public.content_rows FOR DELETE USING (has_role(auth.uid(), 'admin'));

CREATE TRIGGER update_content_rows_updated_at BEFORE UPDATE ON public.content_rows
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Content cards inside rows
CREATE TABLE public.content_cards (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  row_id UUID NOT NULL REFERENCES public.content_rows(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  subtitle TEXT,
  image_url TEXT,
  link_url TEXT,
  profile_id UUID REFERENCES public.profiles(id),
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.content_cards ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active cards" ON public.content_cards FOR SELECT USING (is_active = true);
CREATE POLICY "Admins can view all cards" ON public.content_cards FOR SELECT USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can insert cards" ON public.content_cards FOR INSERT WITH CHECK (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update cards" ON public.content_cards FOR UPDATE USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete cards" ON public.content_cards FOR DELETE USING (has_role(auth.uid(), 'admin'));

CREATE TRIGGER update_content_cards_updated_at BEFORE UPDATE ON public.content_cards
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Student affiliations (orgs, clubs, entrepreneurship roles)
CREATE TABLE public.student_affiliations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  section_id UUID NOT NULL REFERENCES public.content_sections(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'member',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(profile_id, section_id)
);

ALTER TABLE public.student_affiliations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view affiliations" ON public.student_affiliations FOR SELECT USING (true);
CREATE POLICY "Admins can insert affiliations" ON public.student_affiliations FOR INSERT WITH CHECK (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update affiliations" ON public.student_affiliations FOR UPDATE USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete affiliations" ON public.student_affiliations FOR DELETE USING (has_role(auth.uid(), 'admin'));

CREATE TRIGGER update_student_affiliations_updated_at BEFORE UPDATE ON public.student_affiliations
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Storage bucket for content media
INSERT INTO storage.buckets (id, name, public) VALUES ('content-media', 'content-media', true);

CREATE POLICY "Anyone can view content media" ON storage.objects FOR SELECT USING (bucket_id = 'content-media');
CREATE POLICY "Admins can upload content media" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'content-media' AND EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin'));
CREATE POLICY "Admins can update content media" ON storage.objects FOR UPDATE USING (bucket_id = 'content-media' AND EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin'));
CREATE POLICY "Admins can delete content media" ON storage.objects FOR DELETE USING (bucket_id = 'content-media' AND EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin'));
