-- Drop the restrictive SELECT policy and recreate as permissive
DROP POLICY "Anyone can view active slides" ON public.carousel_slides;

CREATE POLICY "Anyone can view active slides"
ON public.carousel_slides
FOR SELECT
USING (is_active = true);

-- Also need a permissive SELECT for admins to see all slides (active and inactive)
CREATE POLICY "Admins can view all slides"
ON public.carousel_slides
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));