
-- Add alumni columns to profiles
ALTER TABLE public.profiles
  ADD COLUMN is_alumni boolean NOT NULL DEFAULT false,
  ADD COLUMN company_name text DEFAULT NULL,
  ADD COLUMN tech_or_non_tech text DEFAULT NULL,
  ADD COLUMN year_of_passout integer DEFAULT NULL;
