
-- Enable realtime for messages if not already
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' AND tablename = 'messages'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
  END IF;
END $$;

-- Allow both sender and receiver to update collaboration_requests (for unfriend/block)
DROP POLICY IF EXISTS "Receivers can update request status" ON public.collaboration_requests;

CREATE POLICY "Participants can update request status"
ON public.collaboration_requests
FOR UPDATE
USING ((auth.uid() = sender_id) OR (auth.uid() = receiver_id));
