
-- Add parent_id to form_options for hierarchical branch support
ALTER TABLE public.form_options ADD COLUMN parent_id UUID REFERENCES public.form_options(id) ON DELETE CASCADE;

-- Add sub_branch to profiles (nullable for existing users)
ALTER TABLE public.profiles ADD COLUMN sub_branch TEXT;

-- Index for efficient sub-branch lookups
CREATE INDEX idx_form_options_parent_id ON public.form_options(parent_id) WHERE parent_id IS NOT NULL;
