
-- Create conferences table
CREATE TABLE public.conferences (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  organizer TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL DEFAULT 'Engineering',
  mode TEXT NOT NULL DEFAULT 'Online',
  deadline_date TIMESTAMP WITH TIME ZONE NOT NULL,
  link_url TEXT,
  status TEXT NOT NULL DEFAULT 'upcoming',
  created_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create published_papers table
CREATE TABLE public.published_papers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  author_name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Engineering',
  abstract TEXT,
  link_url TEXT,
  published_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.conferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.published_papers ENABLE ROW LEVEL SECURITY;

-- Conferences RLS policies
CREATE POLICY "Anyone authenticated can view conferences"
  ON public.conferences FOR SELECT USING (true);

CREATE POLICY "Admins can insert conferences"
  ON public.conferences FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update conferences"
  ON public.conferences FOR UPDATE
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete conferences"
  ON public.conferences FOR DELETE
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Published papers RLS policies
CREATE POLICY "Anyone authenticated can view papers"
  ON public.published_papers FOR SELECT USING (true);

CREATE POLICY "Admins can insert papers"
  ON public.published_papers FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update papers"
  ON public.published_papers FOR UPDATE
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete papers"
  ON public.published_papers FOR DELETE
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Triggers for updated_at
CREATE TRIGGER update_conferences_updated_at
  BEFORE UPDATE ON public.conferences
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_published_papers_updated_at
  BEFORE UPDATE ON public.published_papers
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
