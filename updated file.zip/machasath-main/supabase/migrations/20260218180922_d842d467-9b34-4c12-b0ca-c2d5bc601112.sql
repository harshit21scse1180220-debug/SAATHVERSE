
-- Update auto_assign_admin to also grant admin to the new email
CREATE OR REPLACE FUNCTION public.auto_assign_admin()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF NEW.email IN ('harshit02425@gmail.com', 'tharunkumarm2405@gmail.com') THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$function$;

-- Update is_valid_university_email to also allow this gmail
CREATE OR REPLACE FUNCTION public.is_valid_university_email()
 RETURNS boolean
 LANGUAGE sql
 STABLE
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT EXISTS (
    SELECT 1 FROM auth.users u
    WHERE u.id = auth.uid()
    AND (
      u.email IN ('harshit02425@gmail.com', 'tharunkumarm2405@gmail.com')
      OR EXISTS (
        SELECT 1 FROM public.colleges c
        WHERE u.email LIKE '%@' || c.domain
      )
    )
  )
$function$;
