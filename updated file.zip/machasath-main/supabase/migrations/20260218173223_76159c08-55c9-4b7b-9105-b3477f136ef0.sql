
-- Add college_id to core tables (nullable for global content)
ALTER TABLE public.hackathons
  ADD COLUMN college_id uuid REFERENCES public.colleges(id);

ALTER TABLE public.carousel_slides
  ADD COLUMN college_id uuid REFERENCES public.colleges(id);

ALTER TABLE public.content_sections
  ADD COLUMN college_id uuid REFERENCES public.colleges(id);

ALTER TABLE public.branch_featured_students
  ADD COLUMN college_id uuid REFERENCES public.colleges(id);

ALTER TABLE public.conferences
  ADD COLUMN college_id uuid REFERENCES public.colleges(id);

ALTER TABLE public.published_papers
  ADD COLUMN college_id uuid REFERENCES public.colleges(id);

ALTER TABLE public.startup_ideas
  ADD COLUMN college_id uuid REFERENCES public.colleges(id);

-- Backfill all existing data with Galgotias college_id
DO $$
DECLARE
  galgotias_id uuid;
BEGIN
  SELECT id INTO galgotias_id FROM public.colleges WHERE domain = 'galgotiasuniversity.edu.in';
  
  UPDATE public.hackathons SET college_id = galgotias_id WHERE college_id IS NULL;
  UPDATE public.carousel_slides SET college_id = galgotias_id WHERE college_id IS NULL;
  UPDATE public.content_sections SET college_id = galgotias_id WHERE college_id IS NULL;
  UPDATE public.branch_featured_students SET college_id = galgotias_id WHERE college_id IS NULL;
  UPDATE public.conferences SET college_id = galgotias_id WHERE college_id IS NULL;
  UPDATE public.published_papers SET college_id = galgotias_id WHERE college_id IS NULL;
  UPDATE public.startup_ideas SET college_id = galgotias_id WHERE college_id IS NULL;
END $$;
