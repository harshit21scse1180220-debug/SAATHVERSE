-- Allow team creators to delete their own teams
CREATE POLICY "Team creators can delete their teams"
ON public.hackathon_teams
FOR DELETE
USING (auth.uid() = creator_id);

-- Allow team creators to update their teams
CREATE POLICY "Team creators can update their teams"
ON public.hackathon_teams
FOR UPDATE
USING (auth.uid() = creator_id);
