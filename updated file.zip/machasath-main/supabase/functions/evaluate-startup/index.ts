import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("Missing authorization header");

    // Verify the user
    const anonClient = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_ANON_KEY")!);
    const { data: { user }, error: authError } = await anonClient.auth.getUser(authHeader.replace("Bearer ", ""));
    if (authError || !user) throw new Error("Unauthorized");

    const { startup_id } = await req.json();
    if (!startup_id) throw new Error("startup_id is required");

    // Fetch the startup idea
    const { data: startup, error: fetchError } = await supabase
      .from("startup_ideas")
      .select("*")
      .eq("id", startup_id)
      .single();
    if (fetchError || !startup) throw new Error("Startup idea not found");

    // Security: only creator can trigger evaluation
    if (startup.creator_id !== user.id) throw new Error("Only the creator can evaluate this idea");

    // Check description length
    if (!startup.description || startup.description.length < 100) {
      return new Response(JSON.stringify({ error: "Description must be at least 100 characters for AI evaluation" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Check 24h cooldown for re-evaluation
    if (startup.ai_evaluated_at) {
      const lastEval = new Date(startup.ai_evaluated_at).getTime();
      const now = Date.now();
      const hoursSince = (now - lastEval) / (1000 * 60 * 60);
      if (hoursSince < 24) {
        return new Response(JSON.stringify({ error: `Re-evaluation available in ${Math.ceil(24 - hoursSince)} hours` }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    // Rate limit: max 3 evaluations per day per user
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const { count } = await supabase
      .from("event_logs")
      .select("*", { count: "exact", head: true })
      .eq("user_id", user.id)
      .eq("event_type", "startup_ai_evaluated")
      .gte("created_at", todayStart.toISOString());
    if ((count ?? 0) >= 3) {
      return new Response(JSON.stringify({ error: "Daily evaluation limit reached (3/day)" }), {
        status: 429,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fetch creator profile for branch info
    const { data: profile } = await supabase
      .from("profiles")
      .select("branch")
      .eq("user_id", startup.creator_id)
      .single();

    const prompt = `Evaluate the following startup idea. Return response in strict JSON format:

{
  "overall_score": number (0-10, one decimal),
  "clarity_score": number (0-10, one decimal),
  "market_score": number (0-10, one decimal),
  "feasibility_score": number (0-10, one decimal),
  "innovation": "Low" | "Moderate" | "High",
  "difficulty": "Low" | "Medium" | "High",
  "strengths": ["point1", "point2", "point3"],
  "risks": ["risk1", "risk2", "risk3"],
  "suggestions": ["suggestion1", "suggestion2", "suggestion3"],
  "summary": "A short paragraph summarizing the evaluation"
}

Startup Idea:
TITLE: ${startup.title}
CATEGORY: ${startup.category || "Other"}
DESCRIPTION: ${startup.description}
BRANCH: ${profile?.branch || "Unknown"}

Important: Return ONLY the JSON object, no markdown, no code blocks, no extra text.`;

    // Call Lovable AI with fallback models
    const models = ["google/gemini-2.5-flash", "google/gemini-2.5-flash-lite"];
    let aiResponse: Response | null = null;

    for (const model of models) {
      console.log("Trying model:", model);
      const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: "system", content: "You are a startup evaluation expert. Evaluate startup ideas objectively and return structured JSON responses only." },
            { role: "user", content: prompt },
          ],
        }),
      });

      if (resp.ok) {
        aiResponse = resp;
        break;
      }

      const errText = await resp.text();
      console.error(`Model ${model} failed:`, resp.status, errText);

      if (resp.status === 429) {
        return new Response(JSON.stringify({ error: "AI rate limit exceeded, please try again later" }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (resp.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted, please try again later" }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    if (!aiResponse) {
      throw new Error("All AI models failed");
    }

    const aiData = await aiResponse.json();
    const rawContent = aiData.choices?.[0]?.message?.content;
    if (!rawContent) throw new Error("Empty AI response");

    // Parse JSON - strip potential markdown code blocks
    let cleaned = rawContent.trim();
    if (cleaned.startsWith("```")) {
      cleaned = cleaned.replace(/^```(?:json)?\n?/, "").replace(/\n?```$/, "");
    }

    let evaluation: any;
    try {
      evaluation = JSON.parse(cleaned);
    } catch {
      console.error("Failed to parse AI response:", cleaned);
      // Log error
      await supabase.from("event_logs").insert({
        user_id: user.id,
        event_type: "startup_ai_evaluation_failed",
        metadata: { startup_id, error: "JSON parse failed", raw: cleaned.substring(0, 500) },
      });
      throw new Error("AI returned invalid response format");
    }

    // Validate scores
    const clamp = (v: any, min: number, max: number) => {
      const n = parseFloat(v);
      if (isNaN(n)) return null;
      return Math.round(Math.min(max, Math.max(min, n)) * 10) / 10;
    };

    const updateData = {
      ai_overall_score: clamp(evaluation.overall_score, 0, 10),
      ai_clarity_score: clamp(evaluation.clarity_score, 0, 10),
      ai_market_score: clamp(evaluation.market_score, 0, 10),
      ai_feasibility_score: clamp(evaluation.feasibility_score, 0, 10),
      ai_innovation: ["Low", "Moderate", "High"].includes(evaluation.innovation) ? evaluation.innovation : null,
      ai_difficulty: ["Low", "Medium", "High"].includes(evaluation.difficulty) ? evaluation.difficulty : null,
      ai_strengths: Array.isArray(evaluation.strengths) ? JSON.stringify(evaluation.strengths) : null,
      ai_risks: Array.isArray(evaluation.risks) ? JSON.stringify(evaluation.risks) : null,
      ai_suggestions: Array.isArray(evaluation.suggestions) ? JSON.stringify(evaluation.suggestions) : null,
      ai_summary: typeof evaluation.summary === "string" ? evaluation.summary : null,
      ai_evaluated_at: new Date().toISOString(),
    };

    // Update startup idea
    const { error: updateError } = await supabase
      .from("startup_ideas")
      .update(updateData)
      .eq("id", startup_id);
    if (updateError) throw updateError;

    // Log event
    await supabase.from("event_logs").insert({
      user_id: user.id,
      event_type: "startup_ai_evaluated",
      metadata: { startup_id, overall_score: updateData.ai_overall_score },
    });

    return new Response(JSON.stringify({ success: true, ...updateData }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("evaluate-startup error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
