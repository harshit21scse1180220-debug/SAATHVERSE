import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

function escapeCsv(val: string): string {
  if (val.includes(",") || val.includes('"') || val.includes("\n")) {
    return `"${val.replace(/"/g, '""')}"`;
  }
  return val;
}

function generateCSV(headers: string[], rows: string[][]): string {
  const lines = [headers.map(escapeCsv).join(",")];
  rows.forEach((row) => {
    lines.push(row.map(escapeCsv).join(","));
  });
  return lines.join("\r\n");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const userClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const adminClient = createClient(supabaseUrl, supabaseServiceKey);
    const { data: isAdmin } = await adminClient.rpc("has_role", {
      _user_id: user.id,
      _role: "admin",
    });

    if (!isAdmin) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: profiles, error: profilesError } = await adminClient
      .from("profiles")
      .select("*")
      .order("created_at", { ascending: false });

    if (profilesError) throw profilesError;

    const { data: { users: authUsers } } = await adminClient.auth.admin.listUsers({ perPage: 1000 });
    const emailMap: Record<string, string> = {};
    authUsers?.forEach((u: any) => {
      emailMap[u.id] = u.email || "";
    });

    const headers = [
      "Full Name", "Email", "Gender", "College", "Branch", "Specialization",
      "Year of Study", "Bio", "Skills", "Interested in Hackathons",
      "Is Alumni", "Company", "Domain", "Year of Passout",
      "Show Photo", "Registered At"
    ];

    const rows = (profiles || []).map((p: any) => [
      p.full_name || "",
      emailMap[p.user_id] || "",
      p.gender || "",
      p.college_name || "",
      p.branch || "",
      p.sub_branch || "",
      p.year_of_study === 0 ? "N/A" : String(p.year_of_study || ""),
      p.bio || "",
      (p.skills || []).join("; "),
      p.interested_in_hackathons ? "Yes" : "No",
      p.is_alumni ? "Yes" : "No",
      p.company_name || "",
      p.tech_or_non_tech || "",
      p.year_of_passout ? String(p.year_of_passout) : "",
      p.show_photo ? "Yes" : "No",
      p.created_at ? new Date(p.created_at).toLocaleString() : "",
    ]);

    const csv = generateCSV(headers, rows);

    return new Response(csv, {
      headers: {
        ...corsHeaders,
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="student_registrations_${new Date().toISOString().slice(0, 10)}.csv"`,
      },
    });
  } catch (error) {
    console.error("Export error:", error);
    return new Response(JSON.stringify({ error: String(error) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
