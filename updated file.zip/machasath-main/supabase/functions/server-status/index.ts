import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const dbUrl = Deno.env.get("SUPABASE_DB_URL")!;

    // Verify caller is admin
    const token = authHeader.replace("Bearer ", "");
    const anonClient = createClient(supabaseUrl, anonKey);
    const { data: claimsData, error: claimsError } = await anonClient.auth.getClaims(token);

    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = claimsData.claims.sub as string;
    const adminClient = createClient(supabaseUrl, serviceRoleKey);

    const { data: isAdmin } = await adminClient.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    if (!isAdmin) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── Gather metrics in parallel ──

    const [
      dbSizeResult,
      storageSizeResult,
      totalUsersResult,
      activeUsersResult,
      profileCountResult,
      settingsResult,
      storageBucketsResult,
      recentSignupsResult,
    ] = await Promise.allSettled([
      // 1. Database size via SQL
      adminClient.rpc("get_db_size").then((r) => r),

      // 2. Storage: list all buckets and sum file sizes
      getStorageUsage(adminClient),

      // 3. Total auth users
      adminClient.auth.admin.listUsers({ perPage: 1 }).then((r) => ({
        // The total is returned even with perPage=1
        total: (r.data as any)?.total ?? r.data?.users?.length ?? 0,
      })),

      // 4. Active users (profiles updated in last 7 days)
      adminClient
        .from("profiles")
        .select("*", { count: "exact", head: true })
        .gte("updated_at", new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()),

      // 5. Total profiles count
      adminClient.from("profiles").select("*", { count: "exact", head: true }),

      // 6. Site settings for max upload size
      adminClient.from("site_settings").select("key, value").eq("key", "max_upload_size_kb").maybeSingle(),

      // 7. Storage bucket list
      adminClient.storage.listBuckets(),

      // 8. Recent signups (last 4 weeks, grouped by week)
      getRecentSignups(adminClient),
    ]);

    // ── Process results ──

    // DB size (fallback if RPC doesn't exist)
    let dbSizeBytes = 0;
    let dbSizeAvailableBytes = 500 * 1024 * 1024; // 500MB default for free plan
    if (dbSizeResult.status === "fulfilled" && dbSizeResult.value?.data) {
      dbSizeBytes = dbSizeResult.value.data;
    }

    // Storage usage
    let storageSizeBytes = 0;
    let storageAvailableBytes = 1 * 1024 * 1024 * 1024; // 1GB default
    if (storageSizeResult.status === "fulfilled") {
      storageSizeBytes = storageSizeResult.value;
    }

    // Users
    let totalUsers = 0;
    if (totalUsersResult.status === "fulfilled") {
      totalUsers = totalUsersResult.value.total;
    }

    let activeUsers7d = 0;
    if (activeUsersResult.status === "fulfilled") {
      activeUsers7d = activeUsersResult.value.count ?? 0;
    }

    let profileCount = 0;
    if (profileCountResult.status === "fulfilled") {
      profileCount = profileCountResult.value.count ?? 0;
    }

    // Max upload size KB
    let maxUploadSizeKB = 1024;
    if (settingsResult.status === "fulfilled" && settingsResult.value?.data?.value) {
      const parsed = parseInt(settingsResult.value.data.value, 10);
      if (!isNaN(parsed)) maxUploadSizeKB = parsed;
    }

    // User capacity calculation
    const remainingStorageBytes = Math.max(0, storageAvailableBytes - storageSizeBytes);
    const perUserBytes = maxUploadSizeKB * 1024;
    const estimatedUsersLeft = perUserBytes > 0 ? Math.floor(remainingStorageBytes / perUserBytes) : 0;
    const maxSupportedUsers = perUserBytes > 0 ? Math.floor(storageAvailableBytes / perUserBytes) : 0;

    // Buckets info
    let buckets: { name: string; public: boolean }[] = [];
    if (storageBucketsResult.status === "fulfilled" && storageBucketsResult.value?.data) {
      buckets = storageBucketsResult.value.data.map((b: any) => ({
        name: b.name,
        public: b.public,
      }));
    }

    // Recent signups
    let recentSignups: { week: string; count: number }[] = [];
    if (recentSignupsResult.status === "fulfilled") {
      recentSignups = recentSignupsResult.value;
    }

    // ── Service health pings ──
    const serviceHealth = await checkServiceHealth(supabaseUrl, anonKey);

    // ── Build response ──
    const response = {
      timestamp: new Date().toISOString(),
      database: {
        sizeBytes: dbSizeBytes,
        availableBytes: dbSizeAvailableBytes,
        percentUsed: dbSizeAvailableBytes > 0 ? Math.round((dbSizeBytes / dbSizeAvailableBytes) * 100) : 0,
      },
      storage: {
        sizeBytes: storageSizeBytes,
        availableBytes: storageAvailableBytes,
        percentUsed: storageAvailableBytes > 0 ? Math.round((storageSizeBytes / storageAvailableBytes) * 100) : 0,
        buckets,
      },
      users: {
        totalRegistered: totalUsers,
        totalProfiles: profileCount,
        activeLastWeek: activeUsers7d,
      },
      userCapacity: {
        currentUsers: profileCount,
        maxSupportedUsers,
        remainingSlots: estimatedUsersLeft,
        maxUploadSizeKB,
      },
      serviceHealth,
      recentSignups,
      alerts: generateAlerts({
        dbPercent: dbSizeAvailableBytes > 0 ? (dbSizeBytes / dbSizeAvailableBytes) * 100 : 0,
        storagePercent: storageAvailableBytes > 0 ? (storageSizeBytes / storageAvailableBytes) * 100 : 0,
        remainingSlots: estimatedUsersLeft,
        maxSupportedUsers,
        serviceHealth,
      }),
    };

    return new Response(JSON.stringify(response), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("server-status error:", err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

/* ── Helpers ── */

async function getStorageUsage(client: any): Promise<number> {
  try {
    const { data: buckets } = await client.storage.listBuckets();
    if (!buckets?.length) return 0;
    let totalSize = 0;
    for (const bucket of buckets) {
      try {
        const { data: files } = await client.storage.from(bucket.name).list("", { limit: 1000 });
        if (files) {
          for (const file of files) {
            if (file.metadata?.size) {
              totalSize += file.metadata.size;
            }
          }
        }
      } catch {
        // skip inaccessible bucket
      }
    }
    return totalSize;
  } catch {
    return 0;
  }
}

async function getRecentSignups(client: any): Promise<{ week: string; count: number }[]> {
  try {
    const fourWeeksAgo = new Date(Date.now() - 28 * 24 * 60 * 60 * 1000);
    const { data } = await client
      .from("profiles")
      .select("created_at")
      .gte("created_at", fourWeeksAgo.toISOString())
      .order("created_at", { ascending: true });

    if (!data?.length) return [];

    // Group by week
    const weeks: Record<string, number> = {};
    for (const row of data) {
      const d = new Date(row.created_at);
      const weekStart = new Date(d);
      weekStart.setDate(d.getDate() - d.getDay());
      const key = weekStart.toISOString().split("T")[0];
      weeks[key] = (weeks[key] || 0) + 1;
    }

    return Object.entries(weeks).map(([week, count]) => ({ week, count }));
  } catch {
    return [];
  }
}

async function checkServiceHealth(
  supabaseUrl: string,
  anonKey: string
): Promise<Record<string, { status: string; latencyMs: number }>> {
  const results: Record<string, { status: string; latencyMs: number }> = {};

  // Database check
  const dbStart = Date.now();
  try {
    const res = await fetch(`${supabaseUrl}/rest/v1/site_settings?select=id&limit=1`, {
      headers: { apikey: anonKey, Authorization: `Bearer ${anonKey}` },
    });
    results.database = {
      status: res.ok ? "healthy" : "degraded",
      latencyMs: Date.now() - dbStart,
    };
  } catch {
    results.database = { status: "down", latencyMs: Date.now() - dbStart };
  }

  // Auth check
  const authStart = Date.now();
  try {
    const res = await fetch(`${supabaseUrl}/auth/v1/settings`, {
      headers: { apikey: anonKey },
    });
    results.authentication = {
      status: res.ok ? "healthy" : "degraded",
      latencyMs: Date.now() - authStart,
    };
  } catch {
    results.authentication = { status: "down", latencyMs: Date.now() - authStart };
  }

  // Storage check
  const storageStart = Date.now();
  try {
    const res = await fetch(`${supabaseUrl}/storage/v1/bucket`, {
      headers: { apikey: anonKey, Authorization: `Bearer ${anonKey}` },
    });
    results.storage = {
      status: res.ok ? "healthy" : "degraded",
      latencyMs: Date.now() - storageStart,
    };
  } catch {
    results.storage = { status: "down", latencyMs: Date.now() - storageStart };
  }

  // Realtime check
  const rtStart = Date.now();
  try {
    const res = await fetch(`${supabaseUrl}/realtime/v1/api/health`, {
      headers: { apikey: anonKey },
    });
    results.realtime = {
      status: res.ok ? "healthy" : "degraded",
      latencyMs: Date.now() - rtStart,
    };
  } catch {
    results.realtime = { status: "down", latencyMs: Date.now() - rtStart };
  }

  // Edge functions check
  const efStart = Date.now();
  try {
    // Just check if the functions endpoint is reachable
    const res = await fetch(`${supabaseUrl}/functions/v1/`, {
      method: "OPTIONS",
      headers: { apikey: anonKey },
    });
    results.edge_functions = {
      status: res.status < 500 ? "healthy" : "degraded",
      latencyMs: Date.now() - efStart,
    };
  } catch {
    results.edge_functions = { status: "down", latencyMs: Date.now() - efStart };
  }

  return results;
}

interface AlertInput {
  dbPercent: number;
  storagePercent: number;
  remainingSlots: number;
  maxSupportedUsers: number;
  serviceHealth: Record<string, { status: string; latencyMs: number }>;
}

function generateAlerts(input: AlertInput): { level: string; message: string }[] {
  const alerts: { level: string; message: string }[] = [];

  if (input.dbPercent > 90) {
    alerts.push({ level: "critical", message: `Database at ${Math.round(input.dbPercent)}% capacity` });
  } else if (input.dbPercent > 80) {
    alerts.push({ level: "warning", message: `Database at ${Math.round(input.dbPercent)}% capacity` });
  }

  if (input.storagePercent > 90) {
    alerts.push({ level: "critical", message: `Storage at ${Math.round(input.storagePercent)}% capacity` });
  } else if (input.storagePercent > 80) {
    alerts.push({ level: "warning", message: `Storage at ${Math.round(input.storagePercent)}% capacity` });
  }

  if (input.maxSupportedUsers > 0) {
    const capacityPercent = ((input.maxSupportedUsers - input.remainingSlots) / input.maxSupportedUsers) * 100;
    if (capacityPercent > 90) {
      alerts.push({ level: "critical", message: `Only ${input.remainingSlots} user slots remaining` });
    } else if (input.remainingSlots < 100) {
      alerts.push({ level: "warning", message: `Only ${input.remainingSlots} user slots remaining` });
    }
  }

  for (const [service, health] of Object.entries(input.serviceHealth)) {
    if (health.status === "down") {
      alerts.push({ level: "critical", message: `${service.replace("_", " ")} service is not responding` });
    } else if (health.status === "degraded") {
      alerts.push({ level: "warning", message: `${service.replace("_", " ")} service is degraded` });
    }
    if (health.latencyMs > 5000) {
      alerts.push({ level: "warning", message: `${service.replace("_", " ")} latency is high (${health.latencyMs}ms)` });
    }
  }

  return alerts;
}
